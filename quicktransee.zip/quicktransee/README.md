<img width="200px" src="public/icon.png" align="left"/>

# QuickTransee

> 🌈 Một phần mềm dịch thuật văn bản và OCR đa nền tảng

![License](https://img.shields.io/badge/license-GPLv3-blue.svg)
![Tauri](https://img.shields.io/badge/Tauri-1.6.8-blue?logo=tauri)
![JavaScript](https://img.shields.io/badge/-JavaScript-yellow?logo=javascript&logoColor=white)
![Rust](https://img.shields.io/badge/-Rust-orange?logo=rust&logoColor=white)
![Windows](https://img.shields.io/badge/-Windows-blue?logo=windows&logoColor=white)
![MacOS](https://img.shields.io/badge/-macOS-black?&logo=apple&logoColor=white)
![Linux](https://img.shields.io/badge/-Linux-yellow?logo=linux&logoColor=white)

<br/>
<hr/>
<div align="center">

<h3> <a href='./README_EN.md'> English </a> | <a href='./README_JA.md'> 日本語 </a> | Tiếng Việt </h3>

<table>
<tr>
    <td> <img src="asset/1.png">
    <td> <img src="asset/2.png">
</table>

# Mục lục

</div>

-   [Cách sử dụng](#cách-sử-dụng)
-   [Tính năng](#tính-năng)
-   [Dịch vụ hỗ trợ](#dịch-vụ-hỗ-trợ)
-   [Cài đặt](#cài-đặt)
-   [Gọi từ bên ngoài (API)](#gọi-từ-bên-ngoài-api)
-   [Hỗ trợ Wayland](#hỗ-trợ-wayland)
-   [Biên dịch thủ công](#biên-dịch-thủ-công)
-   [Cảm ơn](#cảm-ơn)

<div align="center">

# Cách sử dụng

</div>

| Dịch bằng cách bôi đen                          | Dịch bằng cách nhập liệu                                          | Gọi từ ứng dụng khác                                                                  |
| ----------------------------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| Chọn văn bản và nhấn phím tắt để dịch           | Nhấn phím tắt để mở cửa sổ dịch, nhập văn bản và nhấn Enter       | Quy trình làm việc hiệu quả hơn bằng cách tích hợp ứng dụng khác, xem [API](#gọi-từ-bên-ngoài-api) |
| <img src="asset/eg1.gif"/>                      | <img src="asset/eg2.gif"/>                                        | <img src="asset/eg3.gif"/>                                                            |

| Nghe Clipboard                                                                                                               | OCR Ảnh chụp màn hình              | Dịch Ảnh chụp màn hình                   |
| ---------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- | ---------------------------------------- |
| Nhấp vào biểu tượng góc trên bên trái của bất kỳ bảng dịch nào để bắt đầu nghe clipboard. Văn bản đã sao chép sẽ được tự động dịch. | Nhấn phím tắt, chọn vùng để OCR    | Nhấn phím tắt, chọn vùng để dịch         |
| <img src="asset/eg4.gif"/>                                                                                                   | <img src="asset/eg5.gif"/>         | <img src="asset/eg6.gif"/>               |

<div align="center">

# Tính năng

</div>

-   [x] Dịch song song với nhiều dịch vụ ([Dịch vụ hỗ trợ](#dịch-vụ-hỗ-trợ))
-   [x] OCR với nhiều dịch vụ ([Dịch vụ hỗ trợ](#dịch-vụ-hỗ-trợ))
-   [x] Hỗ trợ chuyển văn bản thành giọng nói (TTS) ([Dịch vụ hỗ trợ](#dịch-vụ-hỗ-trợ))
-   [x] Xuất sang các ứng dụng học từ vựng ([Dịch vụ hỗ trợ](#dịch-vụ-hỗ-trợ))
-   [x] Gọi từ bên ngoài (External calls) ([API](#gọi-từ-bên-ngoài-api))
-   [x] Hỗ trợ Windows, macOS và Linux
-   [x] Hỗ trợ Wayland (Đã thử nghiệm trên KDE, Gnome và Hyprland)
-   [x] Hỗ trợ đa ngôn ngữ (Tiếng Anh, Tiếng Nhật)

<div align="center">

# Dịch vụ hỗ trợ

</div>

## Dịch thuật

-   [x] [OpenAI](https://platform.openai.com/)
-   [x] [Gemini Pro](https://gemini.google.com/)
-   [x] [Ollama](https://www.ollama.com/) (Ngoại tuyến)
-   [x] [Google Translate](https://translate.google.com)
-   [x] [Bing Translate](https://learn.microsoft.com/zh-cn/azure/cognitive-services/translator/)
-   [x] [Bing Dictionary](https://www.bing.com/dict)
-   [x] [DeepL](https://www.deepl.com/)

## Nhận diện văn bản (OCR)

-   [x] System OCR (Ngoại tuyến)
    -   [x] [Windows.Media.OCR](https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine?view=winrt-22621) trên Windows
    -   [x] [Apple Vision Framework](https://developer.apple.com/documentation/vision/recognizing_text_in_images) trên MacOS
    -   [x] [Tesseract OCR](https://github.com/tesseract-ocr) trên Linux
-   [x] [Tesseract.js](https://tesseract.projectnaptha.com/) (Ngoại tuyến)

## Chuyển văn bản thành giọng nói (TTS)

-   [x] [Lingva](https://github.com/thedaviddelta/lingva-translate)

## Sổ từ vựng

-   [x] [Anki](https://apps.ankiweb.net/)
-   [x] [Eudic](https://dict.eudic.net/)

<div align="center">

# Cài đặt

</div>

## Windows

### Cài đặt thủ công

1. Tải gói cài đặt định dạng `.exe` từ phiên bản mới nhất.
    - Máy 64-bit tải `quicktransee_{version}_x64-setup.exe`
    - Máy 32-bit tải `quicktransee_{version}_x86-setup.exe`
    - Máy arm64 tải `quicktransee_{version}_arm64-setup.exe`

2. Nhấp đúp vào tệp đã tải xuống để cài đặt.

### Khắc phục sự cố

-   **Không có giao diện sau khi khởi động / Biểu tượng khay hệ thống không phản hồi:**
    Kiểm tra xem WebView2 có bị gỡ cài đặt hoặc bị vô hiệu hóa hay không. Nếu có, hãy cài đặt WebView2 thủ công hoặc khôi phục nó.
    Nếu vấn đề vẫn còn, hãy thử khởi động ở chế độ tương thích Windows 7.

## MacOS

### Cài đặt thủ công

1. Tải gói cài đặt định dạng `.dmg`. (Nếu bạn sử dụng chip M1/M2, vui lòng tải phiên bản `aarch64`, nếu không thì tải `x64`).
2. Nhấp đúp vào tệp đã tải xuống để cài đặt.

### Khắc phục sự cố

-   **"QuickTransee" không thể mở vì nhà phát triển không thể được xác minh:**
    Vào Cài đặt -> Quyền riêng tư và bảo mật, nhấp vào nút "Vẫn mở" (Still Open).
    Nếu vẫn không được, hãy chạy lệnh sau trong Terminal:
    ```bash
    sudo xattr -d com.apple.quarantine /Applications/quicktransee.app
    ```

## Linux

Chúng tôi cung cấp các gói `.deb` cho Linux.

### Arch/Manjaro

Trên phiên bản mới của [Webkit2Gtk](https://archlinux.org/packages/extra/x86_64/webkit2gtk) (2.42.0), trình điều khiển Nvidia có thể khiến ứng dụng không khởi động được.
Vui lòng thêm `WEBKIT_DISABLE_DMABUF_RENDERER=1` vào biến môi trường của bạn.

<div align="center">

# Gọi từ bên ngoài (API)

</div>

QuickTransee cung cấp giao diện HTTP để tích hợp với các phần mềm khác. Cổng mặc định là `60828`.

## Tài liệu API:

```bash
POST "/" => Dịch văn bản (body là văn bản cần dịch)
GET "/config" => Mở cài đặt
POST "/translate" => Dịch văn bản (tương tự "/")
GET "/selection_translate" => Dịch văn bản đang chọn
GET "/input_translate" => Mở ô nhập liệu dịch
GET "/ocr_recognize" => Thực hiện OCR trên ảnh chụp màn hình
GET "/ocr_translate" => Thực hiện dịch trên ảnh chụp màn hình
GET "/ocr_recognize?screenshot=false" => OCR không cần chụp màn hình (dùng ảnh có sẵn)
GET "/ocr_translate?screenshot=false" => Dịch không cần chụp màn hình (dùng ảnh có sẵn)
```

## Ví dụ:

```bash
curl "127.0.0.1:60828/selection_translate"
```

<div align="center">

# Hỗ trợ Wayland

</div>

- **Phím tắt:** Tauri thiếu hỗ trợ Wayland cho phím tắt toàn cục. Sử dụng phím tắt hệ thống với `curl` để kích hoạt hành động.
- **Chụp màn hình:** Nếu tính năng chụp màn hình tích hợp bị lỗi, hãy sử dụng các công cụ bên ngoài như `grim` và `slurp`, lưu vào thư mục cache, sau đó gọi với tham số `screenshot=false`.

<div align="center">

# Biên dịch thủ công

</div>

### Yêu cầu

- Node.js >= 18.0.0
- pnpm >= 8.5.0
- Rust >= 1.80.0

### Các bước

1. Clone repository.
2. Cài đặt phụ thuộc: `pnpm install`.
3. Phát triển: `pnpm tauri dev`.
4. Đóng gói: `pnpm tauri build`.

<div align="center">

# Cảm ơn

</div>

-   [Pot](https://github.com/pot-app/pot-desktop) Dự án gốc
-   [Bob](https://github.com/ripperhe/Bob) Nguồn cảm hứng
-   [Tauri](https://github.com/tauri-apps/tauri) GUI Framework

<div align="center">
