<img width="200px" src="public/icon.png" align="left"/>

# QuickTransee

> 🌈 クロスプラットフォーム対応の翻訳・OCRソフトウェア

![License](https://img.shields.io/badge/license-GPLv3-blue.svg)
![Tauri](https://img.shields.io/badge/Tauri-1.6.8-blue?logo=tauri)
![JavaScript](https://img.shields.io/badge/-JavaScript-yellow?logo=javascript&logoColor=white)
![Rust](https://img.shields.io/badge/-Rust-orange?logo=rust&logoColor=white)
![Windows](https://img.shields.io/badge/-Windows-blue?logo=windows&logoColor=white)
![MacOS](https://img.shields.io/badge/-macOS-black?&logo=apple&logoColor=white)
![Linux](https://img.shields.io/badge/-Linux-yellow?logo=linux&logoColor=white)

<br/>
<hr/>
<div align="center">

<h3> <a href='./README_EN.md'> English </a> | 日本語 | <a href='./README.md'> Tiếng Việt </a></h3>

<table>
<tr>
    <td> <img src="asset/1.png">
    <td> <img src="asset/2.png">
</table>

# 目次

</div>

-   [使い方](#使い方)
-   [主な機能](#主な機能)
-   [対応サービス](#対応サービス)
-   [インストール](#インストール)
-   [外部呼び出し (API)](#外部呼び出し-api)
-   [Wayland サポート](#wayland-サポート)
-   [手動ビルド](#手動ビルド)
-   [謝辞](#謝辞)

<div align="center">

# 使い方

</div>

| 選択範囲を翻訳                                  | 入力して翻訳                                                  | 外部アプリからの呼び出し                                                                 |
| ----------------------------------------------- | ------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| テキストを選択してショートカットキーを押すと翻訳 | ショートカットでウィンドウを開き、テキストを入力してEnterで翻訳 | 他のアプリと連携して効率的に動作します。詳細は [API](#外部呼び出し-api) を参照           |
| <img src="asset/eg1.gif"/>                      | <img src="asset/eg2.gif"/>                                    | <img src="asset/eg3.gif"/>                                                               |

| クリップボード監視                                                                                                           | 画面キャプチャ OCR                 | 画面キャプチャ翻訳                       |
| ---------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- | ---------------------------------------- |
| 翻訳パネルの左上のアイコンをクリックして監視を開始。コピーしたテキストが自動的に翻訳されます。 | ショートカットを押し、範囲を選択してOCR | ショートカットを押し、範囲を選択して翻訳 |
| <img src="asset/eg4.gif"/>                                                                                                   | <img src="asset/eg5.gif"/>         | <img src="asset/eg6.gif"/>               |

<div align="center">

# 主な機能

</div>

-   [x] 複数サービスによる同時翻訳 ([対応サービス](#対応サービス))
-   [x] 複数サービスによる OCR ([対応サービス](#対応サービス))
-   [x] テキスト読み上げ (TTS) サポート ([対応サービス](#対応サービス))
-   [x] 単語帳アプリへのエクスポート ([対応サービス](#対応サービス))
-   [x] 外部からの呼び出し (External calls) ([API](#外部呼び出し-api))
-   [x] Windows, macOS, Linux 対応
-   [x] Wayland サポート (KDE, Gnome, Hyprland でテスト済み)
-   [x] 多言語対応 (英語、日本語)

<div align="center">

# 対応サービス

</div>

## 翻訳

-   [x] [OpenAI](https://platform.openai.com/)
-   [x] [Gemini Pro](https://gemini.google.com/)
-   [x] [Ollama](https://www.ollama.com/) (オフライン)
-   [x] [Google 翻訳](https://translate.google.com)
-   [x] [Bing 翻訳](https://learn.microsoft.com/zh-cn/azure/cognitive-services/translator/)
-   [x] [Bing 辞書](https://www.bing.com/dict)
-   [x] [DeepL](https://www.deepl.com/)

## 文字認識 (OCR)

-   [x] システム OCR (オフライン)
    -   [x] [Windows.Media.OCR](https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine?view=winrt-22621) (Windows)
    -   [x] [Apple Vision Framework](https://developer.apple.com/documentation/vision/recognizing_text_in_images) (MacOS)
    -   [x] [Tesseract OCR](https://github.com/tesseract-ocr) (Linux)
-   [x] [Tesseract.js](https://tesseract.projectnaptha.com/) (オフライン)

## テキスト読み上げ (TTS)

-   [x] [Lingva](https://github.com/thedaviddelta/lingva-translate)

## 単語帳

-   [x] [Anki](https://apps.ankiweb.net/)
-   [x] [欧路詞典 (Eudic)](https://dict.eudic.net/)

<div align="center">

# インストール

</div>

## Windows

### 手動インストール

1. 最新のリリースから `.exe` インストーラーをダウンロードしてください。
    - 64bit: `quicktransee_{version}_x64-setup.exe`
    - 32bit: `quicktransee_{version}_x86-setup.exe`
    - arm64: `quicktransee_{version}_arm64-setup.exe`

2. ダウンロードしたファイルをダブルクリックしてインストールします。

### トラブルシューティング

-   **起動しても画面が表示されない / トレイアイコンが反応しない:**
    WebView2 がインストールされているか確認してください。未インストールの場合は手動でインストールしてください。
    解決しない場合は、Windows 7 互換モードでの起動を試してください。

## MacOS

### 手動インストール

1. `.dmg` ファイルをダウンロードします。(M1/M2チップの場合は `aarch64` 版、それ以外は `x64` 版を選択)
2. ダウンロードしたファイルをダブルクリックしてインストールします。

### トラブルシューティング

-   **開発元を検証できないため開けない場合:**
    設定 -> プライバシーとセキュリティから「このまま開く」をクリックしてください。
    解決しない場合は、ターミナルで以下を実行してください:
    ```bash
    sudo xattr -d com.apple.quarantine /Applications/quicktransee.app
    ```

## Linux

Linux向けに `.deb` パッケージを提供しています。

### Arch/Manjaro

[Webkit2Gtk](https://archlinux.org/packages/extra/x86_64/webkit2gtk) (2.42.0) 以降では、Nvidiaドライバの影響で起動しないことがあります。
環境変数に `WEBKIT_DISABLE_DMABUF_RENDERER=1` を追加してください。

<div align="center">

# 外部呼び出し (API)

</div>

QuickTransee は、他のソフトウェアと連携するための HTTP インターフェースを提供しています。デフォルトポートは `60828` です。

## API ドキュメント:

```bash
POST "/" => 指定したテキストを翻訳 (body にテキストを含める)
GET "/config" => 設定を開く
POST "/translate" => 指定したテキストを翻訳 ("/" と同じ)
GET "/selection_translate" => 選択中のテキストを翻訳
GET "/input_translate" => 入力翻訳ウィンドウを開く
GET "/ocr_recognize" => 画面キャプチャ OCR を実行
GET "/ocr_translate" => 画面キャプチャ翻訳を実行
GET "/ocr_recognize?screenshot=false" => キャプチャせずに OCR (既存の画像を使用)
GET "/ocr_translate?screenshot=false" => キャプチャせずに翻訳 (既存の画像を使用)
```

## 例:

```bash
curl "127.0.0.1:60828/selection_translate"
```

<div align="center">

# Wayland サポート

</div>

- **ショートカットキー:** Tauri は Wayland でのグローバルショートカットをサポートしていません。システム側のショートカットに `curl` コマンドを設定して呼び出してください。
- **キャプチャ:** 内蔵キャプチャが動作しない場合は、`grim` や `slurp` などの外部ツールを使用し、キャッシュディレクトリに保存してから `screenshot=false` を指定して呼び出してください。

<div align="center">

# 手動ビルド

</div>

### 必要要件

- Node.js >= 18.0.0
- pnpm >= 8.5.0
- Rust >= 1.80.0

### 手順

1. リポジトリをクローンします。
2. 依存関係をインストール: `pnpm install`
3. 開発モード: `pnpm tauri dev`
4. ビルド: `pnpm tauri build`

<div align="center">

# 謝辞

</div>

-   [Pot](https://github.com/pot-app/pot-desktop) 元のプロジェクト
-   [Bob](https://github.com/ripperhe/Bob) インスピレーション
-   [Tauri](https://github.com/tauri-apps/tauri) GUI フレームワーク

<div align="center">
