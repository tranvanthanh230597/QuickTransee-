import { useLocation, useRoutes } from 'react-router-dom';
import React, { useEffect } from 'react';
import { appWindow } from '@tauri-apps/api/window';
import { useTranslation } from 'react-i18next';

import WindowControl from '../../components/WindowControl';
import SideBar from './components/SideBar';
import { osType } from '../../utils/env';
import { useConfig } from '../../hooks';
import routes from './routes';
import './style.css';
import { BarsIcon } from '../../components/Icons';

export default function Config() {
    const [transparent] = useConfig('transparent', true);
    const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);
    const { t } = useTranslation();
    const location = useLocation();
    const page = useRoutes(routes);

    useEffect(() => {
        if (appWindow.label === 'config') {
            appWindow.show();
        }
    }, []);

    return (
        <div className="flex flex-col h-screen overflow-hidden bg-white dark:bg-gray-900 select-none cursor-default">
            {/* Header / Top Navigation */}
            <nav
                className="fixed top-0 z-50 w-full bg-white border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700 h-[60px]"
                data-tauri-drag-region='true'
            >
                <div className="px-3 py-3 lg:px-5 lg:pl-3 h-full flex items-center justify-between" data-tauri-drag-region='true'>
                    <div className="flex items-center justify-start h-full" data-tauri-drag-region='true'>
                        <button
                            type="button"
                            className="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
                            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                        >
                            <span className="sr-only">Toggle sidebar</span>
                            <BarsIcon className="w-6 h-6" />
                        </button>
                        {/* <div className="flex items-center ms-2" data-tauri-drag-region='true'>
                            <img src="icon.png" className="h-8" alt="QuickTransee Logo" draggable={false} />
                        </div> */}
                    </div>

                    <div className="flex items-center gap-2" data-tauri-drag-region='true'>
                        <div className="flex items-center ms-2 h-full">
                            {osType !== 'Darwin' && <WindowControl />}
                        </div>
                    </div>
                </div>
            </nav>

            {/* Sidebar and Content Area */}
            <div className="flex flex-1 pt-[60px] overflow-hidden">
                {/* Sidebar Column */}
                <div
                    className={`${isSidebarOpen ? 'w-[240px]' : 'w-[64px]'} transition-all duration-300 flex-shrink-0 flex flex-col border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800`}
                >
                    <SideBar isCollapsed={!isSidebarOpen} />
                </div>

                {/* Main Content Area */}
                <main className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-950 overflow-hidden">
                    <div className="flex-1 flex flex-col overflow-hidden p-6 pb-0">
                        <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col overflow-hidden">
                            {/* Page Header */}
                            <div className="flex-none mb-6">
                                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                                    {t(`config.${location.pathname.slice(1) || 'general'}.title`)}
                                </h1>
                            </div>

                            {/* Page Content */}
                            <div className="flex-1 flex flex-col overflow-hidden pb-6">
                                {page}
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
