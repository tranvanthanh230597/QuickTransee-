import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import React from 'react';
import {
    SettingsIcon,
    GlobeIcon,
    CameraIcon,
    KeyboardIcon,
    ServerIcon,
    ClockIcon,
    BookIcon,
    InfoIcon
} from '../../../../components/Icons';

export default function SideBar({ isCollapsed }) {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const location = useLocation();

    function isActive(pathname) {
        return location.pathname.includes(pathname);
    }

    const getItemClasses = (pathname) => {
        const active = isActive(pathname);
        const baseClass = `flex items-center p-2 rounded-lg group w-full transition-all duration-200 text-sm font-medium ${isCollapsed ? 'justify-center' : ''}`;
        if (active) {
            return `${baseClass} bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white`;
        }
        return `${baseClass} text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:text-blue-600 dark:hover:text-blue-400`;
    };

    const getIconClasses = (pathname) => {
        const active = isActive(pathname);
        const baseClass = "flex-shrink-0 w-6 h-6 transition-colors duration-200";
        if (active) {
            return `${baseClass} text-gray-900 dark:text-white`;
        }
        return `${baseClass} text-gray-700 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-400`;
    };

    const menuItems = [
        { path: '/general', label: 'config.general.label', icon: SettingsIcon },
        { path: '/translate', label: 'config.translate.label', icon: GlobeIcon },
        { path: '/recognize', label: 'config.recognize.label', icon: CameraIcon },
        { path: '/hotkey', label: 'config.hotkey.label', icon: KeyboardIcon },
        { path: '/service', label: 'config.service.label', icon: ServerIcon },
        { path: '/history', label: 'config.history.label', icon: ClockIcon },
        { path: '/dictionary', label: 'config.dictionary.label', icon: BookIcon },
        { path: '/about', label: 'config.about.label', icon: InfoIcon },
    ];

    return (
        <aside id="default-sidebar" className="h-full flex flex-col" aria-label="Sidebar">
            <div className="h-full px-3 py-4 overflow-y-auto overflow-x-hidden">
                <ul className="space-y-2 font-medium">
                    {menuItems.map((item) => (
                        <li key={item.path}>
                            <button
                                className={getItemClasses(item.path)}
                                onClick={() => {
                                    navigate(item.path);
                                }}
                                title={isCollapsed ? t(item.label) : ''}
                            >
                                <item.icon className={getIconClasses(item.path)} aria-hidden="true" />
                                {!isCollapsed && (
                                    <span className="ms-3 flex-1 text-left whitespace-nowrap transition-opacity duration-300">
                                        {t(item.label)}
                                    </span>
                                )}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </aside>
    );
}
