import toast, { Toaster } from 'react-hot-toast';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { save, open } from '@tauri-apps/api/dialog';
import { writeTextFile, readTextFile } from '@tauri-apps/api/fs';
import Database from 'tauri-plugin-sql-api';
import Dropdown from '../../../../components/Dropdown';
import { DeleteIcon, PlusIcon, ArrowDownTrayIcon, ArrowUpTrayIcon, SearchIcon } from '../../../../components/Icons';

export default function Dictionary() {
    // Modal States
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [isProjectOpen, setIsProjectOpen] = useState(false);
    const [isDeleteProjectOpen, setIsDeleteProjectOpen] = useState(false);
    const [isClearOpen, setIsClearOpen] = useState(false);

    const [selectedItem, setSelectItem] = useState(null);
    const [originalItem, setOriginalItem] = useState(null);
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [items, setItems] = useState([]);

    const [newKey, setNewKey] = useState('');
    const [newValue, setNewValue] = useState('');

    const [projects, setProjects] = useState([]);
    const [currentProject, setCurrentProject] = useState(null);
    const [newProjectName, setNewProjectName] = useState('');
    const [selectedKeys, setSelectedKeys] = useState(new Set([])); // Set of IDs
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoaded, setIsLoaded] = useState(false);

    const { t } = useTranslation();

    useEffect(() => {
        const setup = async () => {
            await init();
            await initProject();
            setIsLoaded(true);
        };
        setup();
    }, []);

    useEffect(() => {
        if (!isLoaded) return;

        if (currentProject) {
            getData();
            localStorage.setItem('currentProjectId', currentProject.id.toString());
        } else {
            setItems([]);
            setTotal(0);
            localStorage.removeItem('currentProjectId');
        }
        setSelectedKeys(new Set([]));
    }, [isLoaded, total, page, currentProject, searchQuery]);

    const init = async () => {
        const db = await Database.load('sqlite:dictionary.db');
        await db.execute('CREATE TABLE IF NOT EXISTS dictionary(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL, value TEXT NOT NULL, timestamp INTEGER NOT NULL, project_id INTEGER)');
        try {
            await db.execute('ALTER TABLE dictionary ADD COLUMN project_id INTEGER');
        } catch (e) { }

        if (currentProject) {
            const result = await db.select('SELECT COUNT(*) FROM dictionary WHERE project_id = $1', [currentProject.id]);
            if (result[0] && result[0]['COUNT(*)']) {
                setTotal(result[0]['COUNT(*)']);
            } else {
                setTotal(0);
            }
        }
    };

    const initProject = async (newSelectedId = null) => {
        const db = await Database.load('sqlite:project.db');
        await db.execute('CREATE TABLE IF NOT EXISTS project(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, glossary_id TEXT)');
        const result = await db.select('SELECT * FROM project');
        setProjects(result);

        if (newSelectedId) {
            const newP = result.find(x => x.id === newSelectedId);
            if (newP) setCurrentProject(newP);
        } else if (result.length > 0 && !currentProject) {
            const savedId = localStorage.getItem('currentProjectId');
            if (savedId) {
                const savedP = result.find(x => x.id.toString() === savedId);
                if (savedP) {
                    setCurrentProject(savedP);
                    return;
                }
            }
            setCurrentProject(result[0]);
        } else if (result.length === 0) {
            setCurrentProject(null);
        }
    };

    const getData = async () => {
        if (!currentProject) return;
        const db = await Database.load('sqlite:dictionary.db');
        let query = 'SELECT * FROM dictionary WHERE project_id = $1';
        let countQuery = 'SELECT COUNT(*) FROM dictionary WHERE project_id = $1';
        let params = [currentProject.id];

        if (searchQuery) {
            query += ' AND (key LIKE $2 OR value LIKE $2)';
            countQuery += ' AND (key LIKE $2 OR value LIKE $2)';
            params.push(`%${searchQuery}%`);
        }

        const offsetParamIndex = params.length + 1;
        query += ` ORDER BY id DESC LIMIT 20 OFFSET $${offsetParamIndex}`;
        params.push(20 * (page - 1));

        let result = await db.select(query, params);
        setItems(result);

        const countResult = await db.select(countQuery, params.slice(0, params.length - 1));
        if (countResult[0] && countResult[0]['COUNT(*)']) {
            setTotal(countResult[0]['COUNT(*)']);
        } else {
            setTotal(0);
        }
    };

    const getSelectedData = async (id) => {
        const db = await Database.load('sqlite:dictionary.db');
        let result = await db.select('SELECT * FROM dictionary WHERE id=$1', [id]);
        setSelectItem(result[0]);
        setOriginalItem(result[0]);
        setIsEditOpen(true);
    };

    const clearData = async () => {
        if (!currentProject) return;
        const db = await Database.load('sqlite:dictionary.db');

        if (selectedKeys.size > 0) {
            const ids = Array.from(selectedKeys).join(',');
            await db.execute(`DELETE FROM dictionary WHERE id IN (${ids})`);
        } else {
            return;
        }

        await db.execute('VACUUM');
        setSelectedKeys(new Set([]));

        const countResult = await db.select('SELECT COUNT(*) FROM dictionary WHERE project_id = $1', [currentProject.id]);
        const newTotal = countResult[0]?.['COUNT(*)'] || 0;
        setTotal(newTotal);

        const maxPage = Math.ceil(newTotal / 20) || 1;
        if (page > maxPage) {
            setPage(maxPage);
        } else {
            await getData();
        }
        toast.success(t('common.success'));
        setIsClearOpen(false);
    };

    const updateData = async () => {
        if (selectedItem.key === originalItem.key && selectedItem.value === originalItem.value) {
            return;
        }
        const db = await Database.load('sqlite:dictionary.db');

        if (selectedItem.key.trim() !== originalItem.key) {
            const existing = await db.select('SELECT id FROM dictionary WHERE project_id = $1 AND key = $2 AND id != $3', [
                currentProject.id,
                selectedItem.key.trim(),
                selectedItem.id
            ]);
            if (existing.length > 0) {
                toast.error(t('config.dictionary.duplicate_key'));
                return true;
            }
        }

        await db.execute('UPDATE dictionary SET key=$1, value=$2, timestamp=$3 WHERE id=$4', [
            selectedItem.key.trim(),
            selectedItem.value.trim(),
            Date.now(),
            selectedItem.id,
        ]);
        await getData();
        toast.success(t('common.success'));
        setIsEditOpen(false);
        return true;
    };

    const addDictionary = async () => {
        if (!newKey || !newValue || !currentProject) return false;
        const db = await Database.load('sqlite:dictionary.db');

        const existing = await db.select('SELECT id FROM dictionary WHERE project_id = $1 AND key = $2', [currentProject.id, newKey.trim()]);
        if (existing.length > 0) {
            toast.error(t('config.dictionary.duplicate_key'));
            setNewKey('');
            setNewValue('');
            return true;
        }

        await db.execute('INSERT INTO dictionary (key, value, timestamp, project_id) VALUES ($1, $2, $3, $4)', [
            newKey.trim(),
            newValue.trim(),
            Date.now(),
            currentProject.id
        ]);
        setNewKey('');
        setNewValue('');
        await getData();
        toast.success(t('common.success'));
        setIsAddOpen(false);
        return true;
    };

    const addProject = async () => {
        if (!newProjectName) return false;
        const db = await Database.load('sqlite:project.db');
        const result = await db.execute('INSERT INTO project (name) VALUES ($1)', [newProjectName]);
        const newId = result.lastInsertId;
        setNewProjectName('');
        await initProject(newId);
        toast.success(t('common.success'));
        setIsProjectOpen(false);
        return true;
    };

    const deleteProject = async () => {
        if (!currentProject) return;
        const dictDb = await Database.load('sqlite:dictionary.db');
        await dictDb.execute('DELETE FROM dictionary WHERE project_id = $1', [currentProject.id]);
        await dictDb.execute('VACUUM');
        const projectDb = await Database.load('sqlite:project.db');
        await projectDb.execute('DELETE FROM project WHERE id = $1', [currentProject.id]);
        setCurrentProject(null);
        await initProject();
        toast.success(t('common.success'));
        setIsDeleteProjectOpen(false);
    };

    const exportCSV = async () => {
        if (!currentProject) return;
        try {
            const db = await Database.load('sqlite:dictionary.db');
            const data = await db.select('SELECT key, value FROM dictionary WHERE project_id = $1', [currentProject.id]);
            if (data.length === 0) return;
            const csvContent = data.map(row => {
                const escapedKey = row.key.replace(/"/g, '""');
                const escapedValue = row.value.replace(/"/g, '""');
                return `"${escapedKey}","${escapedValue}"`;
            }).join('\n');
            const filePath = await save({ filters: [{ name: 'CSV', extensions: ['csv'] }], defaultPath: `${currentProject.name}_dictionary.csv` });
            if (filePath) {
                await writeTextFile(filePath, csvContent);
                toast.success(t('common.success'));
            }
        } catch (error) {
            console.error('Export failed:', error);
            toast.error('Export failed');
        }
    };

    const importCSV = async () => {
        if (!currentProject) return;
        try {
            const selected = await open({ filters: [{ name: 'CSV', extensions: ['csv'] }], multiple: false });
            if (!selected) return;
            const content = await readTextFile(selected);
            const lines = content.split(/\r?\n/);
            const newData = [];
            for (const line of lines) {
                if (!line.trim()) continue;
                const regex = /("(?:[^"]|"")*"|[^,]+)/g;
                let match;
                const row = [];
                while ((match = regex.exec(line)) !== null) {
                    let field = match[0];
                    if (field.startsWith('"') && field.endsWith('"')) field = field.slice(1, -1).replace(/""/g, '"');
                    row.push(field);
                }
                if (row.length >= 2) newData.push({ key: row[0].trim(), value: row[1].trim() });
            }
            if (newData.length > 0) {
                const db = await Database.load('sqlite:dictionary.db');
                await db.execute('DELETE FROM dictionary WHERE project_id = $1', [currentProject.id]);
                const uniqueData = [];
                const keys = new Set();
                const duplicateRows = [];
                let rowCount = 0;
                for (const item of newData) {
                    rowCount++;
                    if (!keys.has(item.key)) { keys.add(item.key); uniqueData.push(item); } else { duplicateRows.push(rowCount); }
                }
                for (const item of uniqueData) {
                    await db.execute('INSERT INTO dictionary (key, value, timestamp, project_id) VALUES ($1, $2, $3, $4)', [item.key, item.value, Date.now(), currentProject.id]);
                }
                await getData();
                const countResult = await db.select('SELECT COUNT(*) FROM dictionary WHERE project_id = $1', [currentProject.id]);
                setTotal(countResult[0]?.['COUNT(*)'] || 0);
                if (duplicateRows.length > 0) toast.success(t('config.dictionary.import_duplicate_summary').replace('$1', duplicateRows.join(', ')), { duration: 5000 });
                else toast.success(t('common.success'));
            }
        } catch (error) { console.error('Import failed:', error); toast.error('Import failed'); }
    };

    const formatDate = (date) => {
        function padTo2Digits(num) { return num.toString().padStart(2, '0'); }
        const year = date.getFullYear().toString().slice(2, 4);
        const month = padTo2Digits(date.getMonth() + 1);
        const day = padTo2Digits(date.getDate());
        const hour = padTo2Digits(date.getHours());
        const minute = padTo2Digits(date.getMinutes());
        const second = padTo2Digits(date.getSeconds());
        return `${year}/${month}/${day} ${hour}:${minute}:${second}`;
    };

    // Checkbox Logic
    const toggleSelectAll = (checked) => {
        if (checked) {
            const allIds = items.map(i => i.id);
            setSelectedKeys(new Set(allIds));
        } else {
            setSelectedKeys(new Set([]));
        }
    };

    const toggleSelectOne = (id, checked) => {
        const newSet = new Set(selectedKeys);
        if (checked) newSet.add(id);
        else newSet.delete(id);
        setSelectedKeys(newSet);
    };

    const isAllSelected = items.length > 0 && items.every(i => selectedKeys.has(i.id));

    return (
        <div className="flex-1 flex flex-col gap-3 relative overflow-hidden">
            <Toaster position="bottom-right" reverseOrder={false} />

            {/* Project Selection Card */}
            <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4'>
                <div className='flex justify-between flex-wrap gap-4 items-center'>
                    <div className='flex gap-4 items-center'>
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white select-none">{t('config.dictionary.project')}</h3>

                        {/* Project Select */}
                        <Dropdown
                            value={currentProject ? currentProject.id : ''}
                            onChange={(pid) => {
                                const p = projects.find(x => x.id === pid);
                                setCurrentProject(p || null);
                            }}
                            options={projects.map(p => ({ value: p.id, label: p.name }))}
                            className="w-[200px]"
                        />

                        {currentProject && (
                            <button
                                type="button"
                                className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2.5 text-center inline-flex items-center gap-2 dark:bg-red-500 dark:hover:bg-red-600 dark:focus:ring-red-800 transition-colors"
                                onClick={() => setIsDeleteProjectOpen(true)}
                                title={t('config.dictionary.delete_project')}
                            >
                                <DeleteIcon className="text-base shrink-0" />
                                <span className="hidden lg:inline whitespace-nowrap">{t('config.dictionary.delete_project')}</span>
                                <span className="inline lg:hidden whitespace-nowrap">Delete</span>
                            </button>
                        )}
                    </div>
                </div>
            </div>

            {/* Dictionary Table Card */}
            <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 flex-1 flex flex-col min-h-0 overflow-hidden'>
                <div className="flex flex-col gap-4 mb-4 text-sm sm:text-base">
                    <div className="flex gap-4 items-center">
                        <h3 className="select-none cursor-default font-bold text-gray-900 dark:text-white">{t('config.dictionary.label')}</h3>
                        <div className="relative">
                            <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                                <SearchIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                            </div>
                            <input
                                type="text"
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                placeholder="Search entries..."
                                value={searchQuery}
                                onChange={(e) => {
                                    setSearchQuery(e.target.value);
                                    setPage(1);
                                }}
                            />
                        </div>
                    </div>
                    <div className="flex gap-1.5 sm:gap-2 justify-start items-center flex-nowrap">
                        <button
                            className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-2 sm:px-3 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 inline-flex items-center gap-1.5 sm:gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
                            onClick={importCSV}
                            disabled={!currentProject}
                            title={t('config.dictionary.import')}
                        >
                            <ArrowUpTrayIcon className="text-base shrink-0" />
                            <span className="hidden lg:inline whitespace-nowrap">{t('config.dictionary.import')}</span>
                            <span className="inline lg:hidden whitespace-nowrap">Import</span>
                        </button>
                        <button
                            className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-2 sm:px-3 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 inline-flex items-center gap-1.5 sm:gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
                            onClick={exportCSV}
                            disabled={!currentProject}
                            title={t('config.dictionary.export')}
                        >
                            <ArrowDownTrayIcon className="text-base shrink-0" />
                            <span className="hidden lg:inline whitespace-nowrap">{t('config.dictionary.export')}</span>
                            <span className="inline lg:hidden whitespace-nowrap">Export</span>
                        </button>
                        <button
                            className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-2 sm:px-3 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 inline-flex items-center gap-1.5 sm:gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
                            onClick={() => setIsAddOpen(true)}
                            disabled={!currentProject}
                            title={t('config.dictionary.add')}
                        >
                            <PlusIcon className="text-base shrink-0" />
                            <span className="hidden lg:inline whitespace-nowrap">{t('config.dictionary.add')}</span>
                            <span className="inline lg:hidden whitespace-nowrap">Add</span>
                        </button>
                        <button
                            onClick={() => setIsClearOpen(true)}
                            className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-2 sm:px-3 py-2.5 text-center inline-flex items-center gap-1.5 sm:gap-2 dark:bg-red-500 dark:hover:bg-red-600 dark:focus:ring-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
                            disabled={!currentProject || selectedKeys.size === 0}
                            title={t('common.clear')}
                        >
                            <DeleteIcon className="text-base shrink-0" />
                            <span className="hidden lg:inline whitespace-nowrap">{t('common.clear')}</span>
                            <span className="inline lg:hidden whitespace-nowrap">Clear</span>
                        </button>
                    </div>
                </div>

                <div className={`relative overflow-x-auto shadow-sm sm:rounded-lg border border-gray-200 dark:border-gray-700 flex-1 overflow-y-auto`}>
                    <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 sticky top-0 z-10">
                            <tr>
                                <th scope="col" className="p-4">
                                    <div className="flex items-center">
                                        <input
                                            id="checkbox-all"
                                            type="checkbox"
                                            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                            checked={isAllSelected}
                                            onChange={(e) => toggleSelectAll(e.target.checked)}
                                        />
                                        <label htmlFor="checkbox-all" className="sr-only">checkbox</label>
                                    </div>
                                </th>
                                <th scope="col" className="px-6 py-3">{t('config.dictionary.key')}</th>
                                <th scope="col" className="px-6 py-3">{t('config.dictionary.value')}</th>
                                <th scope="col" className="px-6 py-3 text-right">{t('config.dictionary.time') || 'Time'}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {!currentProject ? (
                                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <td colSpan="4" className="px-6 py-4 text-center">Please select or add a project.</td>
                                </tr>
                            ) : items.length === 0 ? (
                                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <td colSpan="4" className="px-6 py-4 text-center">No Dictionary entries.</td>
                                </tr>
                            ) : (
                                items.map((item) => (
                                    <tr
                                        key={item.id}
                                        className={`${selectedKeys.has(item.id) ? 'bg-gray-50 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'} border-b dark:border-gray-700 cursor-pointer transition-colors duration-200 hover:bg-blue-50 dark:hover:bg-blue-900/20 group`}
                                        onClick={(e) => {
                                            if (e.target.type !== 'checkbox') getSelectedData(item.id);
                                        }}
                                    >
                                        <td className="w-4 p-4" onClick={(e) => e.stopPropagation()}>
                                            <div className="flex items-center">
                                                <input
                                                    id={`checkbox-${item.id}`}
                                                    type="checkbox"
                                                    className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                                    checked={selectedKeys.has(item.id)}
                                                    onChange={(e) => toggleSelectOne(item.id, e.target.checked)}
                                                />
                                                <label htmlFor={`checkbox-${item.id}`} className="sr-only">checkbox</label>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 font-bold text-gray-900 dark:text-white">
                                            {item.key}
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="truncate max-w-[300px]">{item.value}</div>
                                        </td>
                                        <td className="px-6 py-4 text-right whitespace-nowrap">
                                            {formatDate(new Date(item.timestamp))}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                <div className='mt-4 flex-none flex justify-between items-center'>
                    <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-700 dark:text-gray-400">
                            Page <span className="font-semibold text-gray-900 dark:text-white">{page}</span> of <span className="font-semibold text-gray-900 dark:text-white">{Math.ceil(total / 20) || 1}</span>
                        </span>
                        <div className="inline-flex rounded-md shadow-sm" role="group">
                            <button
                                onClick={() => setPage(p => Math.max(1, p - 1))}
                                disabled={page === 1}
                                className="px-3 py-1 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-s-lg hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-2 focus:ring-blue-700 focus:text-blue-700 dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-blue-500 dark:focus:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Prev
                            </button>
                            <button
                                onClick={() => setPage(p => Math.min(Math.ceil(total / 20) || 1, p + 1))}
                                disabled={page >= (Math.ceil(total / 20) || 1)}
                                className="px-3 py-1 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-e-lg hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-2 focus:ring-blue-700 focus:text-blue-700 dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-blue-500 dark:focus:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Next
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Simple Modal Component */}
            {isEditOpen && selectedItem && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                        <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600">
                            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Edit Entry</h3>
                            <button onClick={() => setIsEditOpen(false)} type="button" className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                                <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" /></svg>
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{t('config.dictionary.key')}</label>
                                <input type="text" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" value={selectedItem?.key || ''} onChange={(e) => setSelectItem({ ...selectedItem, key: e.target.value })} />
                            </div>
                            <div>
                                <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{t('config.dictionary.value')}</label>
                                <input type="text" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" value={selectedItem?.value || ''} onChange={(e) => setSelectItem({ ...selectedItem, value: e.target.value })} />
                            </div>
                        </div>
                        <div className="flex items-center p-4 border-t border-gray-200 rounded-b dark:border-gray-600 justify-end">
                            <button onClick={updateData} type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 transition-colors">{t('common.save')}</button>
                            <button onClick={() => setIsEditOpen(false)} type="button" className="ms-3 text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600 transition-colors">{t('common.cancel')}</button>
                        </div>
                    </div>
                </div>
            )}

            {isAddOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                        <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600">
                            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{t('config.dictionary.add')}</h3>
                            <button onClick={() => setIsAddOpen(false)} type="button" className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                                <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" /></svg>
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <input type="text" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder={t('config.dictionary.key')} value={newKey} onChange={(e) => setNewKey(e.target.value)} />
                            <input type="text" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder={t('config.dictionary.value')} value={newValue} onChange={(e) => setNewValue(e.target.value)} />
                        </div>
                        <div className="flex items-center p-4 border-t border-gray-200 rounded-b dark:border-gray-600 justify-end">
                            <button onClick={addDictionary} type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 transition-colors">{t('common.ok')}</button>
                            <button onClick={() => setIsAddOpen(false)} type="button" className="ms-3 text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600 transition-colors">{t('common.cancel')}</button>
                        </div>
                    </div>
                </div>
            )}

            {isProjectOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                        <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600">
                            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{t('config.dictionary.add_project')}</h3>
                            <button onClick={() => setIsProjectOpen(false)} type="button" className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                                <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" /></svg>
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <input type="text" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder={t('config.dictionary.project_name')} value={newProjectName} onChange={(e) => setNewProjectName(e.target.value)} />
                        </div>
                        <div className="flex items-center p-4 border-t border-gray-200 rounded-b dark:border-gray-600 justify-end">
                            <button onClick={addProject} type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 transition-colors">{t('common.ok')}</button>
                            <button onClick={() => setIsProjectOpen(false)} type="button" className="ms-3 text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600 transition-colors">{t('common.cancel')}</button>
                        </div>
                    </div>
                </div>
            )}

            {isDeleteProjectOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                        <div className="p-4 md:p-5 text-center">
                            <svg className="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                            </svg>
                            <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">{t('config.dictionary.delete_project_warn')}</h3>
                            <p className="mb-5 font-bold text-red-600">{currentProject?.name}</p>
                            <button onClick={() => { deleteProject(); setIsDeleteProjectOpen(false); }} type="button" className="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center transition-colors">
                                {t('common.ok')}
                            </button>
                            <button onClick={() => setIsDeleteProjectOpen(false)} type="button" className="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 transition-colors">
                                {t('common.cancel')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isClearOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                    <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                        <div className="p-4 md:p-5 text-center">
                            <svg className="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                            </svg>
                            <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">{t('config.dictionary.clear_warn')}</h3>
                            <button onClick={clearData} type="button" className="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center transition-colors">
                                {t('common.ok')}
                            </button>
                            <button onClick={() => setIsClearOpen(false)} type="button" className="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 transition-colors">
                                {t('common.cancel')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Floating Action Button for Add Project */}
            <button
                type="button"
                className="fixed bottom-8 right-8 w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-600/30 transition-all hover:scale-110 active:scale-95 z-[60] group"
                onClick={() => setIsProjectOpen(true)}
                title={t('config.dictionary.add_project')}
            >
                <PlusIcon className="text-3xl group-hover:rotate-90 transition-transform duration-300" />
            </button>
        </div>
    );
}
