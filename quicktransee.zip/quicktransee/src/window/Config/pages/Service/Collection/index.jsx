import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import React, { useState } from 'react';

import { useToastStyle } from '../../../../../hooks';
import SelectPluginModal from '../SelectPluginModal';
import { osType } from '../../../../../utils/env';
import { useConfig, deleteKey } from '../../../../../hooks';
import ServiceItem from './ServiceItem';
import SelectModal from './SelectModal';
import ConfigModal from './ConfigModal';

export default function Collection(props) {
    const { pluginList } = props;

    // Modal states
    const [isSelectPluginOpen, setIsSelectPluginOpen] = useState(false);
    const [isSelectOpen, setIsSelectOpen] = useState(false);
    const [isConfigOpen, setIsConfigOpen] = useState(false);

    const [currentConfigKey, setCurrentConfigKey] = useState('anki');
    // now it's service instance list
    const [collectionServiceInstanceList, setCollectionServiceInstanceList] = useConfig('collection_service_list', []);

    const { t } = useTranslation();
    const toastStyle = useToastStyle();

    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };
    const onDragEnd = async (result) => {
        if (!result.destination) return;
        const items = reorder(collectionServiceInstanceList, result.source.index, result.destination.index);
        setCollectionServiceInstanceList(items);
    };

    const deleteServiceInstance = (instanceKey) => {
        if (collectionServiceInstanceList.length === 1) {
            toast.error(t('config.service.least'), { style: toastStyle });
            return;
        } else {
            setCollectionServiceInstanceList(collectionServiceInstanceList.filter((x) => x !== instanceKey));
            deleteKey(instanceKey);
        }
    };
    const updateServiceInstanceList = (instanceKey) => {
        if (collectionServiceInstanceList.includes(instanceKey)) {
            return;
        } else {
            const newList = [...collectionServiceInstanceList, instanceKey];
            setCollectionServiceInstanceList(newList);
        }
    };

    return (
        <>
            <Toaster />
            <div
                className="h-full p-5 flex flex-col bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
            >
                <div className="flex-1 overflow-y-auto min-h-0">
                    <DragDropContext onDragEnd={onDragEnd}>
                        <Droppable
                            droppableId='droppable'
                            direction='vertical'
                        >
                            {(provided) => (
                                <div
                                    className='flex flex-col gap-2'
                                    ref={provided.innerRef}
                                    {...provided.droppableProps}
                                >
                                    {collectionServiceInstanceList !== null &&
                                        collectionServiceInstanceList.map((x, i) => {
                                            return (
                                                <Draggable
                                                    key={x}
                                                    draggableId={x}
                                                    index={i}
                                                >
                                                    {(provided) => {
                                                        return (
                                                            <div
                                                                ref={provided.innerRef}
                                                                {...provided.draggableProps}
                                                            >
                                                                <ServiceItem
                                                                    {...provided.dragHandleProps}
                                                                    serviceInstanceKey={x}
                                                                    key={x}
                                                                    pluginList={pluginList}
                                                                    deleteServiceInstance={deleteServiceInstance}
                                                                    setCurrentConfigKey={setCurrentConfigKey}
                                                                    onConfigOpen={() => setIsConfigOpen(true)}
                                                                />
                                                            </div>
                                                        );
                                                    }}
                                                </Draggable>
                                            );
                                        })}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </DragDropContext>
                </div>

                <div className='flex gap-2 mt-4 flex-none'>
                    <button
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 w-full"
                        onClick={() => setIsSelectOpen(true)}
                    >
                        {t('config.service.add_builtin_service')}
                    </button>
                    <button
                        className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700 w-full"
                        onClick={() => setIsSelectPluginOpen(true)}
                    >
                        {t('config.service.add_external_service')}
                    </button>
                </div>
            </div>
            <SelectPluginModal
                isOpen={isSelectPluginOpen}
                onOpenChange={setIsSelectPluginOpen}
                setCurrentConfigKey={setCurrentConfigKey}
                onConfigOpen={() => setIsConfigOpen(true)}
                pluginType='collection'
                pluginList={pluginList}
                deleteService={deleteServiceInstance}
            />
            <SelectModal
                isOpen={isSelectOpen}
                onOpenChange={setIsSelectOpen}
                setCurrentConfigKey={setCurrentConfigKey}
                onConfigOpen={() => setIsConfigOpen(true)}
            />
            <ConfigModal
                serviceInstanceKey={currentConfigKey}
                isOpen={isConfigOpen}
                pluginList={pluginList}
                onOpenChange={setIsConfigOpen}
                updateServiceInstanceList={updateServiceInstanceList}
            />
        </>
    );
}
