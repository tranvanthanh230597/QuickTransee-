import { useTranslation } from 'react-i18next';
import React from 'react';

import { createServiceInstanceKey } from '../../../../../../utils/service_instance';
import * as builtinServices from '../../../../../../services/collection';

export default function SelectModal(props) {
    const { isOpen, onOpenChange, setCurrentConfigKey, onConfigOpen } = props;
    const { t } = useTranslation();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
            <div className="relative w-full max-w-md max-h-[90vh] flex flex-col bg-white rounded-lg shadow dark:bg-gray-700">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600 flex-none">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                        {t('config.service.add_service')}
                    </h3>
                    <button
                        type="button"
                        className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        onClick={() => onOpenChange(false)}
                    >
                        <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span className="sr-only">Close modal</span>
                    </button>
                </div>

                {/* Body - Scrollable */}
                <div className="p-4 space-y-2 overflow-y-auto flex-1 min-h-0">
                    {Object.keys(builtinServices).map((x) => (
                        <button
                            key={x}
                            className="w-full flex items-center p-3 text-base font-bold text-gray-900 rounded-lg bg-gray-50 hover:bg-gray-100 group hover:shadow dark:bg-gray-600 dark:hover:bg-gray-500 dark:text-white transition-all border border-gray-200 dark:border-gray-500"
                            onClick={() => {
                                setCurrentConfigKey(createServiceInstanceKey(x));
                                onConfigOpen();
                                onOpenChange(false);
                            }}
                        >
                            <img
                                src={builtinServices[x].info.icon}
                                className='h-6 w-6 mr-3'
                                alt="icon"
                            />
                            <span className="flex-1 ms-3 whitespace-nowrap text-left">
                                {t(`services.collection.${builtinServices[x].info.name}.title`)}
                            </span>
                        </button>
                    ))}
                </div>

                {/* Footer */}
                <div className="flex items-center p-4 border-t border-gray-200 rounded-b dark:border-gray-600 justify-end flex-none">
                    <button
                        onClick={() => onOpenChange(false)}
                        type="button"
                        className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        {t('common.cancel')}
                    </button>
                </div>
            </div>
        </div>
    );
}
