import { useTranslation } from 'react-i18next';

import {
    INSTANCE_NAME_CONFIG_KEY,
    ServiceSourceType,
    getServiceName,
    getServiceSouceType,
} from '../../../../../../utils/service_instance';
import * as builtinServices from '../../../../../../services/recognize';
import { osType } from '../../../../../../utils/env';
import { useConfig } from '../../../../../../hooks';
import { EditIcon, DeleteIcon, DragIcon } from '../../../../../../components/Icons';

export default function ServiceItem(props) {
    const { serviceInstanceKey, pluginList, deleteServiceInstance, setCurrentConfigKey, onConfigOpen, ...drag } = props;
    const { t } = useTranslation();

    const [serviceInstanceConfig] = useConfig(serviceInstanceKey, {});

    const serviceSourceType = getServiceSouceType(serviceInstanceKey);
    const serviceName = getServiceName(serviceInstanceKey);

    return serviceSourceType === ServiceSourceType.PLUGIN && !(serviceName in pluginList) ? (
        <></>
    ) : (
        serviceInstanceConfig !== null && (
            <div className='bg-gray-50 dark:bg-gray-700 rounded-md px-4 py-4 flex justify-between items-center shadow-sm border border-gray-200 dark:border-gray-600'>
                <div className='flex items-center gap-4'>
                    <div
                        {...drag}
                        className='text-2xl text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 cursor-grab active:cursor-grabbing'
                    >
                        <DragIcon />
                    </div>

                    {serviceSourceType === ServiceSourceType.BUILDIN && (
                        <>
                            <img
                                src={
                                    serviceName === 'system'
                                        ? `logo/${osType}.svg`
                                        : builtinServices[serviceName].info.icon
                                }
                                className='h-6 w-6 my-auto'
                                draggable={false}
                                alt="Service Icon"
                            />
                            <h2 className='my-auto font-medium text-gray-900 dark:text-white text-base'>
                                {serviceInstanceConfig[INSTANCE_NAME_CONFIG_KEY] ||
                                    t(`services.recognize.${serviceName}.title`)}
                            </h2>
                        </>
                    )}
                    {serviceSourceType === ServiceSourceType.PLUGIN && (
                        <>
                            <img
                                src={pluginList[serviceName].icon}
                                className='h-6 w-6 my-auto'
                                draggable={false}
                                alt="Plugin Icon"
                            />
                            <h2 className='my-auto font-medium text-gray-900 dark:text-white text-base'>
                                {`${serviceInstanceConfig[INSTANCE_NAME_CONFIG_KEY] || pluginList[serviceName].display} [${t('common.plugin')}]`}
                            </h2>
                        </>
                    )}
                </div>
                <div className='flex items-center gap-1'>
                    <button
                        type="button"
                        className="p-1.5 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors text-gray-500 dark:text-gray-400"
                        onClick={() => {
                            setCurrentConfigKey(serviceInstanceKey);
                            onConfigOpen();
                        }}
                        title={t('common.edit')}
                    >
                        <EditIcon className='w-5 h-5' />
                    </button>
                    <button
                        type="button"
                        className="p-1.5 text-red-500 hover:bg-red-100 dark:text-red-400 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                        onClick={() => {
                            deleteServiceInstance(serviceInstanceKey);
                        }}
                        title={t('common.delete')}
                    >
                        <DeleteIcon className='w-5 h-5' />
                    </button>
                </div>
            </div>
        )
    );
}
