import { readDir, BaseDirectory, readTextFile, exists } from '@tauri-apps/api/fs';
import { listen } from '@tauri-apps/api/event';
import { useTranslation } from 'react-i18next';
import { appConfigDir, join } from '@tauri-apps/api/path';
import { convertFileSrc } from '@tauri-apps/api/tauri';
import React, { useEffect, useState } from 'react';
import Translate from './Translate';
import Recognize from './Recognize';
import Collection from './Collection';
import Tts from './Tts';
import { ServiceType } from '../../../../utils/service_instance';
import { initFlowbite } from 'flowbite';

let unlisten = null;

export default function Service() {
    const [pluginList, setPluginList] = useState(null);
    const [activeTab, setActiveTab] = useState('translate');
    const { t } = useTranslation();

    const loadPluginList = async () => {
        const serviceTypeList = ['translate', 'tts', 'recognize', 'collection'];
        let temp = {};
        for (const serviceType of serviceTypeList) {
            temp[serviceType] = {};
            if (await exists(`plugins/${serviceType}`, { dir: BaseDirectory.AppConfig })) {
                const plugins = await readDir(`plugins/${serviceType}`, { dir: BaseDirectory.AppConfig });
                for (const plugin of plugins) {
                    const infoStr = await readTextFile(`plugins/${serviceType}/${plugin.name}/info.json`, {
                        dir: BaseDirectory.AppConfig,
                    });
                    let pluginInfo = JSON.parse(infoStr);
                    if ('icon' in pluginInfo) {
                        const appConfigDirPath = await appConfigDir();
                        const iconPath = await join(
                            appConfigDirPath,
                            `/plugins/${serviceType}/${plugin.name}/${pluginInfo.icon}`
                        );
                        pluginInfo.icon = convertFileSrc(iconPath);
                    }
                    temp[serviceType][plugin.name] = pluginInfo;
                }
            }
        }
        setPluginList({ ...temp });
    };

    useEffect(() => {
        loadPluginList();
        if (unlisten) {
            unlisten.then((f) => {
                f();
            });
        }
        unlisten = listen('reload_plugin_list', loadPluginList);

        // Init flowbite
        setTimeout(() => initFlowbite(), 100);

        return () => {
            if (unlisten) {
                unlisten.then((f) => {
                    f();
                });
            }
        };
    }, []);

    const tabs = [
        { id: 'translate', label: t('config.service.translate') },
        { id: 'recognize', label: t('config.service.recognize') },
        { id: 'tts', label: t('config.service.tts') },
        { id: 'collection', label: t('config.service.collection') },
    ];

    return (
        pluginList !== null && (
            <div className="flex flex-col h-full">
                <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
                    <ul className="flex flex-wrap -mb-px text-sm font-medium text-center justify-center text-gray-500 dark:text-gray-400">
                        {tabs.map((tab) => (
                            <li key={tab.id} className="me-2">
                                <button
                                    onClick={() => setActiveTab(tab.id)}
                                    className={`inline-block p-4 border-b-2 rounded-t-lg ${activeTab === tab.id
                                        ? 'text-blue-600 border-blue-600 dark:text-blue-500 dark:border-blue-500'
                                        : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'
                                        }`}
                                >
                                    {tab.label}
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="flex-1 overflow-hidden p-1 flex flex-col">
                    {activeTab === 'translate' && <Translate pluginList={pluginList[ServiceType.TRANSLATE]} />}
                    {activeTab === 'recognize' && <Recognize pluginList={pluginList[ServiceType.RECOGNIZE]} />}
                    {activeTab === 'tts' && <Tts pluginList={pluginList[ServiceType.TTS]} />}
                    {activeTab === 'collection' && <Collection pluginList={pluginList[ServiceType.COLLECTION]} />}
                </div>
            </div>
        )
    );
}
