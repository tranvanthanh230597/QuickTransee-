import { useTranslation } from 'react-i18next';
import React from 'react';

import * as builtinServices from '../../../../../../services/tts';
import { PluginConfig } from '../../PluginConfig';
import { ServiceSourceType, getServiceName, getServiceSouceType, whetherPluginService } from '../../../../../../utils/service_instance';

export default function ConfigModal(props) {
    const { serviceInstanceKey, pluginList, isOpen, onOpenChange, updateServiceInstanceList } = props;

    const serviceSourceType = getServiceSouceType(serviceInstanceKey)
    const pluginServiceFlag = whetherPluginService(serviceInstanceKey)
    const serviceName = getServiceName(serviceInstanceKey)

    const { t } = useTranslation();
    const ConfigComponent = pluginServiceFlag ? PluginConfig : builtinServices[serviceName]?.Config;

    if (!isOpen) return null;
    if (pluginServiceFlag && !(serviceName in pluginList)) return null;
    if (!ConfigComponent) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
            <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-white rounded-lg shadow dark:bg-gray-700">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600 flex-none">
                    <div className="flex items-center gap-2">
                        {serviceSourceType === ServiceSourceType.BUILDIN && builtinServices[serviceName] && (
                            <>
                                <img
                                    src={builtinServices[serviceName].info.icon}
                                    className='h-6 w-6 select-none'
                                    draggable={false}
                                    alt="icon"
                                />
                                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                                    {t(`services.tts.${serviceName}.title`)}
                                </h3>
                            </>
                        )}
                        {pluginServiceFlag && pluginList && pluginList[serviceName] && (
                            <>
                                <img
                                    src={pluginList[serviceName].icon}
                                    className='h-6 w-6 select-none'
                                    draggable={false}
                                    alt="icon"
                                />
                                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                                    {`${pluginList[serviceName].display} [${t('common.plugin')}]`}
                                </h3>
                            </>
                        )}
                    </div>
                    <button
                        type="button"
                        className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        onClick={() => onOpenChange(false)}
                    >
                        <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span className="sr-only">Close modal</span>
                    </button>
                </div>

                {/* Body */}
                <div className="flex-1 overflow-hidden min-h-0 flex flex-col">
                    <ConfigComponent
                        name={serviceName}
                        instanceKey={serviceInstanceKey}
                        pluginType='tts'
                        pluginList={pluginList}
                        updateServiceList={updateServiceInstanceList}
                        onClose={() => onOpenChange(false)}
                    />
                </div>
            </div>
        </div>
    );
}
