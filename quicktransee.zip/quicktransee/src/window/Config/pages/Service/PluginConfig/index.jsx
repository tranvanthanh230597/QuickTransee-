import { INSTANCE_NAME_CONFIG_KEY } from '../../../../../utils/service_instance';
import { useTranslation } from 'react-i18next';
import { open as openInBrowser } from '@tauri-apps/api/shell';
import React from 'react';

import { useConfig } from '../../../../../hooks';
import Dropdown from '../../../../../components/Dropdown';

export function PluginConfig(props) {
    const { instanceKey, updateServiceList, onClose, name, pluginList } = props;
    const [pluginConfig, setPluginConfig] = useConfig(instanceKey, {}, { sync: false });
    const { t } = useTranslation();

    return (
        <div className="flex flex-col overflow-hidden h-full">
            <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                <div className='flex justify-between items-center'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white select-none cursor-default'>
                        {t('config.service.homepage')}
                    </h3>
                    <button
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                        onClick={() => {
                            openInBrowser(pluginList[name].homepage);
                        }}
                    >
                        {t('config.service.homepage')}
                    </button>
                </div>
                {pluginConfig && (
                    <div className='flex justify-between items-center'>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white my-auto">
                            {t('services.instance_name')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[250px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={pluginConfig[INSTANCE_NAME_CONFIG_KEY] ?? pluginList[name].display}
                            onChange={(e) => {
                                setPluginConfig({
                                    ...pluginConfig,
                                    [INSTANCE_NAME_CONFIG_KEY]: e.target.value,
                                });
                            }}
                        />
                    </div>
                )}

                {pluginList[name].needs.length === 0 ? (
                    <div className="text-gray-500 dark:text-gray-400">{t('services.no_need')}</div>
                ) : (
                    pluginList[name].needs.map((x) => {
                        return (
                            pluginConfig &&
                            (x.type ? (
                                <div
                                    key={x.key}
                                    className='flex justify-between items-center'
                                >
                                    <h3 className='text-sm font-medium text-gray-900 dark:text-white select-none cursor-default'>
                                        {x.display}
                                    </h3>
                                    {x.type === 'input' && (
                                        <input
                                            type="text"
                                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[250px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            value={`${pluginConfig.hasOwnProperty(x.key) ? pluginConfig[x.key] : ''}`}
                                            onChange={(e) => {
                                                setPluginConfig({
                                                    ...pluginConfig,
                                                    [x.key]: e.target.value,
                                                });
                                            }}
                                        />
                                    )}
                                    {x.type === 'select' && (
                                        <Dropdown
                                            value={pluginConfig.hasOwnProperty(x.key) ? pluginConfig[x.key] : Object.keys(x.options)[0]}
                                            onChange={(val) => {
                                                setPluginConfig({
                                                    ...pluginConfig,
                                                    [x.key]: val,
                                                });
                                            }}
                                            options={Object.keys(x.options).map(y => ({ value: y, label: x.options[y] }))}
                                            className="w-[250px]"
                                        />
                                    )}
                                </div>
                            ) : (
                                <div
                                    key={x.key}
                                    className='flex justify-between items-center'
                                >
                                    <h3 className='text-sm font-medium text-gray-900 dark:text-white select-none cursor-default'>
                                        {x.display}
                                    </h3>
                                    <input
                                        type="text"
                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[250px] p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        value={`${pluginConfig.hasOwnProperty(x.key) ? pluginConfig[x.key] : ''}`}
                                        onChange={(e) => {
                                            setPluginConfig({
                                                ...pluginConfig,
                                                [x.key]: e.target.value,
                                            });
                                        }}
                                    />
                                </div>
                            ))
                        );
                    })
                )}
            </div>

            <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                <button
                    className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 transition-all"
                    onClick={() => {
                        setPluginConfig(pluginConfig, true);
                        updateServiceList(instanceKey);
                        onClose();
                    }}
                >
                    {t('common.save')}
                </button>
                <button
                    onClick={onClose}
                    type="button"
                    className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                >
                    {t('common.cancel')}
                </button>
            </div>
        </div>
    );
}
