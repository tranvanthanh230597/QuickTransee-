import { appLogDir, appConfigDir } from '@tauri-apps/api/path';
import { useTranslation } from 'react-i18next';
import { open } from '@tauri-apps/api/shell';
import { invoke } from '@tauri-apps/api/tauri';
import { initFlowbite } from 'flowbite';
import React, { useEffect } from 'react';

import { appVersion } from '../../../../utils/env';

export default function About() {
    const { t } = useTranslation();
    useEffect(() => {
        initFlowbite();
    }, []);

    const buttonClass = "flex-1 text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:text-blue-600 dark:hover:text-blue-400 font-medium rounded-lg text-sm px-4 py-2.5 transition-all duration-200 text-center border border-transparent hover:border-blue-100 dark:hover:border-blue-900/30";

    return (
        <div className='flex-1 flex flex-col min-h-0 overflow-hidden'>
            <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 flex-1 flex flex-col justify-center items-center overflow-y-auto no-scrollbar-on-hover'>
                <div className='max-w-md w-full px-8 flex flex-col items-center'>
                    {/* Logo */}
                    <img
                        src='icon.png'
                        className='h-16 sm:h-20'
                        draggable={false}
                    />

                    {/* App Info */}
                    <div className='mb-6 text-center'>
                        <h1 className='font-bold text-xl sm:text-2xl text-gray-900 dark:text-white'>QuickTransee</h1>
                        <p className='text-xs text-gray-500 dark:text-gray-400'>{appVersion}</p>
                    </div>

                    {/* Buttons Section */}
                    <div className='w-full'>
                        <div className='flex flex-col sm:flex-row gap-2 justify-center'>
                            <button
                                className={buttonClass}
                                onClick={() => {
                                    invoke('updater_window');
                                }}
                            >
                                <span className="whitespace-nowrap">{t('config.about.check_update')}</span>
                            </button>
                            <button
                                className={buttonClass}
                                onClick={async () => {
                                    const dir = await appLogDir();
                                    open(dir);
                                }}
                            >
                                <span className="whitespace-nowrap">{t('config.about.view_log')}</span>
                            </button>
                            <button
                                className={buttonClass}
                                onClick={async () => {
                                    const dir = await appConfigDir();
                                    open(dir);
                                }}
                            >
                                <span className="whitespace-nowrap">{t('config.about.view_config')}</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
