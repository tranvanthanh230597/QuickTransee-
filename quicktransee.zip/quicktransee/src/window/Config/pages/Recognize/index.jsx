import { useTranslation } from 'react-i18next';

import React, { useEffect } from 'react';

import { LanguageFlag, languageList } from '../../../../utils/language';
import { useConfig } from '../../../../hooks';
import Dropdown from '../../../../components/Dropdown';

export default function Recognize() {
    const [recognizeLanguage, setRecognizeLanguage] = useConfig('recognize_language', 'auto');
    const [deleteNewline, setDeleteNewline] = useConfig('recognize_delete_newline', false);
    const [autoCopy, setAutoCopy] = useConfig('recognize_auto_copy', false);
    const [hideWindow, setHideWindow] = useConfig('recognize_hide_window', false);
    const [closeOnBlur, setCloseOnBlur] = useConfig('recognize_close_on_blur', false);
    const { t } = useTranslation();



    return (
        <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5'>
            {/* Recognize Language */}
            {/* Recognize Language */}
            <div className='flex justify-between items-center mb-4'>
                <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.recognize.language')}</h3>
                <Dropdown
                    value={recognizeLanguage || 'auto'}
                    onChange={(val) => setRecognizeLanguage(val)}
                    options={[
                        { value: 'auto', label: t('languages.auto') },
                        ...languageList.map(item => ({ value: item, label: t(`languages.${item}`) }))
                    ]}
                    className="w-[200px]"
                    showSearch={true}
                />
            </div>

            {/* Delete Newline */}
            {/* Delete Newline */}
            <div className='flex justify-between items-center mb-4'>
                <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.recognize.delete_newline')}</h3>
                {deleteNewline !== null && (
                    <label className='inline-flex items-center cursor-pointer'>
                        <input
                            type='checkbox'
                            checked={deleteNewline}
                            onChange={(e) => setDeleteNewline(e.target.checked)}
                            className='sr-only peer'
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                )}
            </div>

            {/* Auto Copy */}
            {/* Auto Copy */}
            <div className='flex justify-between items-center mb-4'>
                <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.recognize.auto_copy')}</h3>
                {autoCopy !== null && (
                    <label className='inline-flex items-center cursor-pointer'>
                        <input
                            type='checkbox'
                            checked={autoCopy}
                            onChange={(e) => setAutoCopy(e.target.checked)}
                            className='sr-only peer'
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                )}
            </div>

            {/* Close On Blur */}
            {/* Close On Blur */}
            <div className='flex justify-between items-center mb-4'>
                <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.recognize.close_on_blur')}</h3>
                {closeOnBlur !== null && (
                    <label className='inline-flex items-center cursor-pointer'>
                        <input
                            type='checkbox'
                            checked={closeOnBlur}
                            onChange={(e) => setCloseOnBlur(e.target.checked)}
                            className='sr-only peer'
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                )}
            </div>

            {/* Hide Window */}
            {/* Hide Window */}
            <div className='flex justify-between items-center mb-0'>
                <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.recognize.hide_window')}</h3>
                {hideWindow !== null && (
                    <label className='inline-flex items-center cursor-pointer'>
                        <input
                            type='checkbox'
                            checked={hideWindow}
                            onChange={(e) => setHideWindow(e.target.checked)}
                            className='sr-only peer'
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                )}
            </div>
        </div>
    );
}
