import { useTranslation } from 'react-i18next';

import React, { useEffect } from 'react';

import { LanguageFlag, languageList } from '../../../../utils/language';
import { useConfig } from '../../../../hooks/useConfig';
import { invoke } from '@tauri-apps/api/tauri';
import Dropdown from '../../../../components/Dropdown';

export default function Translate() {
    const [sourceLanguage, setSourceLanguage] = useConfig('translate_source_language', 'auto');
    const [targetLanguage, setTargetLanguage] = useConfig('translate_target_language', 'vi');
    const [secondLanguage, setSecondLanguage] = useConfig('translate_second_language', 'vi');
    const [detectEngine, setDetectEngine] = useConfig('translate_detect_engine', 'google');
    const [autoCopy, setAutoCopy] = useConfig('translate_auto_copy', 'disable');
    const [incrementalTranslate, setIncrementalTranslate] = useConfig('incremental_translate', false);
    const [historyDisable, setHistoryDisable] = useConfig('history_disable', false);
    const [dynamicTranslate, setDynamicTranslate] = useConfig('dynamic_translate', false);
    const [deleteNewline, setDeleteNewline] = useConfig('translate_delete_newline', false);
    const [rememberLanguage, setRememberLanguage] = useConfig('translate_remember_language', false);
    const [windowPosition, setWindowPosition] = useConfig('translate_window_position', 'mouse');
    const [rememberWindowSize, setRememberWindowSize] = useConfig('translate_remember_window_size', false);
    const [hideSource, setHideSource] = useConfig('hide_source', false);
    const [hideLanguage, setHideLanguage] = useConfig('hide_language', false);
    const [hideWindow, setHideWindow] = useConfig('translate_hide_window', false);
    const [closeOnBlur, setCloseOnBlur] = useConfig('translate_close_on_blur', true);
    const [alwaysOnTop, setAlwaysOnTop] = useConfig('translate_always_on_top', false);
    const { t } = useTranslation();



    return (
        <>
            {/* Language Settings Card */}
            <div className='mb-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5'>
                {/* Source Language */}
                {/* Source Language */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.source_language')}</h3>
                    <Dropdown
                        value={sourceLanguage || 'auto'}
                        onChange={(val) => setSourceLanguage(val)}
                        options={[
                            { value: 'auto', label: t('languages.auto') },
                            ...languageList.map(item => ({ value: item, label: t(`languages.${item}`) }))
                        ]}
                        className="w-[200px]"
                        showSearch={true}
                    />
                </div>

                {/* Target Language */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.target_language')}</h3>
                    <Dropdown
                        value={targetLanguage || 'vi'}
                        onChange={(val) => setTargetLanguage(val)}
                        options={languageList.map(item => ({ value: item, label: t(`languages.${item}`) }))}
                        className="w-[200px]"
                        showSearch={true}
                    />
                </div>

                {/* Second Language */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.second_language')}</h3>
                    <Dropdown
                        value={secondLanguage || 'vi'}
                        onChange={(val) => setSecondLanguage(val)}
                        options={languageList.map(item => ({ value: item, label: t(`languages.${item}`) }))}
                        className="w-[200px]"
                        showSearch={true}
                    />
                </div>

                {/* Detect Engine */}
                <div className='flex justify-between items-center'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.detect_engine')}</h3>
                    <Dropdown
                        value={detectEngine || 'google'}
                        onChange={(val) => setDetectEngine(val)}
                        options={[
                            { value: 'google', label: t('config.translate.google') },
                            { value: 'bing', label: t('config.translate.bing') }
                        ]}
                        className="w-[200px]"
                    />
                </div>
            </div>

            {/* Translation Options Card */}
            <div className='mb-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5'>
                {/* Auto Copy */}
                {/* Auto Copy */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.auto_copy')}</h3>
                    <Dropdown
                        value={autoCopy || 'disable'}
                        onChange={(val) => {
                            setAutoCopy(val);
                            invoke('update_tray', { language: '', copyMode: val });
                        }}
                        options={[
                            { value: 'source', label: t('config.translate.source') },
                            { value: 'target', label: t('config.translate.target') },
                            { value: 'source_target', label: t('config.translate.source_target') },
                            { value: 'disable', label: t('config.translate.disable') }
                        ]}
                        className="w-[200px]"
                    />
                </div>

                {/* History Disable */}
                {/* History Disable */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.history_disable')}</h3>
                    {historyDisable !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={historyDisable}
                                onChange={(e) => setHistoryDisable(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Incremental Translate */}
                {/* Incremental Translate */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.incremental_translate')}</h3>
                    {incrementalTranslate !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={incrementalTranslate}
                                onChange={(e) => setIncrementalTranslate(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Dynamic Translate */}
                {/* Dynamic Translate */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.dynamic_translate')}</h3>
                    {dynamicTranslate !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={dynamicTranslate}
                                onChange={(e) => setDynamicTranslate(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Delete Newline */}
                {/* Delete Newline */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.delete_newline')}</h3>
                    {deleteNewline !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={deleteNewline}
                                onChange={(e) => setDeleteNewline(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Remember Language */}
                {/* Remember Language */}
                <div className='flex justify-between items-center mb-0'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.remember_language')}</h3>
                    {rememberLanguage !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={rememberLanguage}
                                onChange={(e) => setRememberLanguage(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>
            </div>

            {/* Window Settings Card */}
            <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5'>
                {/* Window Position */}
                {/* Window Position */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto min-w-[120px]'>{t('config.translate.window_position')}</h3>
                    <Dropdown
                        value={windowPosition || 'mouse'}
                        onChange={(val) => setWindowPosition(val)}
                        options={[
                            { value: 'mouse', label: t('config.translate.mouse') },
                            { value: 'pre_state', label: t('config.translate.pre_state') }
                        ]}
                        className="w-[200px]"
                    />
                </div>

                {/* Remember Window Size */}
                {/* Remember Window Size */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.remember_window_size')}</h3>
                    {rememberWindowSize !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={rememberWindowSize}
                                onChange={(e) => setRememberWindowSize(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Close On Blur */}
                {/* Close On Blur */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.close_on_blur')}</h3>
                    {closeOnBlur !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={closeOnBlur}
                                onChange={(e) => setCloseOnBlur(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Always On Top */}
                {/* Always On Top */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.always_on_top')}</h3>
                    {alwaysOnTop !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={alwaysOnTop}
                                onChange={(e) => setAlwaysOnTop(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Hide Source */}
                {/* Hide Source */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.hide_source')}</h3>
                    {hideSource !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={hideSource}
                                onChange={(e) => setHideSource(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Hide Language */}
                {/* Hide Language */}
                <div className='flex justify-between items-center mb-4'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.hide_language')}</h3>
                    {hideLanguage !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={hideLanguage}
                                onChange={(e) => setHideLanguage(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>

                {/* Hide Window */}
                {/* Hide Window */}
                <div className='flex justify-between items-center mb-0'>
                    <h3 className='text-sm font-medium text-gray-900 dark:text-white my-auto'>{t('config.translate.hide_window')}</h3>
                    {hideWindow !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={hideWindow}
                                onChange={(e) => setHideWindow(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>
            </div>
        </>
    );
}
