import { readDir, BaseDirectory, readTextFile, exists } from '@tauri-apps/api/fs';
import { appConfigDir, join } from '@tauri-apps/api/path';
import { convertFileSrc } from '@tauri-apps/api/tauri';
import { useEffect, useState } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import Database from 'tauri-plugin-sql-api';
import { DeleteIcon } from '../../../../components/Icons';
import 'flag-icons/css/flag-icons.min.css';

import * as builtinCollectionServices from '../../../../services/collection';
import { invoke_plugin } from '../../../../utils/invoke_plugin';
import * as builtinServices from '../../../../services/translate';
import { useConfig, useToastStyle } from '../../../../hooks';
import { LanguageFlag } from '../../../../utils/language';
import { store } from '../../../../utils/store';
import { osType } from '../../../../utils/env';
import {
    ServiceSourceType,
    ServiceType,
    getServiceName,
    getServiceSouceType,
    whetherAvailableService,
} from '../../../../utils/service_instance';

export default function History() {
    const [collectionServiceList] = useConfig('collection_service_list', []);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);
    const [pluginList, setPluginList] = useState(null);
    const [selectedItem, setSelectItem] = useState(null);
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [items, setItems] = useState([]);
    const toastStyle = useToastStyle();
    const { t } = useTranslation();

    useEffect(() => {
        init();
        loadPluginList();
    }, []);

    useEffect(() => {
        getData();
    }, [total, page]);

    const init = async () => {
        const db = await Database.load('sqlite:history.db');
        const result = await db.select('SELECT COUNT(*) FROM history');
        if (result[0] && result[0]['COUNT(*)']) {
            setTotal(result[0]['COUNT(*)']);
        }
    };
    const getData = async () => {
        const db = await Database.load('sqlite:history.db');
        let result = await db.select('SELECT * FROM history ORDER BY id DESC LIMIT 20 OFFSET $1', [20 * (page - 1)]);
        setItems(result);
    };

    const getSelectedData = async (id) => {
        const db = await Database.load('sqlite:history.db');
        let result = await db.select('SELECT * FROM history WHERE id=$1', [id]);
        setSelectItem(result[0]);
        setIsModalOpen(true);
    };
    const clearData = async () => {
        const db = await Database.load('sqlite:history.db');
        await db.execute('DROP TABLE history');
        await db.execute('VACUUM');
        setItems([]);
        setTotal(0);
        setPage(1);
        toast.success(t('common.success'));
        setIsClearConfirmOpen(false);
    };
    const updateData = async () => {
        const db = await Database.load('sqlite:history.db');
        await db.execute('UPDATE history SET text=$1, result=$2 WHERE id=$3', [
            selectedItem.text,
            selectedItem.result,
            selectedItem.id,
        ]);
        await getData();
        toast.success(t('common.success'));
    };

    const formatDate = (date) => {
        function padTo2Digits(num) {
            return num.toString().padStart(2, '0');
        }
        const year = date.getFullYear().toString().slice(2, 4);
        const month = padTo2Digits(date.getMonth() + 1);
        const day = padTo2Digits(date.getDate());
        const hour = padTo2Digits(date.getHours());
        const minute = padTo2Digits(date.getMinutes());
        const second = padTo2Digits(date.getSeconds());
        return `${year}/${month}/${day} ${hour}:${minute}:${second}`;
    };
    const loadPluginList = async () => {
        const serviceTypeList = ['translate', 'collection'];
        let temp = {};
        for (const serviceType of serviceTypeList) {
            temp[serviceType] = {};
            if (await exists(`plugins/${serviceType}`, { dir: BaseDirectory.AppConfig })) {
                const plugins = await readDir(`plugins/${serviceType}`, { dir: BaseDirectory.AppConfig });
                for (const plugin of plugins) {
                    const infoStr = await readTextFile(`plugins/${serviceType}/${plugin.name}/info.json`, {
                        dir: BaseDirectory.AppConfig,
                    });
                    let pluginInfo = JSON.parse(infoStr);
                    if ('icon' in pluginInfo) {
                        const appConfigDirPath = await appConfigDir();
                        const iconPath = await join(
                            appConfigDirPath,
                            `/plugins/${serviceType}/${plugin.name}/${pluginInfo.icon}`
                        );
                        pluginInfo.icon = convertFileSrc(iconPath);
                    }
                    temp[serviceType][plugin.name] = pluginInfo;
                }
            }
        }
        setPluginList({ ...temp });
    };

    const totalPages = Math.ceil(total / 20);

    return (
        pluginList !== null && (
            <div className='flex-1 flex flex-col min-h-0 overflow-hidden'>
                <Toaster position="bottom-right" reverseOrder={false} />

                <div className='bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 flex-1 flex flex-col min-h-0 overflow-hidden'>
                    {/* Table Container */}
                    <div className="relative overflow-x-auto shadow-sm sm:rounded-lg border border-gray-200 dark:border-gray-700 flex-1 overflow-y-auto min-h-0">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 sticky top-0 z-10">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Service</th>
                                    <th scope="col" className="px-6 py-3">Text</th>
                                    <th scope="col" className="px-6 py-3">Source</th>
                                    <th scope="col" className="px-6 py-3">Target</th>
                                    <th scope="col" className="px-6 py-3">Result</th>
                                    <th scope="col" className="px-6 py-3">Timestamp</th>
                                </tr>
                            </thead>
                            <tbody>
                                {items.length === 0 ? (
                                    <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                        <td colSpan="6" className="px-6 py-4 text-center">No History to display.</td>
                                    </tr>
                                ) : (
                                    items.map((item) => (
                                        whetherAvailableService(item.service, {
                                            [ServiceSourceType.BUILDIN]: builtinServices,
                                            [ServiceSourceType.PLUGIN]: pluginList[ServiceType.TRANSLATE],
                                        }) && (
                                            <tr
                                                key={item.id}
                                                className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-blue-50 dark:hover:bg-blue-900/20 cursor-pointer transition-colors duration-200"
                                                onClick={() => getSelectedData(item.id)}
                                            >
                                                <td className="px-6 py-4">
                                                    {getServiceSouceType(item.service) === ServiceSourceType.PLUGIN ? (
                                                        <img
                                                            src={pluginList['translate'][getServiceName(item.service)].icon}
                                                            className='h-[18px] w-[18px]'
                                                            draggable={false}
                                                        />
                                                    ) : (
                                                        <img
                                                            src={`${builtinServices[getServiceName(item.service)].info.icon}`}
                                                            className='h-[18px] w-[18px]'
                                                            draggable={false}
                                                        />
                                                    )}
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="max-w-[200px] whitespace-nowrap overflow-hidden text-ellipsis">
                                                        {item.text}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`fi fi-${LanguageFlag[item.source]} !w-6 !h-4.5 shadow-sm border border-gray-100 dark:border-gray-800 rounded-[2px]`} />
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`fi fi-${LanguageFlag[item.target]} !w-6 !h-4.5 shadow-sm border border-gray-100 dark:border-gray-800 rounded-[2px]`} />
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="max-w-[200px] whitespace-nowrap overflow-hidden text-ellipsis">
                                                        {item.result}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {formatDate(new Date(item.timestamp))}
                                                </td>
                                            </tr>
                                        )
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination & Actions */}
                    <div className='mt-4 flex-none flex justify-between items-center'>
                        <div className="flex items-center space-x-2">
                            <span className="text-sm text-gray-700 dark:text-gray-400">
                                Page <span className="font-semibold text-gray-900 dark:text-white">{page}</span> of <span className="font-semibold text-gray-900 dark:text-white">{totalPages || 1}</span>
                            </span>
                            <div className="inline-flex rounded-md shadow-sm" role="group">
                                <button
                                    onClick={() => setPage(p => Math.max(1, p - 1))}
                                    disabled={page === 1}
                                    className="px-3 py-1 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-s-lg hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-2 focus:ring-blue-700 focus:text-blue-700 dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-blue-500 dark:focus:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                >
                                    Prev
                                </button>
                                <button
                                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                    disabled={page >= totalPages}
                                    className="px-3 py-1 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-e-lg hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-2 focus:ring-blue-700 focus:text-blue-700 dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-blue-500 dark:focus:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                >
                                    Next
                                </button>
                            </div>
                        </div>

                        <button
                            onClick={() => setIsClearConfirmOpen(true)}
                            className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center gap-2 dark:bg-red-500 dark:hover:bg-red-600 dark:focus:ring-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0"
                            disabled={items.length === 0}
                        >
                            <DeleteIcon className="text-base shrink-0" />
                            <span className="whitespace-nowrap">{t('common.clear')}</span>
                        </button>
                    </div>
                </div>

                {/* Edit Modal */}
                {isModalOpen && selectedItem && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                        <div className="relative w-full max-w-2xl max-h-full bg-white rounded-lg shadow dark:bg-gray-700 flex flex-col">
                            {/* Modal header */}
                            <div className="flex items-center justify-between p-4 border-b rounded-t dark:border-gray-600">
                                <div className='flex items-center gap-2'>
                                    {getServiceSouceType(selectedItem.service) === ServiceSourceType.PLUGIN ? (
                                        <img
                                            src={pluginList['translate'][getServiceName(selectedItem.service)].icon}
                                            className='h-6 w-6'
                                            draggable={false}
                                        />
                                    ) : (
                                        <img
                                            src={`${builtinServices[getServiceName(selectedItem.service)].info.icon}`}
                                            className='h-6 w-6'
                                            draggable={false}
                                        />
                                    )}
                                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                                        Edit History
                                    </h3>
                                </div>
                                <button
                                    onClick={() => setIsModalOpen(false)}
                                    type="button"
                                    className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                >
                                    <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                    </svg>
                                    <span className="sr-only">Close modal</span>
                                </button>
                            </div>
                            {/* Modal body */}
                            <div className="p-4 space-y-4 flex-1 overflow-y-auto">
                                <div>
                                    <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Source Text</label>
                                    <textarea
                                        rows="4"
                                        className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        value={selectedItem.text}
                                        onChange={(e) => setSelectItem({ ...selectedItem, text: e.target.value })}
                                    ></textarea>
                                </div>
                                <div>
                                    <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Result Text</label>
                                    <textarea
                                        rows="4"
                                        className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        value={selectedItem.result}
                                        onChange={(e) => setSelectItem({ ...selectedItem, result: e.target.value })}
                                    ></textarea>
                                </div>
                            </div>
                            {/* Modal footer */}
                            <div className="flex items-center justify-between p-4 border-t border-gray-200 rounded-b dark:border-gray-600">
                                <button
                                    onClick={async () => {
                                        await updateData();
                                        setIsModalOpen(false);
                                    }}
                                    type="button"
                                    className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 transition-colors"
                                >
                                    {t('common.save')}
                                </button>
                                <div className="flex gap-2">
                                    {collectionServiceList && collectionServiceList.map((instanceKey) => (
                                        <button
                                            key={instanceKey}
                                            type="button"
                                            className="p-2 text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600"
                                            onClick={async () => {
                                                if (getServiceSouceType(instanceKey) === ServiceSourceType.PLUGIN) {
                                                    const pluginConfig = (await store.get(instanceKey)) ?? {};
                                                    let [func, utils] = await invoke_plugin('collection', getServiceName(instanceKey));
                                                    func(selectedItem.text, selectedItem.result, { config: pluginConfig, utils }).then(
                                                        (_) => toast.success(t('translate.add_collection_success'), { style: toastStyle }),
                                                        (e) => toast.error(e.toString(), { style: toastStyle })
                                                    );
                                                } else {
                                                    const instanceConfig = (await store.get(instanceKey)) ?? {};
                                                    builtinCollectionServices[getServiceName(instanceKey)].collection(
                                                        selectedItem.text, selectedItem.result, { config: instanceConfig }
                                                    ).then(
                                                        (_) => toast.success(t('translate.add_collection_success'), { style: toastStyle }),
                                                        (e) => toast.error(e.toString(), { style: toastStyle })
                                                    );
                                                }
                                            }}
                                        >
                                            <img
                                                src={
                                                    getServiceSouceType(instanceKey) === ServiceSourceType.PLUGIN
                                                        ? pluginList['collection'][getServiceName(instanceKey)].icon
                                                        : builtinCollectionServices[getServiceName(instanceKey)].info.icon
                                                }
                                                className='h-5 w-5'
                                            />
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Clear Confirm Modal */}
                {isClearConfirmOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
                        <div className="relative w-full max-w-md max-h-full bg-white rounded-lg shadow dark:bg-gray-700">
                            <div className="p-4 md:p-5 text-center">
                                <svg className="mx-auto mb-4 text-gray-400 w-12 h-12 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                                <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">Are you sure you want to clear all history?</h3>
                                <button onClick={clearData} type="button" className="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center transition-colors">
                                    {t('common.ok')}
                                </button>
                                <button onClick={() => setIsClearConfirmOpen(false)} type="button" className="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 transition-colors">
                                    {t('common.cancel')}
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        )
    );
}
