import { enable, isEnabled, disable } from 'tauri-plugin-autostart-api';
import React, { useState, useEffect, useRef } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { info } from 'tauri-plugin-log-api';
import 'flag-icons/css/flag-icons.min.css';
import { invoke } from '@tauri-apps/api/tauri';
import { useTheme } from 'next-themes';
import Database from 'tauri-plugin-sql-api';
import { store } from '../../../../utils/store';

import { useConfig } from '../../../../hooks/useConfig';
import { LanguageFlag } from '../../../../utils/language';
import { useToastStyle } from '../../../../hooks';
import { osType } from '../../../../utils/env';
import { createGlossary, deleteGlossary, updateGlossaryDictionary } from '../../../../utils/dictionary';
import Dropdown from '../../../../components/Dropdown';

export default function General() {
    const [autoStart, setAutoStart] = useState(false);
    const [fontList, setFontList] = useState(null);
    const [checkUpdate, setCheckUpdate] = useConfig('check_update', false);

    const [appLanguage, setAppLanguage] = useConfig('app_language', 'en');
    const [appTheme, setAppTheme] = useConfig('app_theme', 'system');
    const [appFont, setAppFont] = useConfig('app_font', 'default');
    const [appFallbackFont, setAppFallbackFont] = useConfig('app_fallback_font', 'default');
    const [appFontSize, setAppFontSize] = useConfig('app_font_size', 16);
    const [transparent, setTransparent] = useConfig('transparent', true);
    const [generalProject, setGeneralProject] = useConfig('general_project', null);
    const [projects, setProjects] = useState([]);

    const [trayClickEvent, setTrayClickEvent] = useConfig('tray_click_event', 'config');

    const { t, i18n } = useTranslation();
    const { setTheme } = useTheme();
    const toastStyle = useToastStyle();

    const languageName = {
        en: t('languages.en'),
        ja: t('languages.ja'),
    };

    useEffect(() => {
        isEnabled().then((v) => {
            setAutoStart(v);
        });
        invoke('font_list').then((v) => {
            setFontList(v);
        });
        initProject();
    }, []);

    const handleProjectChange = async (key) => {
        const newProjectId = key === 'none' ? null : Number(key);
        setGeneralProject(newProjectId);

        if (!newProjectId) {
            const loadingToast = toast.loading(t('common.processing'));
            try {
                await deleteGlossary();
                toast.success(t('config.general.glossary_cleared') || 'Glossary cleared successfully', { id: loadingToast });
            } catch (e) {
                console.error('Error clearing glossary:', e);
                toast.error(t('common.error'), { id: loadingToast });
            }
            return;
        }

        let loadingToast = null;

        try {
            const dictProjectIdStr = localStorage.getItem('currentProjectId');
            const dictProjectId = dictProjectIdStr ? Number(dictProjectIdStr) : null;

            let sourceLang = (await store.get('translate_source_language')) || 'EN';
            let targetLang = (await store.get('translate_target_language')) || 'VI';

            const dictDb = await Database.load('sqlite:dictionary.db');
            const dictCountResult = await dictDb.select('SELECT COUNT(*) as count FROM dictionary WHERE project_id = $1', [newProjectId]);
            const dictCount = dictCountResult[0]?.count || 0;

            if (dictCount === 0) {
                console.log('Dictionary is empty. Skipping glossary sync.');
                return;
            }

            loadingToast = toast.loading(t('common.processing'));

            const db = await Database.load('sqlite:project.db');
            const projectResult = await db.select('SELECT glossary_id FROM project WHERE id = $1', [newProjectId]);
            const hasGlossaryId = !!(projectResult && projectResult[0] && projectResult[0].glossary_id);

            if (sourceLang === 'auto') {
                console.warn("Glossary source language 'auto' is not supported. Defaulting to 'EN'.");
                sourceLang = 'EN';
                toast(t('config.general.glossary_auto_lang_warn'), {
                    icon: '⚠️',
                });
            }

            if (dictProjectId && dictProjectId === newProjectId && hasGlossaryId) {
                console.log('Project matches Dictionary Page and has Glossary. Updating...');
                await updateGlossaryDictionary(newProjectId, sourceLang, targetLang);
                toast.success(t('config.general.glossary_update_success'), { id: loadingToast });
            } else {
                console.log('Project differs or has no Glossary. Resetting...');
                await deleteGlossary();
                await createGlossary(newProjectId, sourceLang, targetLang);
                toast.success(t('config.general.glossary_create_success'), { id: loadingToast });
            }
        } catch (error) {
            console.error('Glossary sync failed:', error);
            if (error.message && !error.message.includes('No dictionary entries')) {
                if (loadingToast) {
                    toast.error(t('config.general.glossary_sync_failed').replace('$1', error.message), { id: loadingToast });
                } else {
                    toast.error(t('config.general.glossary_sync_failed').replace('$1', error.message));
                }
            } else {
                if (loadingToast) {
                    toast.dismiss(loadingToast);
                }
            }
        }
    };

    const initProject = async () => {
        try {
            const db = await Database.load('sqlite:project.db');
            const result = await db.select('SELECT * FROM project');
            setProjects(result);
        } catch (e) {
            console.error('Failed to load projects', e);
        }
    };

    const labelClass = 'text-sm font-medium text-gray-900 dark:text-white my-auto';

    return (
        <div className="flex-1 flex flex-col overflow-y-auto pr-2 no-scrollbar-on-hover">
            <Toaster />
            {/* Auto Start & Check Update Card */}
            <div className='mb-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5 space-y-4'>
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.auto_start')}</h3>
                    <label className='inline-flex items-center cursor-pointer'>
                        <input
                            type='checkbox'
                            checked={autoStart}
                            onChange={(e) => {
                                const v = e.target.checked;
                                setAutoStart(v);
                                if (v) {
                                    enable().then(() => info('Auto start enabled'));
                                } else {
                                    disable().then(() => info('Auto start disabled'));
                                }
                            }}
                            className='sr-only peer'
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                </div>
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.check_update')}</h3>
                    {checkUpdate !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={checkUpdate}
                                onChange={(e) => setCheckUpdate(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>
            </div>

            {/* Main Settings Card */}
            <div className='mb-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-5 space-y-4 flex-none'>
                {/* App Language */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.app_language')}</h3>
                    {appLanguage !== null && (
                        <Dropdown
                            value={appLanguage}
                            onChange={(val) => {
                                setAppLanguage(val);
                                i18n.changeLanguage(val);
                                invoke('update_tray', { language: val, copyMode: '' });
                            }}
                            options={[
                                { value: 'en', label: t('languages.en') },
                                { value: 'ja', label: t('languages.ja') }
                            ]}
                            renderLabel={(opt) => (
                                <span className="flex items-center">
                                    <span className={`fi fi-${LanguageFlag[opt.value]} mr-2`} />
                                    {opt.label}
                                </span>
                            )}
                            renderOption={(opt) => (
                                <span className="flex items-center">
                                    <span className={`fi fi-${LanguageFlag[opt.value]} mr-2`} />
                                    {opt.label}
                                </span>
                            )}
                            className="w-[200px]"
                        />
                    )}
                </div>

                {/* Project Selection */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.project')}</h3>
                    <Dropdown
                        value={generalProject === null ? 'none' : generalProject}
                        onChange={(val) => handleProjectChange(val)}
                        options={[
                            { value: 'none', label: t('config.general.no_project') },
                            ...projects.map(p => ({ value: p.id, label: p.name }))
                        ]}
                        className="w-[200px]"
                    />
                </div>

                {/* App Theme */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.app_theme')}</h3>
                    <Dropdown
                        value={appTheme || 'system'}
                        onChange={(val) => {
                            setAppTheme(val);
                            if (val === 'system') {
                                if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                                    setTheme('dark');
                                } else {
                                    setTheme('light');
                                }
                            } else {
                                setTheme(val);
                            }
                        }}
                        options={[
                            { value: 'system', label: t('config.general.theme.system') },
                            { value: 'light', label: t('config.general.theme.light') },
                            { value: 'dark', label: t('config.general.theme.dark') }
                        ]}
                        className="w-[200px]"
                    />
                </div>

                {/* App Font */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.app_font')}</h3>
                    {appFont !== null && fontList !== null && (
                        <Dropdown
                            value={appFont}
                            onChange={(val) => {
                                document.documentElement.style.fontFamily = `"${val === 'default' ? 'sans-serif' : val}","${appFallbackFont === 'default' ? 'sans-serif' : appFallbackFont}"`;
                                setAppFont(val);
                            }}
                            options={[
                                { value: 'default', label: t('config.general.default_font') },
                                ...fontList.map(f => ({ value: f, label: f }))
                            ]}
                            renderLabel={(opt) => (
                                <span style={{ fontFamily: opt.value === 'default' ? 'inherit' : opt.value }}>
                                    {opt.label}
                                </span>
                            )}
                            renderOption={(opt) => (
                                <span style={{ fontFamily: opt.value === 'default' ? 'sans-serif' : opt.value }}>
                                    {opt.label}
                                </span>
                            )}
                            className="w-[200px]"
                            showSearch={true}
                        />
                    )}
                </div>

                {/* App Fallback Font */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.app_fallback_font')}</h3>
                    {appFallbackFont !== null && fontList !== null && (
                        <Dropdown
                            value={appFallbackFont}
                            onChange={(val) => {
                                document.documentElement.style.fontFamily = `"${appFont === 'default' ? 'sans-serif' : appFont}","${val === 'default' ? 'sans-serif' : val}"`;
                                setAppFallbackFont(val);
                            }}
                            options={[
                                { value: 'default', label: t('config.general.default_font') },
                                ...fontList.map(f => ({ value: f, label: f }))
                            ]}
                            renderLabel={(opt) => (
                                <span style={{ fontFamily: opt.value === 'default' ? 'inherit' : opt.value }}>
                                    {opt.label}
                                </span>
                            )}
                            renderOption={(opt) => (
                                <span style={{ fontFamily: opt.value === 'default' ? 'sans-serif' : opt.value }}>
                                    {opt.label}
                                </span>
                            )}
                            className="w-[200px]"
                            showSearch={true}
                        />
                    )}
                </div>

                {/* Font Size */}
                <div className='flex justify-between items-center'>
                    <h3 className={labelClass}>{t('config.general.font_size.title')}</h3>
                    <Dropdown
                        value={appFontSize || 16}
                        onChange={(val) => {
                            const size = parseInt(val);
                            document.documentElement.style.fontSize = `${size}px`;
                            setAppFontSize(size);
                        }}
                        options={[10, 12, 14, 16, 18, 20, 24].map(size => ({
                            value: size,
                            label: t(`config.general.font_size.${size}`)
                        }))}
                        className="w-[200px]"
                    />
                </div>

                {/* Tray Click Event */}
                <div className={`flex justify-between items-center ${osType !== 'Windows_NT' && 'hidden'}`}>
                    <h3 className={labelClass}>{t('config.general.tray_click_event')}</h3>
                    <Dropdown
                        value={trayClickEvent || 'config'}
                        onChange={(val) => setTrayClickEvent(val)}
                        options={[
                            { value: 'config', label: t('config.general.event.config') },
                            { value: 'translate', label: t('config.general.event.translate') },
                            { value: 'ocr_recognize', label: t('config.general.event.ocr_recognize') },
                            { value: 'ocr_translate', label: t('config.general.event.ocr_translate') },
                            { value: 'disable', label: t('config.general.event.disable') }
                        ]}
                        className="w-[200px]"
                    />
                </div>

                {/* Transparent Effect */}
                <div className={`flex justify-between items-center ${osType === 'Darwin' && 'hidden'}`}>
                    <h3 className={labelClass}>{t('config.general.transparent')}</h3>
                    {transparent !== null && (
                        <label className='inline-flex items-center cursor-pointer'>
                            <input
                                type='checkbox'
                                checked={transparent}
                                onChange={(e) => setTransparent(e.target.checked)}
                                className='sr-only peer'
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    )}
                </div>
            </div>
        </div>
    );
}
