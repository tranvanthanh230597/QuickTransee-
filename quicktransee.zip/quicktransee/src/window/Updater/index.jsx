import { checkUpdate, installUpdate } from '@tauri-apps/api/updater';
import React, { useEffect, useState } from 'react';
import { appWindow } from '@tauri-apps/api/window';
import { relaunch } from '@tauri-apps/api/process';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { listen } from '@tauri-apps/api/event';
import ReactMarkdown from 'react-markdown';
import { initFlowbite } from 'flowbite';

import { useConfig, useToastStyle } from '../../hooks';
import { osType } from '../../utils/env';

let unlisten = 0;
let eventId = 0;

export default function Updater() {
    const [transparent] = useConfig('transparent', true);
    const [downloaded, setDownloaded] = useState(0);
    const [total, setTotal] = useState(0);
    const [body, setBody] = useState('');
    const { t } = useTranslation();
    const toastStyle = useToastStyle();
    const [shouldUpdate, setShouldUpdate] = useState(false);

    useEffect(() => {
        initFlowbite();
        if (appWindow.label === 'updater') {
            appWindow.show();
        }
        checkUpdate().then(
            (update) => {
                if (update.shouldUpdate) {
                    setBody(update.manifest.body);
                    setShouldUpdate(true);
                } else {
                    setBody(t('updater.latest'));
                    setShouldUpdate(false);
                }
            },
            (e) => {
                const errStr = e.toString();
                // Nếu gặp lỗi fetch/JSON hoặc lỗi không xác định, ta coi như đang ở bản mới nhất để không làm phiền user
                if (errStr.includes("JSON") || errStr.includes("fetch") || errStr.includes("body is empty")) {
                    setBody(t('updater.latest'));
                } else {
                    setBody(errStr);
                    toast.error(errStr, { style: toastStyle });
                }
                setShouldUpdate(false);
            }
        );
        if (unlisten === 0) {
            unlisten = listen('tauri://update-download-progress', (e) => {
                if (eventId === 0) {
                    eventId = e.id;
                }
                if (e.id === eventId) {
                    setTotal(e.payload.contentLength);
                    setDownloaded((a) => {
                        return a + e.payload.chunkLength;
                    });
                }
            });
        }
    }, []);

    return (
        <div
            className={`flex flex-col h-screen ${transparent ? 'bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl' : 'bg-white dark:bg-gray-900'} ${osType === 'Linux' && 'rounded-xl border border-gray-200 dark:border-gray-700 shadow-2xl'}`}
        >
            <Toaster />

            {/* Header */}
            <div
                data-tauri-drag-region='true'
                className='flex items-center justify-between px-4 h-12 shrink-0 select-none'
            >
                <div className='flex items-center gap-2 pointer-events-none'>
                    <img
                        src='icon.png'
                        className='h-6 w-6'
                        draggable={false}
                    />
                    <h2 className="text-gray-900 dark:text-white text-sm font-semibold tracking-tight">{t('updater.title')}</h2>
                </div>
                {osType !== 'Darwin' && (
                    <button
                        onClick={() => appWindow.close()}
                        className="p-1.5 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg transition-colors text-gray-500 hover:text-gray-800 dark:hover:text-gray-200"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                )}
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col px-6 pb-4 overflow-hidden">
                <div className={`flex-1 min-h-0 bg-white/50 dark:bg-gray-800/50 rounded-2xl border border-gray-200/50 dark:border-gray-700/50 shadow-inner overflow-y-auto ${!shouldUpdate && body !== '' ? 'flex items-center justify-center p-8' : 'p-6'}`}>
                    {body === '' ? (
                        <div role="status" className="space-y-4 w-full animate-pulse">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full w-3/4"></div>
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full w-full"></div>
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full w-5/6"></div>
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full w-2/3"></div>
                        </div>
                    ) : !shouldUpdate ? (
                        <div className="text-center animate-in fade-in zoom-in duration-500">
                            <div className="inline-flex items-center justify-center w-20 h-20 mb-6 bg-green-100 dark:bg-green-900/30 rounded-full">
                                <svg className="w-10 h-10 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                            </div>
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{t('updater.latest')}</h1>
                            <p className="text-gray-500 dark:text-gray-400 text-sm">{t('updater.no_updates_desc') || 'Your application is current and up to date.'}</p>
                        </div>
                    ) : (
                        <div className="animate-in slide-in-from-bottom-4 duration-500">
                            <div className="flex items-center gap-3 mb-6">
                                <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-xl">
                                    <svg className="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                    </svg>
                                </div>
                                <h1 className="text-xl font-bold text-gray-900 dark:text-white">{t('updater.new_version')}</h1>
                            </div>
                            <div className="prose dark:prose-invert max-w-none">
                                <ReactMarkdown
                                    className='markdown-body select-text text-gray-700 dark:text-gray-300 leading-relaxed'
                                    components={{
                                        code: ({ node, ...props }) => {
                                            const { children } = props;
                                            return <code className="bg-gray-200 dark:bg-gray-700 rounded-md px-1.5 py-0.5 font-mono text-sm">{children}</code>;
                                        },
                                        h2: ({ node, ...props }) => (
                                            <div className="mt-6 mb-3">
                                                <h2 className='text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2' {...props} />
                                                <div className="h-px w-full bg-gradient-to-r from-gray-200 dark:from-gray-700 to-transparent mt-1" />
                                            </div>
                                        ),
                                        h3: ({ node, ...props }) => (
                                            <h3 className='text-md font-semibold text-gray-800 dark:text-gray-200 mt-4 mb-2' {...props} />
                                        ),
                                        li: ({ node, ...props }) => (
                                            <li className='list-disc list-inside mb-1' {...props} />
                                        ),
                                    }}
                                >
                                    {body}
                                </ReactMarkdown>
                            </div>
                        </div>
                    )}
                </div>

                {/* Progress Bar */}
                {downloaded !== 0 && (
                    <div className="mt-4 px-2 animate-in fade-in slide-in-from-bottom-2">
                        <div className="flex justify-between items-center mb-2">
                            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">{t('updater.downloading')}</span>
                            <span className="text-xs font-mono font-bold text-gray-600 dark:text-gray-400">{Math.round((downloaded / total) * 100)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                            <div
                                className="bg-blue-600 dark:bg-blue-500 h-full rounded-full transition-all duration-300 ease-out shadow-[0_0_10px_rgba(37,99,235,0.5)]"
                                style={{ width: `${Math.min(100, (downloaded / total) * 100)}%` }}
                            ></div>
                        </div>
                    </div>
                )}
            </div>

            {/* Footer Actions */}
            <div className='flex items-center justify-end gap-3 p-6 pt-0 shrink-0'>
                <button
                    type="button"
                    className="px-5 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-all active:scale-95"
                    onClick={() => appWindow.close()}
                >
                    {t('updater.cancel')}
                </button>
                <button
                    type="button"
                    disabled={downloaded !== 0 || !shouldUpdate}
                    className={`px-6 py-2.5 text-sm font-bold rounded-xl transition-all shadow-lg active:scale-95 ${downloaded !== 0 || !shouldUpdate
                        ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-600 border border-gray-200 dark:border-gray-700 cursor-not-allowed hidden'
                        : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/30'
                        }`}
                    onClick={() => {
                        installUpdate().then(
                            () => {
                                toast.success(t('updater.installed'), { style: toastStyle, duration: 10000 });
                                relaunch();
                            },
                            (e) => {
                                toast.error(e.toString(), { style: toastStyle });
                            }
                        );
                    }}
                >
                    {downloaded !== 0
                        ? downloaded > total
                            ? t('updater.installing')
                            : t('updater.downloading')
                        : t('updater.update')}
                </button>
            </div>
        </div>
    );
}
