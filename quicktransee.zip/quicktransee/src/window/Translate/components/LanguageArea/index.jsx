import { useTranslation } from 'react-i18next';
import { ArrowsRightLeftIcon } from '../../../../components/Icons';
import { useEffect } from 'react';
import { atom, useAtom, useAtomValue } from 'jotai';

import { languageList } from '../../../../utils/language';
import { detectLanguageAtom } from '../SourceArea';
import { useConfig } from '../../../../hooks';
import Dropdown from '../../../../components/Dropdown';

export const sourceLanguageAtom = atom();
export const targetLanguageAtom = atom();

export default function LanguageArea() {
    const [rememberLanguage] = useConfig('translate_remember_language', false);
    const [translateSourceLanguage, setTranslateSourceLanguage] = useConfig('translate_source_language', 'auto');
    const [translateTargetLanguage, setTranslateTargetLanguage] = useConfig('translate_target_language', 'vi');
    const [translateSecondLanguage] = useConfig('translate_second_language', 'vi');

    const [sourceLanguage, setSourceLanguage] = useAtom(sourceLanguageAtom);
    const [targetLanguage, setTargetLanguage] = useAtom(targetLanguageAtom);
    const detectLanguage = useAtomValue(detectLanguageAtom);
    const { t } = useTranslation();

    useEffect(() => {
        if (translateSourceLanguage) {
            setSourceLanguage(translateSourceLanguage);
        }
        if (translateTargetLanguage) {
            setTargetLanguage(translateTargetLanguage);
        }
    }, [translateSourceLanguage, translateTargetLanguage]);

    useEffect(() => {
        if (rememberLanguage !== null && rememberLanguage) {
            setTranslateSourceLanguage(sourceLanguage);
            setTranslateTargetLanguage(targetLanguage);
        }
    }, [sourceLanguage, targetLanguage, rememberLanguage]);

    const languageOptions = [
        { value: 'auto', label: t('languages.auto') },
        ...languageList.map(x => ({ value: x, label: t(`languages.${x}`) }))
    ];

    const targetLanguageOptions = languageList.map(x => ({ value: x, label: t(`languages.${x}`) }));

    return (
        <div className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-xl px-2 h-[44px] transition-all border border-gray-200 dark:border-gray-700 mb-2 shadow-sm group">
            {/* Source Language Dropdown */}
            <Dropdown
                value={sourceLanguage || 'auto'}
                onChange={(val) => setSourceLanguage(val)}
                options={languageOptions}
                showSearch={true}
                buttonClassName="inline-flex items-center justify-between w-full h-9 px-3 text-sm font-semibold text-gray-700 dark:text-gray-200 bg-transparent hover:bg-gray-100/50 dark:hover:bg-gray-700/50 rounded-lg transition-colors border-none focus:ring-0"
                className="flex-1"
                renderLabel={(opt) => opt ? (opt.value === 'auto' ? <span className="text-blue-600 dark:text-blue-400 font-bold">{opt.label}</span> : opt.label) : ''}
            />

            {/* Swap Button */}
            <button
                type="button"
                className="mx-1 p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-all hover:bg-white dark:hover:bg-gray-700 rounded-full shadow-sm hover:shadow-md hover:rotate-180 duration-500"
                onClick={async () => {
                    if (sourceLanguage !== 'auto') {
                        const oldSourceLanguage = sourceLanguage;
                        setSourceLanguage(targetLanguage);
                        setTargetLanguage(oldSourceLanguage);
                    } else if (detectLanguage !== '') {
                        setTargetLanguage(detectLanguage);
                    }
                }}
                disabled={sourceLanguage === 'auto' && detectLanguage === ''}
            >
                <ArrowsRightLeftIcon className="text-lg" />
            </button>

            {/* Target Language Dropdown */}
            <Dropdown
                value={targetLanguage || 'vi'}
                onChange={(val) => setTargetLanguage(val)}
                options={targetLanguageOptions}
                showSearch={true}
                buttonClassName="inline-flex items-center justify-between w-full h-9 px-3 text-sm font-semibold text-gray-700 dark:text-gray-200 bg-transparent hover:bg-gray-100/50 dark:hover:bg-gray-700/50 rounded-lg transition-colors border-none focus:ring-0"
                className="flex-1"
            />
        </div>
    );
}

