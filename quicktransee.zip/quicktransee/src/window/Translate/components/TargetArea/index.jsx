import {
    HiOutlineSpeakerWave,
    HiOutlineDocumentDuplicate,
    HiOutlineArrowsRightLeft,
    HiOutlineArrowPath
} from 'react-icons/hi2';
import { ChevronDoubleUpIcon, ChevronDoubleDownIcon } from '../../../../components/Icons';
import { BaseDirectory, readTextFile } from '@tauri-apps/api/fs';
import { sendNotification } from '@tauri-apps/api/notification';
import { useEffect, useState, useRef } from 'react';
import { writeText } from '@tauri-apps/api/clipboard';
import PulseLoader from 'react-spinners/PulseLoader';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import Database from 'tauri-plugin-sql-api';
import { useTheme } from 'next-themes';
import { useAtomValue } from 'jotai';
import { nanoid } from 'nanoid';
import { useSpring, animated } from '@react-spring/web';
import useMeasure from 'react-use-measure';

import * as builtinCollectionServices from '../../../../services/collection';
import { sourceLanguageAtom, targetLanguageAtom } from '../LanguageArea';
import { useConfig, useToastStyle, useVoice } from '../../../../hooks';
import { sourceTextAtom, detectLanguageAtom } from '../SourceArea';
import { invoke_plugin } from '../../../../utils/invoke_plugin';
import * as builtinServices from '../../../../services/translate';
import * as builtinTtsServices from '../../../../services/tts';
import Dropdown from '../../../../components/Dropdown';

import { info, error as logError } from 'tauri-plugin-log-api';
import {
    INSTANCE_NAME_CONFIG_KEY,
    ServiceSourceType,
    getDisplayInstanceName,
    getServiceName,
    getServiceSouceType,
    whetherPluginService,
} from '../../../../utils/service_instance';

let translateID = [];

export default function TargetArea(props) {
    const { index, name, translateServiceInstanceList, pluginList, serviceInstanceConfigMap, ...drag } = props;

    const [currentTranslateServiceInstanceKey, setCurrentTranslateServiceInstanceKey] = useState(name);
    function getInstanceName(instanceKey, serviceNameSupplier) {
        const instanceConfig = serviceInstanceConfigMap[instanceKey] ?? {};
        return getDisplayInstanceName(instanceConfig[INSTANCE_NAME_CONFIG_KEY], serviceNameSupplier);
    }

    const [appFontSize] = useConfig('app_font_size', 16);
    const [collectionServiceList] = useConfig('collection_service_list', []);
    const [ttsServiceList] = useConfig('tts_service_list', ['lingva_tts']);
    const [translateSecondLanguage] = useConfig('translate_second_language', 'vi');
    const [historyDisable] = useConfig('history_disable', false);
    const [isLoading, setIsLoading] = useState(false);
    const [hide, setHide] = useState(true);

    const [result, setResult] = useState('');
    const [error, setError] = useState('');

    const sourceText = useAtomValue(sourceTextAtom);
    const sourceLanguage = useAtomValue(sourceLanguageAtom);
    const targetLanguage = useAtomValue(targetLanguageAtom);
    const [autoCopy] = useConfig('translate_auto_copy', 'disable');
    const [hideWindow] = useConfig('translate_hide_window', false);
    const [clipboardMonitor] = useConfig('clipboard_monitor', false);

    const detectLanguage = useAtomValue(detectLanguageAtom);
    const [ttsPluginInfo, setTtsPluginInfo] = useState();
    const { t } = useTranslation();
    const textAreaRef = useRef();
    const toastStyle = useToastStyle();
    const speak = useVoice();
    const { theme } = useTheme();

    useEffect(() => {
        if (error) {
            logError(`[${currentTranslateServiceInstanceKey}]happened error: ` + error);
        }
    }, [error]);

    // listen to translation
    useEffect(() => {
        setResult('');
        setError('');
        if (
            sourceText.trim() !== '' &&
            sourceLanguage &&
            targetLanguage &&
            autoCopy !== null &&
            hideWindow !== null &&
            clipboardMonitor !== null
        ) {
            if (autoCopy === 'source' && !clipboardMonitor) {
                writeText(sourceText).then(() => {
                    if (hideWindow) {
                        sendNotification({ title: t('common.write_clipboard'), body: sourceText });
                    }
                });
            }
            translate();
        }
    }, [
        sourceText,
        sourceLanguage,
        targetLanguage,
        autoCopy,
        hideWindow,
        currentTranslateServiceInstanceKey,
        clipboardMonitor,
    ]);

    // todo: history panel use service instance key
    const addToHistory = async (text, source, target, serviceInstanceKey, result) => {
        const db = await Database.load('sqlite:history.db');

        await db
            .execute(
                'INSERT into history (text, source, target, service, result, timestamp) VALUES ($1, $2, $3, $4, $5, $6)',
                [text, source, target, serviceInstanceKey, result, Date.now()]
            )
            .then(
                (v) => {
                    db.close();
                },
                (e) => {
                    db.execute(
                        'CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL,source TEXT NOT NULL,target TEXT NOT NULL,service TEXT NOT NULL, result TEXT NOT NULL,timestamp INTEGER NOT NULL)'
                    ).then(() => {
                        db.close();
                        addToHistory(text, source, target, serviceInstanceKey, result);
                    });
                }
            );
    };

    function invokeOnce(fn) {
        let isInvoke = false;

        return (...args) => {
            if (isInvoke) {
                return;
            } else {
                fn(...args);
                isInvoke = true;
            }
        };
    }

    const translate = async () => {
        let id = nanoid();
        translateID[index] = id;

        const translateServiceName = getServiceName(currentTranslateServiceInstanceKey);

        if (whetherPluginService(currentTranslateServiceInstanceKey)) {
            const pluginInfo = pluginList['translate'][translateServiceName];
            if (sourceLanguage in pluginInfo.language && targetLanguage in pluginInfo.language) {
                let newTargetLanguage = targetLanguage;
                if (sourceLanguage === 'auto' && targetLanguage === detectLanguage) {
                    newTargetLanguage = translateSecondLanguage;
                }
                setIsLoading(true);
                setHide(true);
                const instanceConfig = serviceInstanceConfigMap[currentTranslateServiceInstanceKey];
                instanceConfig['enable'] = 'true';
                const setHideOnce = invokeOnce(setHide);
                let [func, utils] = await invoke_plugin('translate', translateServiceName);
                func(sourceText.trim(), pluginInfo.language[sourceLanguage], pluginInfo.language[newTargetLanguage], {
                    config: instanceConfig,
                    detect: detectLanguage,
                    setResult: (v) => {
                        if (translateID[index] !== id) return;
                        setResult(v);
                        setHideOnce(false);
                    },
                    utils,
                }).then(
                    (v) => {
                        info(`[${currentTranslateServiceInstanceKey}]resolve:` + v);
                        if (translateID[index] !== id) return;
                        setResult(typeof v === 'string' ? v.trim() : v);
                        setIsLoading(false);
                        if (v !== '') {
                            setHideOnce(false);
                        }
                        if (!historyDisable) {
                            addToHistory(
                                sourceText.trim(),
                                detectLanguage,
                                newTargetLanguage,
                                translateServiceName,
                                typeof v === 'string' ? v.trim() : v
                            );
                        }
                        if (index === 0 && !clipboardMonitor) {
                            switch (autoCopy) {
                                case 'target':
                                    writeText(v).then(() => {
                                        if (hideWindow) {
                                            sendNotification({ title: t('common.write_clipboard'), body: v });
                                        }
                                    });
                                    break;
                                case 'source_target':
                                    writeText(sourceText.trim() + '\n\n' + v).then(() => {
                                        if (hideWindow) {
                                            sendNotification({
                                                title: t('common.write_clipboard'),
                                                body: sourceText.trim() + '\n\n' + v,
                                            });
                                        }
                                    });
                                    break;
                                default:
                                    break;
                            }
                        }
                    },
                    (e) => {
                        info(`[${currentTranslateServiceInstanceKey}]reject:` + e);
                        if (translateID[index] !== id) return;
                        setError(e.toString());
                        setIsLoading(false);
                    }
                );
            } else {
                setError('Language not supported');
            }
        } else {
            const LanguageEnum = builtinServices[translateServiceName].Language;
            if (sourceLanguage in LanguageEnum && targetLanguage in LanguageEnum) {
                let newTargetLanguage = targetLanguage;
                if (sourceLanguage === 'auto' && targetLanguage === detectLanguage) {
                    newTargetLanguage = translateSecondLanguage;
                }
                setIsLoading(true);
                setHide(true);
                const instanceConfig = serviceInstanceConfigMap[currentTranslateServiceInstanceKey];
                const setHideOnce = invokeOnce(setHide);
                builtinServices[translateServiceName]
                    .translate(sourceText.trim(), LanguageEnum[sourceLanguage], LanguageEnum[newTargetLanguage], {
                        config: instanceConfig,
                        detect: detectLanguage,
                        setResult: (v) => {
                            if (translateID[index] !== id) return;
                            setResult(v);
                            setHideOnce(false);
                        },
                    })
                    .then(
                        (v) => {
                            info(`[${currentTranslateServiceInstanceKey}]resolve:` + v);
                            if (translateID[index] !== id) return;
                            setResult(typeof v === 'string' ? v.trim() : v);
                            setIsLoading(false);
                            if (v !== '') {
                                setHideOnce(false);
                            }
                            if (!historyDisable) {
                                addToHistory(
                                    sourceText.trim(),
                                    detectLanguage,
                                    newTargetLanguage,
                                    translateServiceName,
                                    typeof v === 'string' ? v.trim() : v
                                );
                            }
                            if (index === 0 && !clipboardMonitor) {
                                switch (autoCopy) {
                                    case 'target':
                                        writeText(v).then(() => {
                                            if (hideWindow) {
                                                sendNotification({ title: t('common.write_clipboard'), body: v });
                                            }
                                        });
                                        break;
                                    case 'source_target':
                                        writeText(sourceText.trim() + '\n\n' + v).then(() => {
                                            if (hideWindow) {
                                                sendNotification({
                                                    title: t('common.write_clipboard'),
                                                    body: sourceText.trim() + '\n\n' + v,
                                                });
                                            }
                                        });
                                        break;
                                    default:
                                        break;
                                }
                            }
                        },
                        (e) => {
                            info(`[${currentTranslateServiceInstanceKey}]reject:` + e);
                            if (translateID[index] !== id) return;
                            setError(e.toString());
                            setIsLoading(false);
                        }
                    );
            } else {
                setError('Language not supported');
            }
        }
    };

    // hide empty textarea
    useEffect(() => {
        if (textAreaRef.current !== null) {
            textAreaRef.current.style.height = '0px';
            if (result !== '') {
                textAreaRef.current.style.height = textAreaRef.current.scrollHeight + 'px';
            }
        }
    }, [result]);

    // refresh tts config
    useEffect(() => {
        if (ttsServiceList && getServiceSouceType(ttsServiceList[0]) === ServiceSourceType.PLUGIN) {
            readTextFile(`plugins/tts/${getServiceName(ttsServiceList[0])}/info.json`, {
                dir: BaseDirectory.AppConfig,
            }).then((infoStr) => {
                setTtsPluginInfo(JSON.parse(infoStr));
            });
        }
    }, [ttsServiceList]);

    // handle tts speak
    const handleSpeak = async () => {
        const instanceKey = ttsServiceList[0];
        if (getServiceSouceType(instanceKey) === ServiceSourceType.PLUGIN) {
            const pluginConfig = serviceInstanceConfigMap[instanceKey];
            if (!(targetLanguage in ttsPluginInfo.language)) {
                throw new Error('Language not supported');
            }
            let [func, utils] = await invoke_plugin('tts', getServiceName(instanceKey));
            let data = await func(result, ttsPluginInfo.language[targetLanguage], {
                config: pluginConfig,
                utils,
            });
            speak(data);
        } else {
            if (!(targetLanguage in builtinTtsServices[getServiceName(instanceKey)].Language)) {
                throw new Error('Language not supported');
            }
            const instanceConfig = serviceInstanceConfigMap[instanceKey];
            let data = await builtinTtsServices[getServiceName(instanceKey)].tts(
                result,
                builtinTtsServices[getServiceName(instanceKey)].Language[targetLanguage],
                {
                    config: instanceConfig,
                }
            );
            speak(data);
        }
    };

    const [boundRef, bounds] = useMeasure({ scroll: true });
    const springs = useSpring({
        from: { height: 0 },
        to: { height: hide ? 0 : bounds.height },
    });

    const serviceOptions = translateServiceInstanceList.map(instanceKey => ({
        value: instanceKey,
        label: whetherPluginService(instanceKey) ? (
            getInstanceName(instanceKey, () => pluginList['translate'][getServiceName(instanceKey)].display)
        ) : (
            getInstanceName(instanceKey, () =>
                t(`services.translate.${getServiceName(instanceKey)}.title`)
            )
        ),
        icon: whetherPluginService(instanceKey) ?
            pluginList['translate'][getServiceName(instanceKey)].icon :
            builtinServices[getServiceName(instanceKey)].info.icon
    }));

    return (
        <div className="bg-white dark:bg-gray-800 rounded-xl transition-all border border-gray-100 dark:border-gray-700 shadow-sm">
            <Toaster />
            {/* Header */}
            <div
                className={`flex justify-between items-center py-2 px-3 bg-transparent h-auto cursor-grab active:cursor-grabbing ${hide ? 'rounded-xl' : 'rounded-t-xl'}`}
                {...drag}
            >
                <div className="flex items-center gap-4">
                    <Dropdown
                        value={currentTranslateServiceInstanceKey}
                        onChange={(key) => setCurrentTranslateServiceInstanceKey(key)}
                        options={serviceOptions}
                        buttonClassName="inline-flex items-center gap-1.5 h-7 px-2 text-xs font-medium text-gray-700 dark:text-gray-300 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors border-none"
                    />
                    <PulseLoader
                        loading={isLoading}
                        color={theme === 'dark' ? '#3B82F6' : '#2563EB'}
                        size={6}
                        margin={2}
                    />
                </div>

                <div className="flex">
                    <button
                        type="button"
                        className="p-1 px-2 text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 rounded-lg transition-colors"
                        onClick={() => setHide(!hide)}
                    >
                        {hide ? (
                            <ChevronDoubleDownIcon className="text-sm" />
                        ) : (
                            <ChevronDoubleUpIcon className="text-sm" />
                        )}
                    </button>
                </div>
            </div>

            {/* Content Body with Animation */}
            <animated.div style={{ ...springs, overflow: 'hidden' }}>
                <div ref={boundRef}>
                    <div className={`px-3 pt-2 pb-1 ${hide && 'pointer-events-none'}`}>
                        {typeof result === 'string' ? (
                            <textarea
                                ref={textAreaRef}
                                className={`text-[${appFontSize + 1}px] font-medium h-0 w-full resize-none bg-transparent select-text outline-none leading-relaxed text-gray-900 dark:text-gray-100 border-none p-0 overflow-hidden font-sans`}
                                readOnly
                                value={result}
                            />
                        ) : (
                            <div className="font-medium space-y-3 pb-2 text-gray-800 dark:text-gray-200 font-sans">
                                {/* Lexical/Dictionary results display logic remains here */}
                                {result['pronunciations'] && (
                                    <div className="flex flex-wrap gap-4">
                                        {result['pronunciations'].map((pronunciation) => (
                                            <div key={nanoid()} className="flex items-center">
                                                {pronunciation['region'] && (
                                                    <span className={`text-[${appFontSize}px] font-bold text-blue-600 dark:text-blue-400 mr-2`}>
                                                        {pronunciation['region']}
                                                    </span>
                                                )}
                                                {pronunciation['symbol'] && (
                                                    <span className={`text-[${appFontSize}px] text-gray-500 italic mr-2`}>
                                                        /{pronunciation['symbol']}/
                                                    </span>
                                                )}
                                                {pronunciation['voice'] && pronunciation['voice'] !== '' && (
                                                    <HiOutlineSpeakerWave
                                                        className="text-blue-500 cursor-pointer hover:scale-110 transition-transform"
                                                        onClick={() => speak(pronunciation['voice'])}
                                                    />
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {result['explanations'] && result['explanations'].map((ex) => (
                                    <div key={nanoid()} className="space-y-1">
                                        <div className="flex items-baseline gap-2">
                                            <span className={`text-[${appFontSize - 2}px] font-extrabold text-purple-600 dark:text-purple-400 uppercase`}>
                                                {ex['trait']}
                                            </span>
                                            <div className="flex-1 space-y-1">
                                                {ex['explains'].map((explain, idx) => (
                                                    <div key={nanoid()} className={idx === 0 ? `font-bold text-[${appFontSize + 2}px]` : `text-[${appFontSize}px] text-gray-600 dark:text-gray-400 pl-4`}>
                                                        {idx > 0 && "• "}{explain}
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                {result['associations'] && (
                                    <div className="flex flex-wrap gap-2 pt-1 border-t border-gray-100 dark:border-gray-700">
                                        {result['associations'].map((association) => (
                                            <span key={nanoid()} className={`text-[${appFontSize}px] text-gray-400 italic`}>
                                                {association}
                                            </span>
                                        ))}
                                    </div>
                                )}

                                {result['sentence'] && (
                                    <div className="pt-3 border-t border-gray-100 dark:border-gray-700 space-y-3">
                                        {result['sentence'].map((sentence, idx) => (
                                            <div key={nanoid()} className="flex gap-3">
                                                <span className="text-gray-300 dark:text-gray-600 font-bold text-xs pt-1">{idx + 1}</span>
                                                <div className="flex-1">
                                                    {sentence['source'] && (
                                                        <div className={`text-[${appFontSize}px] text-gray-700 dark:text-gray-300 leading-snug`} dangerouslySetInnerHTML={{ __html: sentence['source'] }} />
                                                    )}
                                                    {sentence['target'] && (
                                                        <div className={`text-[${appFontSize - 1}px] text-gray-500 dark:text-gray-400 italic mt-0.5`} dangerouslySetInnerHTML={{ __html: sentence['target'] }} />
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}

                        {error !== '' && (
                            <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg mt-2 mb-2 border border-red-100 dark:border-red-900/30">
                                {error.split('\n').map((v) => (
                                    <p key={v} className={`text-[${appFontSize - 2}px] text-red-600 dark:text-red-400 font-medium`}>
                                        {v}
                                    </p>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Footer Actions */}
                    <div className={`flex items-center gap-1.5 px-2 py-1 bg-gray-50/50 dark:bg-gray-800/30 rounded-b-xl border-t border-gray-100 dark:border-gray-700/50 ${hide && 'hidden'}`}>
                        <div className="flex bg-white/50 dark:bg-gray-800/50 rounded-lg p-0.5 shadow-sm border border-gray-200/50 dark:border-gray-700/50">
                            {/* Speak Button */}
                            <button
                                type="button"
                                title={t('translate.speak')}
                                disabled={typeof result !== 'string' || result === ''}
                                className="p-1.5 text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-gray-700 rounded-md transition-all disabled:opacity-30"
                                onClick={() => handleSpeak().catch(e => toast.error(e.toString(), { style: toastStyle }))}
                            >
                                <HiOutlineSpeakerWave className="text-base" />
                            </button>

                            {/* Copy Button */}
                            <button
                                type="button"
                                title={t('translate.copy')}
                                disabled={typeof result !== 'string' || result === ''}
                                className="p-1.5 text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-gray-700 rounded-md transition-all disabled:opacity-30"
                                onClick={() => { writeText(result); toast.success(t('translate.copy_success'), { style: toastStyle }); }}
                            >
                                <HiOutlineDocumentDuplicate className="text-base" />
                            </button>

                            {/* Translate Back Button */}
                            <button
                                type="button"
                                title={t('translate.translate_back')}
                                disabled={typeof result !== 'string' || result === ''}
                                className="p-1.5 text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-gray-700 rounded-md transition-all disabled:opacity-30"
                                onClick={async () => {
                                    // Translate back logic 
                                    setError('');
                                    let newTargetLanguage = sourceLanguage === 'auto' ? detectLanguage : sourceLanguage;
                                    let newSourceLanguage = sourceLanguage === 'auto' ? 'auto' : targetLanguage;

                                    if (whetherPluginService(currentTranslateServiceInstanceKey)) {
                                        const pluginInfo = pluginList['translate'][getServiceName(currentTranslateServiceInstanceKey)];
                                        if (newSourceLanguage in pluginInfo.language && newTargetLanguage in pluginInfo.language) {
                                            setIsLoading(true); setHide(true);
                                            const instanceConfig = serviceInstanceConfigMap[currentTranslateServiceInstanceKey];
                                            const setHideOnce = invokeOnce(setHide);
                                            let [func, utils] = await invoke_plugin('translate', getServiceName(currentTranslateServiceInstanceKey));
                                            func(result.trim(), pluginInfo.language[newSourceLanguage], pluginInfo.language[newTargetLanguage], {
                                                config: instanceConfig, detect: detectLanguage,
                                                setResult: (v) => { setResult(v); setHideOnce(false); },
                                                utils,
                                            }).then(v => {
                                                setResult(v === result ? v + ' ' : v.trim());
                                                setIsLoading(false); if (v !== '') setHideOnce(false);
                                            }, e => { setError(e.toString()); setIsLoading(false); });
                                        } else setError('Language not supported');
                                    } else {
                                        const LanguageEnum = builtinServices[getServiceName(currentTranslateServiceInstanceKey)].Language;
                                        if (newSourceLanguage in LanguageEnum && newTargetLanguage in LanguageEnum) {
                                            setIsLoading(true); setHide(true);
                                            const instanceConfig = serviceInstanceConfigMap[currentTranslateServiceInstanceKey];
                                            const setHideOnce = invokeOnce(setHide);
                                            builtinServices[getServiceName(currentTranslateServiceInstanceKey)]
                                                .translate(result.trim(), LanguageEnum[newSourceLanguage], LanguageEnum[newTargetLanguage], {
                                                    config: instanceConfig, detect: newSourceLanguage,
                                                    setResult: (v) => { setResult(v); setHideOnce(false); },
                                                }).then(v => {
                                                    setResult(v === result ? v + ' ' : v.trim());
                                                    setIsLoading(false); if (v !== '') setHideOnce(false);
                                                }, e => { setError(e.toString()); setIsLoading(false); });
                                        } else setError('Language not supported');
                                    }
                                }}
                            >
                                <HiOutlineArrowsRightLeft className="text-base" />
                            </button>

                            {/* Retry Button */}
                            {error !== '' && (
                                <button
                                    type="button"
                                    title={t('translate.retry')}
                                    className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-white dark:hover:bg-gray-700 rounded-md transition-all animate-none active:rotate-180"
                                    onClick={() => { setError(''); setResult(''); translate(); }}
                                >
                                    <HiOutlineArrowPath className="text-base" />
                                </button>
                            )}
                        </div>

                        {/* Collection Services */}
                        {collectionServiceList && collectionServiceList.map((collectionKey) => (
                            <button
                                key={collectionKey}
                                title={t(`services.collection.${getServiceName(collectionKey)}.title`)}
                                className="p-1.5 text-gray-400 hover:text-green-600 dark:hover:text-green-400 rounded-lg transition-colors"
                                onClick={async () => {
                                    const collectionServiceName = getServiceName(collectionKey);
                                    const instanceConfig = serviceInstanceConfigMap[collectionKey];
                                    if (getServiceSouceType(collectionKey) === ServiceSourceType.PLUGIN) {
                                        let [func, utils] = await invoke_plugin('collection', collectionServiceName);
                                        func(sourceText, targetLanguage, result, { config: instanceConfig, utils }).then(() => {
                                            toast.success(t('translate.add_collection_success'), { style: toastStyle });
                                        }, e => toast.error(e.toString(), { style: toastStyle }));
                                    } else {
                                        builtinCollectionServices[collectionServiceName]
                                            .addCollection(sourceText, targetLanguage, result, { config: instanceConfig }).then(() => {
                                                toast.success(t('translate.add_collection_success'), { style: toastStyle });
                                            }, e => toast.error(e.toString(), { style: toastStyle }));
                                    }
                                }}
                            >
                                <img
                                    src={getServiceSouceType(collectionKey) === ServiceSourceType.PLUGIN ?
                                        pluginList['collection'][getServiceName(collectionKey)].icon :
                                        builtinCollectionServices[getServiceName(collectionKey)].info.icon}
                                    className="h-4 w-4 grayscale hover:grayscale-0 transition-all opacity-70 hover:opacity-100"
                                />
                            </button>
                        ))}
                    </div>
                </div>
            </animated.div>
        </div>
    );
}

