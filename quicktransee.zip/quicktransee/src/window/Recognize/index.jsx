import { readDir, BaseDirectory, readTextFile, exists } from '@tauri-apps/api/fs';
import { appConfigDir, join } from '@tauri-apps/api/path';
import { convertFileSrc } from '@tauri-apps/api/tauri';
import { appWindow } from '@tauri-apps/api/window';
import { useState, useEffect } from 'react';
import { listen } from '@tauri-apps/api/event';
import { VscPinned } from 'react-icons/vsc';
import { atom, useAtom } from 'jotai';
import { initFlowbite } from 'flowbite';

import WindowControl from '../../components/WindowControl';
import { store } from '../../utils/store';
import { osType } from '../../utils/env';
import { useConfig } from '../../hooks';
import ControlArea from './ControlArea';
import ImageArea from './ImageArea';
import TextArea from './TextArea';

export const pluginListAtom = atom();

let blurTimeout = null;

const listenBlur = () => {
    return listen('tauri://blur', () => {
        if (appWindow.label === 'recognize') {
            if (blurTimeout) {
                clearTimeout(blurTimeout);
            }
            // 50ms后关闭窗口，因为在 windows 下拖动窗口时会先切换成 blur 再立即切换成 focus
            // 如果直接关闭将导致窗口无法拖动
            blurTimeout = setTimeout(async () => {
                await appWindow.close();
            }, 50);
        }
    });
};

let unlisten = listenBlur();
// 取消 blur 监听
const unlistenBlur = () => {
    unlisten.then((f) => {
        f();
    });
};

// 监听 focus 事件取消 blurTimeout 时间之内的关闭窗口
void listen('tauri://focus', () => {
    if (blurTimeout) {
        clearTimeout(blurTimeout);
    }
});

export default function Recognize() {
    const [pluginList, setPluginList] = useAtom(pluginListAtom);
    const [closeOnBlur] = useConfig('recognize_close_on_blur', false);
    const [pined, setPined] = useState(false);
    const [serviceInstanceList] = useConfig('recognize_service_list', ['tesseract', 'system']);
    const [serviceInstanceConfigMap, setServiceInstanceConfigMap] = useState(null);

    const loadPluginList = async () => {
        let temp = {};
        if (await exists(`plugins/recognize`, { dir: BaseDirectory.AppConfig })) {
            const plugins = await readDir(`plugins/recognize`, { dir: BaseDirectory.AppConfig });
            for (const plugin of plugins) {
                const infoStr = await readTextFile(`plugins/recognize/${plugin.name}/info.json`, {
                    dir: BaseDirectory.AppConfig,
                });
                let pluginInfo = JSON.parse(infoStr);
                if ('icon' in pluginInfo) {
                    const appConfigDirPath = await appConfigDir();
                    const iconPath = await join(
                        appConfigDirPath,
                        `/plugins/recognize/${plugin.name}/${pluginInfo.icon}`
                    );
                    pluginInfo.icon = convertFileSrc(iconPath);
                }
                temp[plugin.name] = pluginInfo;
            }
        }
        setPluginList({ ...temp });
    };
    const loadServiceInstanceConfigMap = async () => {
        const config = {};
        for (const serviceInstanceKey of serviceInstanceList) {
            config[serviceInstanceKey] = (await store.get(serviceInstanceKey)) ?? {};
        }
        setServiceInstanceConfigMap({ ...config });
    };
    useEffect(() => {
        if (serviceInstanceList !== null) {
            loadServiceInstanceConfigMap();
        }
    }, [serviceInstanceList]);

    useEffect(() => {
        loadPluginList();
    }, []);

    useEffect(() => {
        if (pluginList && serviceInstanceConfigMap) {
            // Init flowbite
            setTimeout(() => initFlowbite(), 100);
        }
    }, [pluginList, serviceInstanceConfigMap]);
    // 是否自动关闭窗口
    useEffect(() => {
        if (closeOnBlur !== null && !closeOnBlur) {
            unlistenBlur();
        }
    }, [closeOnBlur]);

    return (
        pluginList &&
        serviceInstanceConfigMap !== null && (
            <div
                className={`bg-white dark:bg-gray-900 h-screen w-screen flex flex-col min-w-[600px] min-h-[300px] overflow-hidden ${osType === 'Linux' && 'rounded-lg border border-gray-200 dark:border-gray-700'
                    }`}
            >
                {/* Header */}
                <div className="flex-none flex flex-col">
                    <div className="h-1 w-full" />
                    <div
                        className={`h-[48px] w-full flex items-center px-4 z-[60] relative ${osType === 'Darwin' ? 'justify-end' : 'justify-between'}`}
                        data-tauri-drag-region='true'
                    >
                        <button
                            type="button"
                            className="p-1.5 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors group relative z-[70]"
                            onClick={() => {
                                if (pined) {
                                    if (closeOnBlur) {
                                        unlisten = listenBlur();
                                    }
                                    appWindow.setAlwaysOnTop(false);
                                } else {
                                    unlistenBlur();
                                    appWindow.setAlwaysOnTop(true);
                                }
                                setPined(!pined);
                            }}
                        >
                            <VscPinned className={`text-lg transition-colors ${pined ? 'text-blue-500' : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-400'}`} />
                        </button>
                        {osType !== 'Darwin' && (
                            <div className="relative z-[70]">
                                <WindowControl />
                            </div>
                        )}
                    </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 relative min-h-0">
                    <div className="absolute inset-0 grid grid-cols-2 overflow-hidden pb-1">
                        <ImageArea />
                        <TextArea serviceInstanceConfigMap={serviceInstanceConfigMap} />
                    </div>
                </div>

                {/* Footer Area */}
                <div className='flex-none py-3 px-1'>
                    <ControlArea
                        serviceInstanceList={serviceInstanceList}
                        serviceInstanceConfigMap={serviceInstanceConfigMap}
                        pluginList={pluginList}
                    />
                </div>
            </div>
        )
    );
}
