// import { Card, CardBody, CardFooter, Button, Tooltip } from '@nextui-org/react'; // Removed
import { appWindow } from '@tauri-apps/api/window';
import React, { useEffect, useRef } from 'react';
import { listen } from '@tauri-apps/api/event';
import { HiOutlineDocumentDuplicate } from 'react-icons/hi2';
import { useTranslation } from 'react-i18next';
import { invoke } from '@tauri-apps/api/tauri';
import { atom, useAtom } from 'jotai';

import { useConfig } from '../../../hooks';

export const base64Atom = atom('');
let unlisten = null;

export default function ImageArea() {
    const [hideWindow] = useConfig('recognize_hide_window', false);
    const [base64, setBase64] = useAtom(base64Atom);
    const imgRef = useRef();
    const { t } = useTranslation();
    const load_img = () => {
        invoke('get_base64').then((v) => {
            setBase64(v);
            if (hideWindow) {
                appWindow.hide();
            } else {
                appWindow.show();
                appWindow.setFocus(true);
            }
        });
    };

    useEffect(() => {
        if (hideWindow !== null) {
            load_img();
            if (unlisten) {
                unlisten.then((f) => {
                    f();
                });
            }
            unlisten = listen('new_image', (_) => {
                load_img();
            });
        }
    }, [hideWindow]);

    return (
        <div className="block bg-white border border-gray-200 rounded-lg shadow h-full ml-[12px] mr-[6px] dark:bg-gray-800 dark:border-gray-700 flex flex-col">
            <div className='flex-1 p-0 overflow-hidden relative'>
                {base64 !== '' && (
                    <img
                        ref={imgRef}
                        draggable={false}
                        className='object-contain h-full w-full'
                        src={'data:image/png;base64,' + base64}
                    />
                )}
            </div>
            <div className='flex justify-start px-[12px] py-2 border-t border-gray-200 dark:border-gray-700'>
                <button
                    data-tooltip-target="tooltip-copy-image"
                    type="button"
                    className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm p-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                    onClick={async () => {
                        await invoke('copy_img', {
                            width: imgRef.current.naturalWidth,
                            height: imgRef.current.naturalHeight,
                        });
                    }}
                >
                    <HiOutlineDocumentDuplicate className='text-[16px]' />
                </button>
                <div id="tooltip-copy-image" role="tooltip" className="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                    {t('recognize.copy_img')}
                    <div className="tooltip-arrow" data-popper-arrow></div>
                </div>
            </div>
        </div>
    );
}
