import { atom, useAtom, useSetAtom, useAtomValue } from 'jotai';
import { fetch, Body } from '@tauri-apps/api/http';
import { useTranslation } from 'react-i18next';
import { LanguageIcon, ArrowPathIcon } from '../../../components/Icons';
import { useEffect } from 'react';
import { nanoid } from 'nanoid';
import * as builtinService from '../../../services/recognize';
import { languageList } from '../../../utils/language';
import { useConfig } from '../../../hooks';
import { textAtom } from '../TextArea';
import { pluginListAtom } from '..';
import { osType } from '../../../utils/env';
import {
    ServiceSourceType,
    getServiceSouceType,
    getServiceName,
    INSTANCE_NAME_CONFIG_KEY,
    getDisplayInstanceName,
} from '../../../utils/service_instance';
import Dropdown from '../../../components/Dropdown';

export const currentServiceInstanceKeyAtom = atom();
export const languageAtom = atom();
export const recognizeFlagAtom = atom();

export default function ControlArea(props) {
    const { serviceInstanceConfigMap, serviceInstanceList } = props;
    const pluginList = useAtomValue(pluginListAtom);
    const [recognizeLanguage] = useConfig('recognize_language', 'auto');
    const [serverPort] = useConfig('server_port', 60828);
    const setRecognizeFlag = useSetAtom(recognizeFlagAtom);
    const [currentServiceInstanceKey, setCurrentServiceInstanceKey] = useAtom(currentServiceInstanceKeyAtom);
    const [language, setLanguage] = useAtom(languageAtom);
    const text = useAtomValue(textAtom);
    const { t } = useTranslation();

    function getInstanceName(instanceKey, serviceNameSupplier) {
        const instanceConfig = serviceInstanceConfigMap[instanceKey] ?? {};
        return getDisplayInstanceName(instanceConfig[INSTANCE_NAME_CONFIG_KEY], serviceNameSupplier);
    }

    useEffect(() => {
        if (serviceInstanceList) {
            setCurrentServiceInstanceKey(serviceInstanceList[0]);
        }
        if (recognizeLanguage) {
            setLanguage(recognizeLanguage);
        }
    }, [serviceInstanceList, recognizeLanguage]);

    const serviceOptions = serviceInstanceList ? serviceInstanceList.map(instanceKey => {
        const isPlugin = getServiceSouceType(instanceKey) === ServiceSourceType.PLUGIN;
        const serviceName = getServiceName(instanceKey);

        if (isPlugin) {
            if (!pluginList) return null;
            const plugin = pluginList[serviceName];
            if (!plugin) return null;
            return {
                value: instanceKey,
                label: getInstanceName(instanceKey, () => plugin.display),
                icon: plugin.icon
            };
        } else {
            const service = builtinService[serviceName];
            if (!service) return null;
            return {
                value: instanceKey,
                label: getInstanceName(instanceKey, () => t(`services.recognize.${instanceKey}.title`)),
                icon: service.info.icon === 'system'
                    ? `logo/${osType}.svg`
                    : service.info.icon
            };
        }
    }).filter(Boolean) : [];

    const languageOptions = [
        { value: 'auto', label: t('languages.auto') },
        ...languageList.map(name => ({
            value: name,
            label: t(`languages.${name}`)
        }))
    ];

    return (
        <div className='flex items-center justify-between gap-2 px-3 h-full pb-1'>
            <div className="flex items-center gap-2 flex-1 min-w-0 mr-2">
                {currentServiceInstanceKey && (
                    <Dropdown
                        value={currentServiceInstanceKey}
                        onChange={(val) => setCurrentServiceInstanceKey(val)}
                        options={serviceOptions}
                        className="flex-1 min-w-[120px] max-w-[180px]"
                        placement="top"
                    />
                )}
                {language && (
                    <Dropdown
                        value={language}
                        onChange={(val) => setLanguage(val)}
                        options={languageOptions}
                        showSearch={true}
                        className="flex-1 min-w-[110px] max-w-[150px]"
                        placement="top"
                    />
                )}
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
                <button
                    type="button"
                    className="text-purple-700 hover:text-white border border-purple-700 hover:bg-purple-800 focus:ring-4 focus:outline-none focus:ring-purple-300 font-medium rounded-lg text-sm px-3 py-1.5 text-center dark:border-purple-400 dark:text-purple-400 dark:hover:text-white dark:hover:bg-purple-500 dark:focus:ring-purple-900 inline-flex items-center my-auto"
                    onClick={() => {
                        setRecognizeFlag(nanoid());
                    }}
                >
                    <ArrowPathIcon className='text-[16px] mr-2' />
                    {t('recognize.recognize')}
                </button>
                <button
                    type="button"
                    className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-3 py-1.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 inline-flex items-center my-auto"
                    onClick={async () => {
                        if (text) {
                            void fetch(`http://127.0.0.1:${serverPort}/translate`, {
                                method: 'POST',
                                body: Body.text(text),
                                responseType: 2,
                            });
                        }
                    }}
                >
                    <LanguageIcon className='text-[16px] mr-2' />
                    {t('recognize.translate')}
                </button>
            </div>
        </div>
    );
}
