import Database from 'tauri-plugin-sql-api';
import { fetch, Body } from '@tauri-apps/api/http';
import { store } from './store';


/**
 * Get DeepL API configuration from store
 * @returns {Promise<{authKey: string, customUrl: string}>}
 */
async function getDeepLConfig() {
    // 1. Try to get the list of translation services
    const serviceList = await store.get('translate_service_list');
    let deeplConfig = null;

    if (Array.isArray(serviceList)) {
        // 2. Find a DeepL instance (either 'deepl' or 'deepl@...')
        for (const key of serviceList) {
            if (key === 'deepl' || key.startsWith('deepl@')) {
                const config = await store.get(key);
                // Check if this instance has an authKey configured
                if (config && config.authKey) {
                    deeplConfig = config;
                    break;
                }
            }
        }
    }

    // Fallback: Check the legacy/default 'deepl' key directly if not found in list
    if (!deeplConfig) {
        deeplConfig = await store.get('deepl');
    }

    if (!deeplConfig || !deeplConfig.authKey) {
        throw new Error('DeepL API key not configured. Please configure it in Settings > Services > DeepL');
    }
    return {
        authKey: deeplConfig.authKey,
        customUrl: deeplConfig.customUrl || 'https://api.deepl.com'
    };
}

/**
 * Get the base API URL (remove /v2/translate if present)
 * @param {string} customUrl 
 * @returns {string}
 */
function getBaseUrl(customUrl) {
    if (customUrl.includes('/v2/translate')) {
        return customUrl.replace('/v2/translate', '');
    }
    return customUrl;
}

/**
 * Convert dictionary entries to TSV format for DeepL API
 * @param {Array<{key: string, value: string}>} entries 
 * @returns {string}
 */
function entriesToTSV(entries) {
    return entries.map(entry => `${entry.key}\t${entry.value}`).join('\n');
}

/**
 * Function 1: Create a glossary from project dictionary entries and update glossary_id
 * @param {number} projectId - Selected project ID
 * @param {string} sourceLang - Source language (e.g., 'en', 'ja')
 * @param {string} targetLang - Target language (e.g., 'vi', 'en')
 * @returns {Promise<{glossary_id: string, name: string, ready: boolean}>}
 */
export async function createGlossary(projectId, sourceLang, targetLang) {
    try {
        // 1. Get project information
        const projectDb = await Database.load('sqlite:project.db');
        const projects = await projectDb.select('SELECT * FROM project WHERE id = $1', [projectId]);

        if (!projects || projects.length === 0) {
            throw new Error('Project not found');
        }

        const project = projects[0];

        // 2. Get all dictionary entries for the project
        const dictDb = await Database.load('sqlite:dictionary.db');
        const entries = await dictDb.select(
            'SELECT key, value FROM dictionary WHERE project_id = $1 ORDER BY id',
            [projectId]
        );

        if (!entries || entries.length === 0) {
            throw new Error('No dictionary entries found for this project');
        }

        // 3. Get DeepL configuration
        const deeplConfig = await getDeepLConfig();
        const baseUrl = getBaseUrl(deeplConfig.customUrl);

        // 4. Convert entries to TSV format
        const tsvEntries = entriesToTSV(entries);

        // 5. Create request body for DeepL API
        const requestBody = {
            name: `${project.name} Glossary`,
            dictionaries: [
                {
                    source_lang: sourceLang.toLowerCase(),
                    target_lang: targetLang.toLowerCase(),
                    entries: tsvEntries,
                    entries_format: 'tsv'
                }
            ]
        };

        // 6. Call API to create glossary
        const response = await fetch(`${baseUrl}/v3/glossaries`, {
            method: 'POST',
            headers: {
                'Authorization': `DeepL-Auth-Key ${deeplConfig.authKey}`,
                'Content-Type': 'application/json'
            },
            body: Body.json(requestBody)
        });

        if (!response.ok) {
            const errorMsg = response.data?.message || response.data?.error || 'Unknown error';
            throw new Error(`DeepL API Error (${response.status}): ${errorMsg}`);
        }

        const result = response.data;

        // 7. Update glossary_id in project (only allow one project to have a glossary_id at a time)
        await projectDb.execute('UPDATE project SET glossary_id = NULL');
        await projectDb.execute(
            'UPDATE project SET glossary_id = $1 WHERE id = $2',
            [result.glossary_id, projectId]
        );

        return {
            glossary_id: result.glossary_id,
            name: result.name,
            ready: result.ready,
            creation_time: result.creation_time
        };

    } catch (error) {
        console.error('Error creating glossary:', error);
        throw error;
    }
}

/**
 * Function 2: Delete all glossaries on the DeepL server and reset glossary_id in the database
 * @returns {Promise<boolean>}
 */
export async function deleteGlossary() {
    try {
        // 1. Get DeepL configuration
        const deeplConfig = await getDeepLConfig();
        const baseUrl = getBaseUrl(deeplConfig.customUrl);
        const authHeader = { 'Authorization': `DeepL-Auth-Key ${deeplConfig.authKey}` };

        // 2. Get all glossaries currently on the server
        const glossaries = await listGlossaries();

        // 3. Delete each glossary on the server if it exists
        if (glossaries && glossaries.length > 0) {
            for (const g of glossaries) {
                try {
                    await fetch(`${baseUrl}/v3/glossaries/${g.glossary_id}`, {
                        method: 'DELETE',
                        headers: authHeader
                    });
                    console.log(`Successfully deleted glossary ${g.glossary_id} from DeepL server`);
                } catch (err) {
                    console.warn(`Could not delete glossary ${g.glossary_id}:`, err);
                }
            }
        }

        // 4. Delete all glossary_id in project.db (Reset all)
        const projectDb = await Database.load('sqlite:project.db');
        await projectDb.execute('UPDATE project SET glossary_id = NULL');

        console.log('Reset all glossary_id in database and cleared DeepL server glossaries');
        return true;

    } catch (error) {
        console.error('Error in deleteGlossary (cleanup):', error);
        throw error;
    }
}

/**
 * Function 3: Replace or create a dictionary in the glossary with new entries
 * @param {number} projectId - Selected project ID
 * @param {string} sourceLang - Source language (e.g., 'en', 'ja')
 * @param {string} targetLang - Target language (e.g., 'vi', 'en')
 * @returns {Promise<{source_lang: string, target_lang: string, entry_count: number}>}
 */
export async function updateGlossaryDictionary(projectId, sourceLang, targetLang) {
    try {
        // 1. Get project information and glossary_id
        const projectDb = await Database.load('sqlite:project.db');
        const projects = await projectDb.select('SELECT * FROM project WHERE id = $1', [projectId]);

        if (!projects || projects.length === 0) {
            throw new Error('Project not found');
        }

        const project = projects[0];

        if (!project.glossary_id) {
            throw new Error('No glossary_id found for this project. Please create a glossary first.');
        }

        // 2. Get all dictionary entries for the project
        const dictDb = await Database.load('sqlite:dictionary.db');
        const entries = await dictDb.select(
            'SELECT key, value FROM dictionary WHERE project_id = $1 ORDER BY id',
            [projectId]
        );

        if (!entries || entries.length === 0) {
            throw new Error('No dictionary entries found for this project');
        }

        // 3. Get DeepL configuration
        const deeplConfig = await getDeepLConfig();
        const baseUrl = getBaseUrl(deeplConfig.customUrl);

        // 4. Convert entries to TSV format
        const tsvEntries = entriesToTSV(entries);

        // 5. Create request body
        const requestBody = {
            source_lang: sourceLang.toLowerCase(),
            target_lang: targetLang.toLowerCase(),
            entries: tsvEntries,
            entries_format: 'tsv'
        };

        // 6. Call API to update dictionary (PUT method)
        const response = await fetch(`${baseUrl}/v3/glossaries/${project.glossary_id}/dictionaries`, {
            method: 'PUT',
            headers: {
                'Authorization': `DeepL-Auth-Key ${deeplConfig.authKey}`,
                'Content-Type': 'application/json'
            },
            body: Body.json(requestBody)
        });

        if (!response.ok) {
            const errorMsg = response.data?.message || response.data?.error || 'Unknown error';
            throw new Error(`DeepL API Error (${response.status}): ${errorMsg}`);
        }

        const result = response.data;

        return {
            source_lang: result.source_lang,
            target_lang: result.target_lang,
            entry_count: result.entry_count
        };

    } catch (error) {
        console.error('Error updating glossary dictionary:', error);
        throw error;
    }
}

/**
 * Function 4: Check if any Glossary exists on the DeepL server for this account
 * @returns {Promise<boolean>} - Returns true if there is at least 1 glossary, otherwise false
 */
export async function hasAnyGlossaryOnServer() {
    try {
        const glossaries = await listGlossaries();
        return glossaries.length > 0;
    } catch (error) {
        console.error('Error checking for any glossary on server:', error);
        throw error;
    }
}

/**
 * Helper: Get glossary information from DeepL API
 * @param {string} glossaryId 
 * @returns {Promise<Object>}
 */
export async function getGlossaryInfo(glossaryId) {
    try {
        const deeplConfig = await getDeepLConfig();
        const baseUrl = getBaseUrl(deeplConfig.customUrl);

        const response = await fetch(`${baseUrl}/v3/glossaries/${glossaryId}`, {
            method: 'GET',
            headers: {
                'Authorization': `DeepL-Auth-Key ${deeplConfig.authKey}`
            }
        });

        if (!response.ok) {
            const errorMsg = response.data?.message || response.data?.error || 'Unknown error';
            throw new Error(`DeepL API Error (${response.status}): ${errorMsg}`);
        }

        return response.data;

    } catch (error) {
        console.error('Error getting glossary info:', error);
        throw error;
    }
}

/**
 * Helper: List all glossaries
 * @returns {Promise<Array>}
 */
export async function listGlossaries() {
    try {
        const deeplConfig = await getDeepLConfig();
        const baseUrl = getBaseUrl(deeplConfig.customUrl);

        const response = await fetch(`${baseUrl}/v3/glossaries`, {
            method: 'GET',
            headers: {
                'Authorization': `DeepL-Auth-Key ${deeplConfig.authKey}`
            }
        });

        if (!response.ok) {
            const errorMsg = response.data?.message || response.data?.error || 'Unknown error';
            throw new Error(`DeepL API Error (${response.status}): ${errorMsg}`);
        }

        return response.data.glossaries || [];

    } catch (error) {
        console.error('Error listing glossaries:', error);
        throw error;
    }
}

/**
 * Check if the glossary matches the current source and target languages
 * @param {string} glossaryId 
 * @param {string} sourceLang 
 * @param {string} targetLang 
 * @returns {Promise<boolean>}
 */
export async function checkGlossaryLanguageMatch(glossaryId, sourceLang, targetLang) {
    if (!glossaryId) return false;
    try {
        const info = await getGlossaryInfo(glossaryId);
        if (!info) return false;

        // DeepL API v3 returns language info inside 'dictionaries' array
        if (info.dictionaries && Array.isArray(info.dictionaries)) {
            return info.dictionaries.some(dict =>
                dict.source_lang.toLowerCase() === sourceLang.toLowerCase() &&
                dict.target_lang.toLowerCase() === targetLang.toLowerCase()
            );
        }

        // Fallback: DeepL API v2 or other structure returns source_lang and target_lang directly
        if (info.source_lang && info.target_lang) {
            return info.source_lang.toLowerCase() === sourceLang.toLowerCase() &&
                info.target_lang.toLowerCase() === targetLang.toLowerCase();
        }

        return false;
    } catch (error) {
        // If glossary not found or API error, consider it a mismatch
        console.warn('Glossary language match check failed:', error);
        return false;
    }
}
