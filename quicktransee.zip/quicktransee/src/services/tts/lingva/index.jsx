import { fetch, ResponseType } from '@tauri-apps/api/http';

export async function tts(text, lang, options = {}) {
    const { config } = options;
    let { custom_url } = config;

    if (!custom_url) {
        custom_url = 'https://lingva.ml';
    }
    if (!custom_url.startsWith('http')) {
        custom_url = 'https://' + custom_url;
    }

    const res = await fetch(`${custom_url}/api/v1/audio/${lang}/${encodeURIComponent(text)}`, {
        method: 'GET',
        responseType: ResponseType.Binary,
    });

    if (res.ok) {
        return res.data;
    } else {
        throw `Http Request Error\nHttp Status: ${res.status}`;
    }
}

export * from './Config';
export * from './info';
