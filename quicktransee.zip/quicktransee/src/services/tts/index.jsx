import * as _lingva_tts from './lingva';

export const lingva_tts = _lingva_tts;
