export const info = {
    name: 'anki',
    icon: 'logo/anki.svg',
};
