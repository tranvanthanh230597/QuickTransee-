export const info = {
    name: 'eudic',
    icon: 'logo/eudic.png',
};
