import * as _anki from './anki';
import * as _eudic from './eudic';

export const anki = _anki;
export const eudic = _eudic;
