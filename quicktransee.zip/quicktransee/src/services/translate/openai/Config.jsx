import { INSTANCE_NAME_CONFIG_KEY } from '../../../utils/service_instance';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { open } from '@tauri-apps/api/shell';
import React, { useState } from 'react';
import { DeleteIcon } from '../../../components/Icons';

import { useConfig } from '../../../hooks/useConfig';
import { useToastStyle } from '../../../hooks';
import { translate } from './index';
import { Language } from './index';
import Dropdown from '../../../components/Dropdown';

export const defaultRequestArguments = JSON.stringify({
    temperature: 0.1,
    top_p: 0.99,
    frequency_penalty: 0,
    presence_penalty: 0,
});

export function Config(props) {
    const { instanceKey, updateServiceList, onClose } = props;
    const { t } = useTranslation();
    const [openaiConfig, setOpenaiConfig] = useConfig(
        instanceKey,
        {
            [INSTANCE_NAME_CONFIG_KEY]: t('services.translate.openai.title'),
            service: 'openai',
            requestPath: 'https://api.openai.com/v1/chat/completions',
            model: 'gpt-3.5-turbo',
            apiKey: '',
            stream: false,
            promptList: [
                {
                    role: 'system',
                    content:
                        'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                },
                { role: 'user', content: `Translate into $to:\n"""\n$text\n"""` },
            ],
            requestArguments: defaultRequestArguments,
        },
        { sync: false }
    );
    React.useEffect(() => {
        if (openaiConfig) {
            if (openaiConfig.promptList === undefined || openaiConfig.requestArguments === undefined) {
                setOpenaiConfig({
                    ...openaiConfig,
                    promptList: openaiConfig.promptList ?? [
                        {
                            role: 'system',
                            content:
                                'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                        },
                        { role: 'user', content: `Translate into $to:\n"""\n$text\n"""` },
                    ],
                    requestArguments: openaiConfig.requestArguments ?? defaultRequestArguments,
                });
            }
        }
    }, [openaiConfig]);

    const [isLoading, setIsLoading] = useState(false);

    const toastStyle = useToastStyle();

    return (
        openaiConfig !== null && (
            <form
                className="flex flex-col overflow-hidden h-full"
                onSubmit={(e) => {
                    e.preventDefault();
                    setIsLoading(true);
                    translate('hello', Language.auto, Language.zh_cn, { config: openaiConfig }).then(
                        () => {
                            setIsLoading(false);
                            setOpenaiConfig(openaiConfig, true);
                            updateServiceList(instanceKey);
                            onClose();
                        },
                        (e) => {
                            setIsLoading(false);
                            toast.error(t('config.service.test_failed') + e.toString(), { style: toastStyle });
                        }
                    );
                }}
            >
                <Toaster />

                <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                    {/* Instance Name */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.instance_name')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={openaiConfig[INSTANCE_NAME_CONFIG_KEY]}
                            onChange={(e) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    [INSTANCE_NAME_CONFIG_KEY]: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Help Button */}
                    <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">{t('services.help')}</h3>
                        <button
                            type="button"
                            onClick={() => open('https://gitlab.aureole-it.vn/binhlp/quicktransee/')}
                            className="py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                            {t('services.help')}
                        </button>
                    </div>

                    {/* Service Type Selection */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.openai.service')}
                        </label>
                        <Dropdown
                            value={openaiConfig.service}
                            onChange={(val) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    service: val,
                                });
                            }}
                            options={[
                                { value: 'openai', label: t(`services.translate.openai.openai`) },
                                { value: 'azure', label: t(`services.translate.openai.azure`) }
                            ]}
                        />
                    </div>

                    {/* Stream Toggle */}
                    <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-300">
                            {t('services.translate.openai.stream')}
                        </span>
                        <label className="inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                checked={openaiConfig['stream']}
                                onChange={(e) => {
                                    setOpenaiConfig({
                                        ...openaiConfig,
                                        stream: e.target.checked
                                    });
                                }}
                                className="sr-only peer"
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    {/* Request Path */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.openai.request_path')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={openaiConfig['requestPath']}
                            onChange={(e) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    requestPath: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* API Key */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.openai.api_key')}
                        </label>
                        <input
                            type="password"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={openaiConfig['apiKey']}
                            onChange={(e) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    apiKey: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Model (Hidden for Azure) */}
                    <div className={openaiConfig.service === 'azure' ? 'hidden' : ''}>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.openai.model')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={openaiConfig['model']}
                            onChange={(e) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    model: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Prompt List */}
                    <div>
                        <h3 className='text-sm font-medium text-gray-900 dark:text-white mb-1'>Prompt List</h3>
                        <p className='text-xs text-gray-500 dark:text-gray-400 mb-2'>
                            {t('services.translate.openai.prompt_description')}
                        </p>

                        <div className='bg-gray-50 dark:bg-gray-700 rounded-lg p-3 space-y-3'>
                            {openaiConfig.promptList &&
                                openaiConfig.promptList.map((prompt, index) => (
                                    <div className='flex gap-2 items-start' key={index}>
                                        <div className="flex-grow">
                                            <label className="block mb-1 text-xs font-medium text-gray-700 dark:text-gray-300">
                                                {prompt.role}
                                            </label>
                                            <textarea
                                                rows="2"
                                                className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                value={prompt.content}
                                                placeholder={`Input Some ${prompt.role} Prompt`}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setOpenaiConfig({
                                                        ...openaiConfig,
                                                        promptList: openaiConfig.promptList.map((p, i) => {
                                                            if (i === index) {
                                                                if (i === 0) {
                                                                    return {
                                                                        role: 'system',
                                                                        content: value,
                                                                    };
                                                                } else {
                                                                    return {
                                                                        role: index % 2 !== 0 ? 'user' : 'assistant',
                                                                        content: value,
                                                                    };
                                                                }
                                                            } else {
                                                                return p;
                                                            }
                                                        }),
                                                    });
                                                }}
                                            />
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setOpenaiConfig({
                                                    ...openaiConfig,
                                                    promptList: openaiConfig.promptList.filter((_, i) => i !== index),
                                                });
                                            }}
                                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg dark:text-red-500 dark:hover:bg-gray-600 mt-6 transition-colors"
                                        >
                                            <DeleteIcon size={20} />
                                        </button>
                                    </div>
                                ))}

                            <button
                                type="button"
                                onClick={() => {
                                    setOpenaiConfig({
                                        ...openaiConfig,
                                        promptList: [
                                            ...openaiConfig.promptList,
                                            {
                                                role:
                                                    openaiConfig.promptList.length === 0
                                                        ? 'system'
                                                        : openaiConfig.promptList.length % 2 === 0
                                                            ? 'assistant'
                                                            : 'user',
                                                content: '',
                                            },
                                        ],
                                    });
                                }}
                                className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                            >
                                {t('services.translate.openai.add')}
                            </button>
                        </div>
                    </div>

                    {/* Request Arguments */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            Request Arguments
                        </label>
                        <textarea
                            rows="4"
                            className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 font-mono"
                            value={openaiConfig['requestArguments']}
                            placeholder={`Input API Request Arguments`}
                            onChange={(e) => {
                                setOpenaiConfig({
                                    ...openaiConfig,
                                    requestArguments: e.target.value,
                                });
                            }}
                        />
                    </div>
                </div>

                <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                    <button
                        type='submit'
                        disabled={isLoading}
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 disabled:opacity-50"
                    >
                        {isLoading ? 'Testing...' : t('common.save')}
                    </button>
                    <button
                        onClick={onClose}
                        type="button"
                        className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        {t('common.cancel')}
                    </button>
                </div>
            </form>
        )
    );
}
