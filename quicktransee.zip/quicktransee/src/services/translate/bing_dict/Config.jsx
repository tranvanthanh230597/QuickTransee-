import { useTranslation } from 'react-i18next';
import React from 'react';

export function Config(props) {
    const { updateServiceList, onClose } = props;
    const { t } = useTranslation();

    return (
        <div className="flex flex-col overflow-hidden h-full">
            <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                <div className="text-gray-900 dark:text-gray-100">{t('services.no_need')}</div>
            </div>
            <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                <button
                    type="button"
                    className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                    onClick={() => {
                        updateServiceList('bing_dict');
                        onClose();
                    }}
                >
                    {t('common.save')}
                </button>
                <button
                    onClick={onClose}
                    type="button"
                    className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                >
                    {t('common.cancel')}
                </button>
            </div>
        </div>
    );
}
