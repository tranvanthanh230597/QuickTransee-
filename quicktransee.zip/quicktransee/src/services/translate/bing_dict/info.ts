export const info = {
    name: 'bing_dict',
    icon: 'logo/bing.svg',
};

export enum Language {
    auto = 'auto',
    zh_cn = 'zh-cn',
    zh_tw = 'zh-cn',
    en = 'en-us',
}
