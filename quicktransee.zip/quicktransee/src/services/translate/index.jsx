import * as _deepl from './deepl';
import * as _bing from './bing';
import * as _openai from './openai';
import * as _google from './google';
import * as _bing_dict from './bing_dict';
import * as _geminipro from './geminipro';
import * as _ollama from './ollama';

export const deepl = _deepl;
export const bing = _bing;
export const openai = _openai;
export const google = _google;
export const bing_dict = _bing_dict;
export const geminipro = _geminipro;
export const ollama = _ollama;
