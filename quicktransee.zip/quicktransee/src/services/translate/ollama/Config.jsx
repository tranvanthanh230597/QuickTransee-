import { INSTANCE_NAME_CONFIG_KEY } from '../../../utils/service_instance';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { open } from '@tauri-apps/api/shell';
import { useEffect, useState } from 'react';
import { Ollama } from 'ollama/browser';
import { DeleteIcon } from '../../../components/Icons';

import { useConfig } from '../../../hooks/useConfig';
import { useToastStyle } from '../../../hooks';
import { translate } from './index';
import { Language } from './index';

export function Config(props) {
    const { instanceKey, updateServiceList, onClose } = props;
    const { t } = useTranslation();
    const [serviceConfig, setServiceConfig] = useConfig(
        instanceKey,
        {
            [INSTANCE_NAME_CONFIG_KEY]: t('services.translate.ollama.title'),
            stream: true,
            model: 'gemma:2b',
            requestPath: 'http://localhost:11434',
            promptList: [
                {
                    role: 'system',
                    content:
                        'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                },
                { role: 'user', content: `Translate into $to:\n"""\n$text\n"""` },
            ],
        },
        { sync: false }
    );
    const [isLoading, setIsLoading] = useState(false);
    const [isPulling, setIsPulling] = useState(false);
    const [progress, setProgress] = useState(0);
    const [pullingStatus, setPullingStatus] = useState('');
    const [installedModels, setInstalledModels] = useState(null);

    const toastStyle = useToastStyle();

    async function getModles() {
        try {
            const ollama = new Ollama({ host: serviceConfig.requestPath });
            const list = await ollama.list();
            setInstalledModels(list);
        } catch {
            setInstalledModels(null);
        }
    }

    async function pullModel() {
        setIsPulling(true);
        const ollama = new Ollama({ host: serviceConfig.requestPath });
        const stream = await ollama.pull({ model: serviceConfig.model, stream: true });
        for await (const part of stream) {
            if (part.digest) {
                let percent = 0;
                if (part.completed && part.total) {
                    percent = Math.round((part.completed / part.total) * 100);
                }
                setProgress(percent);
                setPullingStatus(part.status);
            } else {
                setProgress(0);
                setPullingStatus(part.status);
            }
        }
        setProgress(0);
        setPullingStatus('');
        setIsPulling(false);
        getModles();
    }

    useEffect(() => {
        if (serviceConfig !== null) {
            getModles();
        }
    }, [serviceConfig]);

    return (
        serviceConfig !== null && (
            <form
                className="flex flex-col overflow-hidden h-full"
                onSubmit={(e) => {
                    e.preventDefault();
                    setIsLoading(true);
                    translate('hello', Language.auto, Language.zh_cn, { config: serviceConfig }).then(
                        () => {
                            setIsLoading(false);
                            setServiceConfig(serviceConfig, true);
                            updateServiceList(instanceKey);
                            onClose();
                        },
                        (e) => {
                            setIsLoading(false);
                            toast.error(t('config.service.test_failed') + e.toString(), { style: toastStyle });
                        }
                    );
                }}
            >
                <Toaster />

                <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                    {/* Instance Name */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.instance_name')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={serviceConfig[INSTANCE_NAME_CONFIG_KEY]}
                            onChange={(e) => {
                                setServiceConfig({
                                    ...serviceConfig,
                                    [INSTANCE_NAME_CONFIG_KEY]: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Install Ollama Hint */}
                    {installedModels === null && (
                        <div className="p-4 bg-red-50 border border-red-200 rounded-lg dark:bg-red-900/10 dark:border-red-900">
                            <div className="text-sm text-red-800 dark:text-red-200">
                                {t('services.translate.ollama.install_ollama')}
                                <br />
                                <a
                                    href="#"
                                    onClick={(e) => {
                                        e.preventDefault();
                                        open('https://ollama.com/download');
                                    }}
                                    className="font-medium text-blue-600 hover:underline dark:text-blue-500"
                                >
                                    {t('services.translate.ollama.install_ollama_link')}
                                </a>
                            </div>
                        </div>
                    )}

                    {/* Help Button */}
                    <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">{t('services.help')}</h3>
                        <button
                            type="button"
                            onClick={() => open('https://gitlab.aureole-it.vn/binhlp/quicktransee/')}
                            className="py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                            {t('services.help')}
                        </button>
                    </div>

                    {/* Stream Toggle */}
                    <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-300">
                            {t('services.translate.ollama.stream')}
                        </span>
                        <label className="inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                checked={serviceConfig['stream']}
                                onChange={(e) => {
                                    setServiceConfig({
                                        ...serviceConfig,
                                        stream: e.target.checked
                                    });
                                }}
                                className="sr-only peer"
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    {/* Request Path */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.ollama.request_path')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={serviceConfig['requestPath']}
                            onChange={(e) => {
                                setServiceConfig({
                                    ...serviceConfig,
                                    requestPath: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Model Selection and Installation */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.ollama.model')}
                        </label>
                        <div className="flex gap-2">
                            <input
                                type="text"
                                className="flex-grow bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                value={serviceConfig['model']}
                                onChange={(e) => {
                                    setServiceConfig({
                                        ...serviceConfig,
                                        model: e.target.value,
                                    });
                                }}
                            />
                            {installedModels && !installedModels.models.map((model) => model.name).includes(serviceConfig['model']) ? (
                                <button
                                    type="button"
                                    className="text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-4 py-2 dark:focus:ring-yellow-900"
                                    onClick={pullModel}
                                    disabled={isPulling}
                                >
                                    {isPulling ? 'Installing...' : t('services.translate.ollama.install_model')}
                                </button>
                            ) : (
                                <button
                                    type="button"
                                    className="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800"
                                    disabled
                                >
                                    {t('services.translate.ollama.ready')}
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Progress Bar and Status */}
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg dark:bg-green-900/10 dark:border-green-900">
                        {isPulling && (
                            <div className="mb-2">
                                <div className="flex justify-between mb-1">
                                    <span className="text-sm font-medium text-green-700 dark:text-green-300">{pullingStatus}</span>
                                    <span className="text-sm font-medium text-green-700 dark:text-green-300">{progress}%</span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                        )}
                        <div className='flex justify-center'>
                            <a
                                href="#"
                                onClick={(e) => {
                                    e.preventDefault();
                                    open('https://ollama.com/library');
                                }}
                                className="text-sm font-medium text-blue-600 hover:underline dark:text-blue-500"
                            >
                                {t('services.translate.ollama.supported_models')}
                            </a>
                        </div>
                    </div>

                    {/* Prompt List */}
                    <div>
                        <h3 className='text-sm font-medium text-gray-900 dark:text-white mb-1'>Prompt List</h3>
                        <p className='text-xs text-gray-500 dark:text-gray-400 mb-2'>
                            {t('services.translate.ollama.prompt_description')}
                        </p>

                        <div className='bg-gray-50 dark:bg-gray-700 rounded-lg p-3 space-y-3'>
                            {serviceConfig.promptList &&
                                serviceConfig.promptList.map((prompt, index) => (
                                    <div className='flex gap-2 items-start' key={index}>
                                        <div className="flex-grow">
                                            <label className="block mb-1 text-xs font-medium text-gray-700 dark:text-gray-300">
                                                {prompt.role}
                                            </label>
                                            <textarea
                                                rows="2"
                                                className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                value={prompt.content}
                                                placeholder={`Input Some ${prompt.role} Prompt`}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setServiceConfig({
                                                        ...serviceConfig,
                                                        promptList: serviceConfig.promptList.map((p, i) => {
                                                            if (i === index) {
                                                                if (i === 0) {
                                                                    return {
                                                                        role: 'system',
                                                                        content: value,
                                                                    };
                                                                } else {
                                                                    return {
                                                                        role: index % 2 !== 0 ? 'user' : 'assistant',
                                                                        content: value,
                                                                    };
                                                                }
                                                            } else {
                                                                return p;
                                                            }
                                                        }),
                                                    });
                                                }}
                                            />
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setServiceConfig({
                                                    ...serviceConfig,
                                                    promptList: serviceConfig.promptList.filter((_, i) => i !== index),
                                                });
                                            }}
                                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg dark:text-red-500 dark:hover:bg-gray-600 mt-6 transition-colors"
                                        >
                                            <DeleteIcon size={20} />
                                        </button>
                                    </div>
                                ))}

                            <button
                                type="button"
                                onClick={() => {
                                    setServiceConfig({
                                        ...serviceConfig,
                                        promptList: [
                                            ...serviceConfig.promptList,
                                            {
                                                role:
                                                    serviceConfig.promptList.length === 0
                                                        ? 'system'
                                                        : serviceConfig.promptList.length % 2 === 0
                                                            ? 'assistant'
                                                            : 'user',
                                                content: '',
                                            },
                                        ],
                                    });
                                }}
                                className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                            >
                                {t('services.translate.ollama.add')}
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                    <button
                        type='submit'
                        disabled={isLoading}
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 disabled:opacity-50"
                    >
                        {isLoading ? 'Testing...' : t('common.save')}
                    </button>
                    <button
                        onClick={onClose}
                        type="button"
                        className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        {t('common.cancel')}
                    </button>
                </div>
            </form>
        )
    );
}
