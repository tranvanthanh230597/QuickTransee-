import { INSTANCE_NAME_CONFIG_KEY } from '../../../utils/service_instance';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { open } from '@tauri-apps/api/shell';
import { useState } from 'react';
import { DeleteIcon } from '../../../components/Icons';
import { useConfig } from '../../../hooks/useConfig';
import { useToastStyle } from '../../../hooks';
import { translate } from './index';
import { Language } from './index';

export function Config(props) {
    const { instanceKey, updateServiceList, onClose } = props;
    const { t } = useTranslation();
    const [serviceConfig, setServiceConfig] = useConfig(
        instanceKey,
        {
            [INSTANCE_NAME_CONFIG_KEY]: t('services.translate.geminipro.title'),
            stream: true,
            apiKey: '',
            requestPath: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro',
            promptList: [
                {
                    role: 'user',
                    parts: [
                        {
                            text: 'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                        },
                    ],
                },
                {
                    role: 'model',
                    parts: [
                        {
                            text: 'Ok, I will only translate the text content, never interpret it.',
                        },
                    ],
                },
                {
                    role: 'user',
                    parts: [
                        {
                            text: `Translate into Chinese\n"""\nhello\n"""`,
                        },
                    ],
                },
                {
                    role: 'model',
                    parts: [
                        {
                            text: '你好',
                        },
                    ],
                },
                {
                    role: 'user',
                    parts: [
                        {
                            text: `Translate into $to\n"""\n$text\n"""`,
                        },
                    ],
                },
            ],
        },
        { sync: false }
    );
    const [isLoading, setIsLoading] = useState(false);

    const toastStyle = useToastStyle();

    return (
        serviceConfig !== null && (
            <form
                className="flex flex-col overflow-hidden h-full"
                onSubmit={(e) => {
                    e.preventDefault();
                    setIsLoading(true);
                    translate('hello', Language.auto, Language.zh_cn, { config: serviceConfig }).then(
                        () => {
                            setIsLoading(false);
                            setServiceConfig(serviceConfig, true);
                            updateServiceList(instanceKey);
                            onClose();
                        },
                        (e) => {
                            setIsLoading(false);
                            toast.error(t('config.service.test_failed') + e.toString(), { style: toastStyle });
                        }
                    );
                }}
            >
                <Toaster />

                <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                    {/* Instance Name */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.instance_name')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={serviceConfig[INSTANCE_NAME_CONFIG_KEY]}
                            onChange={(e) => {
                                setServiceConfig({
                                    ...serviceConfig,
                                    [INSTANCE_NAME_CONFIG_KEY]: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Help Button */}
                    <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">{t('services.help')}</h3>
                        <button
                            type="button"
                            onClick={() => open('https://gitlab.aureole-it.vn/binhlp/quicktransee/')}
                            className="py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                            {t('services.help')}
                        </button>
                    </div>

                    {/* Stream Toggle */}
                    <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-gray-300">
                            {t('services.translate.geminipro.stream')}
                        </span>
                        <label className="inline-flex items-center cursor-pointer">
                            <input
                                type="checkbox"
                                checked={serviceConfig['stream']}
                                onChange={(e) => {
                                    setServiceConfig({
                                        ...serviceConfig,
                                        stream: e.target.checked
                                    });
                                }}
                                className="sr-only peer"
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    {/* Request Path */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.geminipro.request_path')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={serviceConfig['requestPath']}
                            onChange={(e) => {
                                setServiceConfig({
                                    ...serviceConfig,
                                    requestPath: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* API Key */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.geminipro.api_key')}
                        </label>
                        <input
                            type="password"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={serviceConfig['apiKey']}
                            onChange={(e) => {
                                setServiceConfig({
                                    ...serviceConfig,
                                    apiKey: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Prompt List */}
                    <div>
                        <h3 className='text-sm font-medium text-gray-900 dark:text-white mb-1'>Prompt List</h3>
                        <p className='text-xs text-gray-500 dark:text-gray-400 mb-2'>
                            {t('services.translate.geminipro.prompt_description')}
                        </p>

                        <div className='bg-gray-50 dark:bg-gray-700 rounded-lg p-3 space-y-3'>
                            {serviceConfig.promptList &&
                                serviceConfig.promptList.map((prompt, index) => (
                                    <div className='flex gap-2 items-start' key={index}>
                                        <div className="flex-grow">
                                            <label className="block mb-1 text-xs font-medium text-gray-700 dark:text-gray-300">
                                                {prompt.role}
                                            </label>
                                            <textarea
                                                rows="2"
                                                className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                value={prompt.parts[0].text}
                                                placeholder={`Input Some ${prompt.role} Prompt`}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setServiceConfig({
                                                        ...serviceConfig,
                                                        promptList: serviceConfig.promptList.map((p, i) => {
                                                            if (i === index) {
                                                                return {
                                                                    role: index % 2 !== 0 ? 'model' : 'user',
                                                                    parts: [
                                                                        {
                                                                            text: value,
                                                                        },
                                                                    ],
                                                                };
                                                            } else {
                                                                return p;
                                                            }
                                                        }),
                                                    });
                                                }}
                                            />
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setServiceConfig({
                                                    ...serviceConfig,
                                                    promptList: serviceConfig.promptList.filter((_, i) => i !== index),
                                                });
                                            }}
                                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg dark:text-red-500 dark:hover:bg-gray-600 mt-6 transition-colors"
                                        >
                                            <DeleteIcon size={20} />
                                        </button>
                                    </div>
                                ))}

                            <button
                                type="button"
                                onClick={() => {
                                    setServiceConfig({
                                        ...serviceConfig,
                                        promptList: [
                                            ...serviceConfig.promptList,
                                            {
                                                role: serviceConfig.promptList.length % 2 === 0 ? 'user' : 'model',
                                                parts: [
                                                    {
                                                        text: '',
                                                    },
                                                ],
                                            },
                                        ],
                                    });
                                }}
                                className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                            >
                                {t('services.translate.geminipro.add')}
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                    <button
                        type='submit'
                        disabled={isLoading}
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 disabled:opacity-50"
                    >
                        {isLoading ? 'Testing...' : t('common.save')}
                    </button>
                    <button
                        onClick={onClose}
                        type="button"
                        className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        {t('common.cancel')}
                    </button>
                </div>
            </form>
        )
    );
}
