import { INSTANCE_NAME_CONFIG_KEY } from '../../../utils/service_instance';
import toast, { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { open } from '@tauri-apps/api/shell';
import React, { useState } from 'react';
import { DeleteIcon } from '../../../components/Icons';
import { useConfig } from '../../../hooks/useConfig';
import { useToastStyle } from '../../../hooks';
import { translate } from './index';
import { Language } from './index';

export function Config(props) {
    const { instanceKey, updateServiceList, onClose } = props;
    const { t } = useTranslation();
    const [deeplConfig, setDeeplConfig] = useConfig(
        instanceKey,
        {
            [INSTANCE_NAME_CONFIG_KEY]: t('services.translate.deepl.title'),
            authKey: '',
            customUrl: 'https://api.deepl.com/v2/translate',
            promptList: [
                {
                    content: 'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                },
            ],
        },
        { sync: false }
    );
    const [isLoading, setIsLoading] = useState(false);

    const toastStyle = useToastStyle();

    React.useEffect(() => {
        if (deeplConfig && (!deeplConfig.promptList || deeplConfig.promptList.length === 0)) {
            setDeeplConfig({
                ...deeplConfig,
                promptList: [
                    {
                        content: 'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.',
                    },
                ],
            });
        }
    }, [deeplConfig]);

    return (
        deeplConfig !== null && (
            <form
                className="flex flex-col overflow-hidden h-full"
                onSubmit={(e) => {
                    e.preventDefault();
                    setIsLoading(true);
                    translate('hello', Language.auto, Language.zh_cn, { config: deeplConfig }).then(
                        () => {
                            setIsLoading(false);
                            setDeeplConfig(deeplConfig, true);
                            updateServiceList(instanceKey);
                            onClose();
                        },
                        (e) => {
                            setIsLoading(false);
                            toast.error(t('config.service.test_failed') + e.toString(), { style: toastStyle });
                        }
                    );
                }}
            >
                <Toaster />

                <div className="flex-1 overflow-y-auto min-h-0 p-6 space-y-4">
                    {/* Instance Name */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.instance_name')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={deeplConfig[INSTANCE_NAME_CONFIG_KEY]}
                            onChange={(e) => {
                                setDeeplConfig({
                                    ...deeplConfig,
                                    [INSTANCE_NAME_CONFIG_KEY]: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Help Button */}
                    <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">{t('services.help')}</h3>
                        <button
                            type="button"
                            onClick={() => open('https://www.deepl.com/pro-api')}
                            className="py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                            {t('services.help')}
                        </button>
                    </div>

                    {/* Custom URL */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.deepl.custom_url')}
                        </label>
                        <input
                            type="text"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            placeholder='https://api.deepl.com/v2/translate'
                            value={deeplConfig.customUrl}
                            onChange={(e) => {
                                setDeeplConfig({
                                    ...deeplConfig,
                                    customUrl: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Auth Key */}
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {t('services.translate.deepl.auth_key')}
                        </label>
                        <input
                            type="password"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            value={deeplConfig['authKey']}
                            onChange={(e) => {
                                setDeeplConfig({
                                    ...deeplConfig,
                                    authKey: e.target.value,
                                });
                            }}
                        />
                    </div>

                    {/* Prompt List */}
                    <div>
                        <h3 className='text-sm font-medium text-gray-900 dark:text-white mb-1'>Prompt List</h3>
                        <p className='text-xs text-gray-500 dark:text-gray-400 mb-2'>
                            Up to 10 instructions, max 300 characters each. Supported for DE, EN, ES, FR, IT, JA, KO, ZH.
                        </p>

                        <div className='bg-gray-50 dark:bg-gray-700 rounded-lg p-3 space-y-3'>
                            {(deeplConfig.promptList || []).map((prompt, index) => (
                                <div className='flex gap-2 items-start' key={index}>
                                    <div className="flex-grow">
                                        <label className="block mb-1 text-xs font-medium text-gray-700 dark:text-gray-300">
                                            Instruction #{index + 1}
                                        </label>
                                        <textarea
                                            rows="2"
                                            className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder='Enter translation instruction...'
                                            maxLength={300}
                                            value={prompt.content}
                                            onChange={(e) => {
                                                const value = e.target.value;
                                                setDeeplConfig({
                                                    ...deeplConfig,
                                                    promptList: (deeplConfig.promptList || []).map((p, i) => {
                                                        if (i === index) {
                                                            return {
                                                                ...p,
                                                                content: value,
                                                            };
                                                        } else {
                                                            return p;
                                                        }
                                                    }),
                                                });
                                            }}
                                        />
                                        <p className="text-right text-xs text-gray-500 dark:text-gray-400 mt-1">
                                            {prompt.content.length}/300
                                        </p>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => {
                                            setDeeplConfig({
                                                ...deeplConfig,
                                                promptList: (deeplConfig.promptList || []).filter((_, i) => i !== index),
                                            });
                                        }}
                                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg dark:text-red-500 dark:hover:bg-gray-600 mt-6 transition-colors"
                                    >
                                        <DeleteIcon size={20} />
                                    </button>
                                </div>
                            ))}

                            <button
                                type="button"
                                disabled={(deeplConfig.promptList || []).length >= 10}
                                onClick={() => {
                                    const currentPrompts = deeplConfig.promptList || [];
                                    setDeeplConfig({
                                        ...deeplConfig,
                                        promptList: [
                                            ...currentPrompts,
                                            {
                                                content: '',
                                            },
                                        ],
                                    });
                                }}
                                className="text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {t('services.translate.ollama.add')}
                                {(deeplConfig.promptList || []).length >= 10 && " (Limit 10 reached)"}
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-4 border-t border-gray-200 dark:border-gray-600 flex justify-end gap-3 flex-none">
                    <button
                        type='submit'
                        disabled={isLoading}
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 disabled:opacity-50"
                    >
                        {isLoading ? 'Testing...' : t('common.save')}
                    </button>
                    <button
                        onClick={onClose}
                        type="button"
                        className="px-5 py-2.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        {t('common.cancel')}
                    </button>
                </div>
            </form>
        )
    );
}
