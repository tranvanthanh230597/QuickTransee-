import { fetch, Body } from '@tauri-apps/api/http';
import { Language } from './info';
import Database from 'tauri-plugin-sql-api';
import { store } from '../../../utils/store';
import { checkGlossaryLanguageMatch } from '../../../utils/dictionary';
import i18n from '../../../i18n';

export async function translate(text, from, to, options = {}) {
    const { config, context: optionsContext } = options;
    const key = config.authKey;
    const url = config.customUrl && config.customUrl.trim() !== '' ? config.customUrl : 'https://api.deepl.com/v2/translate';

    const headers = {
        'Content-Type': 'application/json',
        Authorization: `DeepL-Auth-Key ${key}`,
    };

    // Convert language codes to DeepL format using Language enum
    const targetLang = (Language[to] || to.toUpperCase()).split('-')[0]; // Get base lang for support check
    const fullTargetLang = Language[to] || to.toUpperCase();
    const sourceLang = from !== 'auto' ? (Language[from] || from.toUpperCase()) : null;

    // Supported target languages for custom_instructions: de, en, es, fr, it, ja, ko, zh
    const supportedCustomInstLangs = ['DE', 'EN', 'ES', 'FR', 'IT', 'JA', 'KO', 'ZH'];
    const isCustomInstSupported = supportedCustomInstLangs.includes(targetLang);
    const MAX_DEEPL_BYTES = 128 * 1024; // 131072 bytes

    // Error message for size limit exceeded from i18n
    const SIZE_LIMIT_MSG = i18n.t('services.translate.deepl.size_limit_error');

    // Get glossary_id from the project selected on the General Page
    let glossaryId = null;
    try {
        const generalProjectId = await store.get('general_project');
        if (generalProjectId) {
            const projectDb = await Database.load('sqlite:project.db');
            const projectResult = await projectDb.select('SELECT glossary_id FROM project WHERE id = $1', [generalProjectId]);
            if (projectResult && projectResult[0] && projectResult[0].glossary_id) {
                glossaryId = projectResult[0].glossary_id;
            }
        }
    } catch (e) {
        console.error('Failed to fetch glossary_id:', e);
    }

    let body = {
        text: [text],
        target_lang: fullTargetLang,
        preserve_formatting: true,
    };

    // DeepL requires source_lang to be specified when using a glossary
    // Only use glossary if it matches the current source and target languages
    if (glossaryId && sourceLang && await checkGlossaryLanguageMatch(glossaryId, sourceLang, fullTargetLang)) {
        body['glossary_id'] = glossaryId;
    }

    // Check if text size exceeds DeepL limit
    let textSize = new TextEncoder().encode(JSON.stringify(body.text)).length;
    if (textSize > MAX_DEEPL_BYTES) {
        return await translate(
            SIZE_LIMIT_MSG,
            from,
            to,
            options
        );
    }

    if (config.promptList && config.promptList.length > 0) {
        const allProcessed = config.promptList
            .slice(0, 10)
            .map((item) => {
                return item.content
                    .replaceAll('$text', text)
                    .replaceAll('$from', from)
                    .replaceAll('$to', to)
                    .replaceAll('$detect', options.detect ? (Language[options.detect] || options.detect) : '')
                    .slice(0, 300);
            })
            .filter(p => p.trim() !== '');

        // Separate instructions (general rules) from context (specific task/text wrapper)
        // We assume prompts containing $text are "context" or task-specific.
        const instructions = [];
        const contextPrompts = [];

        config.promptList.slice(0, 10).forEach((item, index) => {
            const processed = allProcessed[index];
            if (!processed) return;

            if (item.content.includes('$text')) {
                contextPrompts.push(processed);
            } else {
                instructions.push(processed);
            }
        });

        if (isCustomInstSupported) {
            if (instructions.length > 0) {
                body['custom_instructions'] = instructions;
                body['model_type'] = 'quality_optimized';
            }
            const contextValue = [optionsContext, ...contextPrompts].filter(Boolean).join('\n');
            if (contextValue) {
                body['context'] = contextValue;
            }
        } else {
            // Fallback for unsupported languages: merge everything into context
            const mergedContext = [optionsContext, ...allProcessed].filter(Boolean).join('\n');
            if (mergedContext) {
                body['context'] = mergedContext;
            }
        }
    } else if (optionsContext) {
        body['context'] = optionsContext;
    }

    if (sourceLang) {
        body['source_lang'] = sourceLang;
    }

    let res = await fetch(url, {
        method: 'POST',
        body: Body.json(body),
        headers: headers,
    });

    if (res.ok) {
        const result = res.data;
        if (result.translations && result.translations[0]) {
            return result.translations[0].text.trim();
        } else {
            throw JSON.stringify(result);
        }
    } else {
        if (res.data && res.data.error) {
            throw `${i18n.t('services.translate.deepl.status_code')}: ${res.status}\n${res.data.error.message}`;
        } else {
            throw `${i18n.t('services.translate.deepl.request_error')}\nHttp Status: ${res.status}\n${JSON.stringify(res.data)}`;
        }
    }
}

export * from './Config';
export * from './info';
