import { initReactI18next } from 'react-i18next';
import i18n from 'i18next';
import en_US from './locales/en_US.json';
import ja_JP from './locales/ja_JP.json';

// http://www.lingoes.net/zh/translator/langcode.htm

i18n.use(initReactI18next).init({
    fallbackLng: {
        default: ['en'],
    },
    debug: false,
    interpolation: {
        escapeValue: false,
    },
    resources: {
        en: en_US,
        ja: ja_JP,
    },
});

export default i18n;
