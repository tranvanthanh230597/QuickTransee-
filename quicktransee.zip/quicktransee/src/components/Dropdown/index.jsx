import { useState, useRef, useEffect, useMemo } from 'react';
import { SearchIcon } from '../Icons';
export default function Dropdown({
    value,
    options,
    onChange,
    label,
    className = '',
    buttonClassName = '',
    renderOption,
    renderLabel,
    variant = 'outline',
    placement = 'bottom',
    showSearch = false
}) {
    const [isOpen, setIsOpen] = useState(false);
    const [searchText, setSearchText] = useState('');
    const dropdownRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(event) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Reset search text when opening/closing
    useEffect(() => {
        if (!isOpen) {
            setSearchText('');
        }
    }, [isOpen]);

    const selectedOption = options.find(opt => opt.value === value);

    const filteredOptions = useMemo(() => {
        if (!searchText) return options;
        const lowerSearch = searchText.toLowerCase();
        return options.filter(opt =>
            String(opt.label).toLowerCase().includes(lowerSearch) ||
            String(opt.value).toLowerCase().includes(lowerSearch)
        );
    }, [options, searchText]);

    const displayLabel = renderLabel ? renderLabel(selectedOption) : (selectedOption ? selectedOption.label : (label || 'Select...'));

    const getButtonClass = () => {
        if (buttonClassName) return buttonClassName;
        const base = "font-medium rounded-lg text-sm px-4 py-2 inline-flex items-center justify-between w-full focus:ring-4 focus:outline-none transition-all";
        if (variant === 'primary') {
            return `${base} text-white bg-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800`;
        }
        return `${base} text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 focus:ring-gray-100 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-700`;
    };

    const placementClasses = placement === 'top' ? 'bottom-full mb-2' : 'mt-2';

    return (
        <div className={`relative ${className}`} ref={dropdownRef}>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className={`group ${getButtonClass()}`}
                style={renderLabel && selectedOption ? { fontFamily: selectedOption.value === 'default' ? 'inherit' : selectedOption.value } : {}}
            >
                <div className="flex items-center gap-2 truncate min-w-0">
                    {selectedOption?.icon && (
                        <img src={selectedOption.icon} className="w-3.5 h-3.5 shrink-0 opacity-90 group-hover:opacity-100 transition-opacity" alt="" />
                    )}
                    <span className="truncate">{displayLabel}</span>
                </div>
                <svg className={`w-2.5 h-2.5 ms-2.5 shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} aria-hidden='true' xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 10 6'>
                    <path stroke='currentColor' strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='m1 1 4 4 4-4' />
                </svg>
            </button>

            {isOpen && (
                <div className={`absolute left-0 z-[100] ${placementClasses} w-full min-w-[200px] bg-white divide-y divide-gray-100 rounded-xl shadow-2xl dark:bg-gray-800 border border-gray-200 dark:border-gray-700 overflow-hidden`}>
                    {showSearch && (
                        <div className="p-2 bg-gray-50/50 dark:bg-gray-800/50">
                            <label htmlFor="input-group-search" className="sr-only">Search</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                                    <SearchIcon />
                                </div>
                                <input
                                    type="text"
                                    autoFocus
                                    className="block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Search..."
                                    value={searchText}
                                    onChange={(e) => setSearchText(e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                />
                            </div>
                        </div>
                    )}
                    <ul className="py-1 text-sm text-gray-700 dark:text-gray-200 max-h-60 overflow-y-auto">
                        {filteredOptions.length > 0 ? (
                            filteredOptions.map((option) => (
                                <li key={option.value}>
                                    <button
                                        type="button"
                                        onClick={() => {
                                            onChange(option.value);
                                            setIsOpen(false);
                                        }}
                                        className={`group block w-full text-left px-4 py-2.5 hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:text-blue-700 dark:hover:text-blue-300 transition-all ${value === option.value ? 'bg-blue-50/50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-bold' : 'text-gray-700 dark:text-gray-300 font-medium'}`}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2 truncate min-w-0">
                                                {option.icon && !renderOption && (
                                                    <img src={option.icon} className="w-4 h-4 shrink-0 transition-opacity opacity-80 group-hover:opacity-100" alt="" />
                                                )}
                                                <span className="truncate">
                                                    {renderOption ? renderOption(option) : option.label}
                                                </span>
                                            </div>
                                            {value === option.value && (
                                                <svg className="w-3.5 h-3.5 ms-2 text-blue-600 dark:text-blue-400 shrink-0" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 12">
                                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M1 5.917 5.724 10.5 15 1.5" />
                                                </svg>
                                            )}
                                        </div>
                                    </button>
                                </li>
                            ))
                        ) : (
                            <li className="px-4 py-2 text-sm text-gray-500 dark:text-gray-400 text-center">
                                No results found
                            </li>
                        )}
                    </ul>
                </div>
            )}
        </div>
    );
}
