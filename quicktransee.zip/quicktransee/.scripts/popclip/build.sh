rm Pot.popclipextz
mkdir Pot.popclipext
cp Config.plist Pot.popclipext
cp Pot.png Pot.popclipext
cp Pot.sh Pot.popclipext
zip -r Pot.popclipextz Pot.popclipext
rm -r Pot.popclipext
