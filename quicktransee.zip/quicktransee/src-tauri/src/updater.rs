use crate::config::{get, set};
use crate::window::updater_window;
use log::{info, warn};
use tauri::Manager;
use serde::Deserialize;

#[derive(Deserialize, Debug)]
struct GitLabRelease {
    tag_name: String,
}

pub fn check_update(app_handle: tauri::AppHandle) {
    let enable = match get("check_update") {
        Some(v) => v.as_bool().unwrap(),
        None => {
            set("check_update", true);
            true
        }
    };
    if enable {
        tauri::async_runtime::spawn(async move {
            let client = reqwest::Client::builder().build();
            match client {
                Ok(client) => {
                     let res = client.get("https://gitlab.aureole-it.vn/api/v4/projects/binhlp%2Fquicktransee/releases")
                         .send()
                         .await;
                     
                     match res {
                        Ok(resp) => {
                             if resp.status().is_success() {
                                 match resp.json::<Vec<GitLabRelease>>().await {
                                     Ok(releases) => {
                                        if releases.is_empty() {
                                            info!("No releases found on GitLab.");
                                            return;
                                        }
                                        let latest_version_tag = &releases[0].tag_name;
                                        let latest_version_str = latest_version_tag.trim_start_matches('v');
                                        let current_version_str = app_handle.package_info().version.to_string();
                                        
                                        if latest_version_str == current_version_str {
                                             info!("App is up to date (Version: {}).", current_version_str);
                                             return;
                                        }
                                     }
                                     Err(e) => {
                                         warn!("Failed to parse GitLab releases: {}", e);
                                         return;
                                     }
                                 }
                             } else {
                                 warn!("GitLab API returned status: {}", resp.status());
                                 return;
                             }
                        }
                        Err(e) => {
                            warn!("Failed to contact GitLab: {}", e);
                            return;
                        }
                     }
                },
                Err(e) => {
                     warn!("Failed to create http client: {}", e);
                     return;
                }
            }

            match tauri::updater::builder(app_handle).check().await {
                Ok(update) => {
                    if update.is_update_available() {
                        info!("New version available");
                        updater_window();
                    }
                }
                Err(e) => {
                    warn!("Failed to check update: {}", e);
                }
            }
        });
    }
}
