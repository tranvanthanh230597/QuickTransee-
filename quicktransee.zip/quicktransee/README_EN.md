<img width="200px" src="public/icon.png" align="left"/>

# QuickTransee

> 🌈 A cross-platform text translation and OCR software

![License](https://img.shields.io/badge/license-GPLv3-blue.svg)
![Tauri](https://img.shields.io/badge/Tauri-1.6.8-blue?logo=tauri)
![JavaScript](https://img.shields.io/badge/-JavaScript-yellow?logo=javascript&logoColor=white)
![Rust](https://img.shields.io/badge/-Rust-orange?logo=rust&logoColor=white)
![Windows](https://img.shields.io/badge/-Windows-blue?logo=windows&logoColor=white)
![MacOS](https://img.shields.io/badge/-macOS-black?&logo=apple&logoColor=white)
![Linux](https://img.shields.io/badge/-Linux-yellow?logo=linux&logoColor=white)

<br/>
<hr/>
<div align="center">

<h3> English | <a href='./README_JA.md'> 日本語 </a> | <a href='./README.md'> Tiếng Việt </a></h3>

<table>
<tr>
    <td> <img src="asset/1.png">
    <td> <img src="asset/2.png">
</table>

# Table of Contents

</div>

-   [Usage](#usage)
-   [Features](#features)
-   [Supported Services](#supported-services)
-   [Installation](#installation)
-   [External Calls](#external-calls)
-   [Wayland Support](#wayland-support)
-   [Manual Compilation](#manual-compilation)
-   [Thanks](#thanks)

<div align="center">

# Usage

</div>

| Translation by selection                        | Translate by input                                                    | External calls                                                                           |
| ----------------------------------------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Select text and press the shortcut to translate | Press shortcut to open translation window, translate by hitting Enter | More efficient workflow by integrating other apps, see [External Calls](#external-calls) |
| <img src="asset/eg1.gif"/>                      | <img src="asset/eg2.gif"/>                                            | <img src="asset/eg3.gif"/>                                                               |

| Clipboard Listening                                                                                                          | Screenshot OCR                     | Screenshot Translation                   |
| ---------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- | ---------------------------------------- |
| Click the top left icon on any translation panel to start clipboard listening. Copied text will be translated automatically. | Press shortcut, select area to OCR | Press shortcut, select area to translate |
| <img src="asset/eg4.gif"/>                                                                                                   | <img src="asset/eg5.gif"/>         | <img src="asset/eg6.gif"/>               |

<div align="center">

# Features

</div>

-   [x] Parallel translations with multiple services ([Supported Services](#supported-services))
-   [x] OCR with multiple services ([Supported Services](#supported-services))
-   [x] Text-to-Speech support ([Supported Services](#supported-services))
-   [x] Export to vocabulary apps ([Supported Services](#supported-services))
-   [x] External calls ([External Calls](#external-calls))
-   [x] Support Windows, macOS and Linux
-   [x] Support Wayland (Tested on KDE, Gnome and Hyprland)
-   [x] Multi-language support (English, Japanese)

<div align="center">

# Supported Services

</div>

## Translation

-   [x] [OpenAI](https://platform.openai.com/)
-   [x] [Gemini Pro](https://gemini.google.com/)
-   [x] [Ollama](https://www.ollama.com/) (Offline)
-   [x] [Google Translate](https://translate.google.com)
-   [x] [Bing Translate](https://learn.microsoft.com/zh-cn/azure/cognitive-services/translator/)
-   [x] [Bing Dictionary](https://www.bing.com/dict)
-   [x] [DeepL](https://www.deepl.com/)

## Text Recognition (OCR)

-   [x] System OCR (Offline)
    -   [x] [Windows.Media.OCR](https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine?view=winrt-22621) on Windows
    -   [x] [Apple Vision Framework](https://developer.apple.com/documentation/vision/recognizing_text_in_images) on MacOS
    -   [x] [Tesseract OCR](https://github.com/tesseract-ocr) on Linux
-   [x] [Tesseract.js](https://tesseract.projectnaptha.com/) (Offline)

## Text-to-Speech

-   [x] [Lingva](https://github.com/thedaviddelta/lingva-translate)

## Collection (Vocabulary)

-   [x] [Anki](https://apps.ankiweb.net/)
-   [x] [Eudic](https://dict.eudic.net/)

<div align="center">

# Installation

</div>

## Windows

### Install Manually

1. Download the installation package ending in `.exe` from the latest release.
    - 64-bit machine download `quicktransee_{version}_x64-setup.exe`
    - 32-bit machine download `quicktransee_{version}_x86-setup.exe`
    - arm64 machine download `quicktransee_{version}_arm64-setup.exe`

2. Double click the downloaded file to install it.

### Troubleshooting

-   **No interface after startup / No response from tray icon:**
    Check if WebView2 is uninstalled/disabled. If so, install WebView2 manually or restore it.
    If the issue persists, try starting in Windows 7 compatibility mode.

## MacOS

### Install Manually

1. Download the installation package ending in `.dmg`. (If you are using M1/M2, please download the `aarch64` version, otherwise `x64`).
2. Double click the downloaded file to install it.

### Troubleshooting

-   **"QuickTransee" can’t be opened because the developer cannot be verified:**
    Go to Settings -> Privacy and Security page, click the "Still Open" button.
    If the issue persists, run the following in Terminal:
    ```bash
    sudo xattr -d com.apple.quarantine /Applications/quicktransee.app
    ```

## Linux

We provide `deb` packages for Linux.

### Arch/Manjaro

In newer version of [Webkit2Gtk](https://archlinux.org/packages/extra/x86_64/webkit2gtk) (2.42.0), Nvidia Proprietary drivers may cause failure to start.
Please add `WEBKIT_DISABLE_DMABUF_RENDERER=1` to your environment variables.

<div align="center">

# External Calls

</div>

QuickTransee provides a HTTP interface for integration with other software. Default port is `60828`.

## API Docs:

```bash
POST "/" => Translate given text (body is text to translate)
GET "/config" => Open settings
POST "/translate" => Translate given text (same as "/")
GET "/selection_translate" => Translate selected text
GET "/input_translate" => Open input translation
GET "/ocr_recognize" => Perform OCR on screenshot
GET "/ocr_translate" => Perform translation on screenshot
GET "/ocr_recognize?screenshot=false" => OCR without taking screenshot
GET "/ocr_translate?screenshot=false" => Translate screenshot without taking screenshot
```

## Example:

```bash
curl "127.0.0.1:60828/selection_translate"
```

<div align="center">

# Wayland Support

</div>

- **Shortcut keys:** Tauri lacks Wayland support for global shortcuts. Use system shortcuts with `curl` to trigger actions.
- **Screenshot:** If the built-in screenshot fails, use external tools like `grim` and `slurp` and save to the cache directory, then call with `screenshot=false`.

<div align="center">

# Manual Compilation

</div>

### Requirements

- Node.js >= 18.0.0
- pnpm >= 8.5.0
- Rust >= 1.80.0

### Steps

1. Clone the repository.
2. Install dependencies: `pnpm install`.
3. Development: `pnpm tauri dev`.
4. Build: `pnpm tauri build`.

<div align="center">

# Thanks

</div>

-   [Pot](https://github.com/pot-app/pot-desktop) Original project
-   [Bob](https://github.com/ripperhe/Bob) Inspiration
-   [Tauri](https://github.com/tauri-apps/tauri) GUI Framework

<div align="center">
