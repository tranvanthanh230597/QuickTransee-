# QuickTranseeProxy 🚀 (Vietnamese Version)

[English](./README.md) | [Tiếng Việt](./README_VN.md) | [日本語](./README_JP.md)


QuickTranseeProxy là một máy chủ middleware hiệu năng cao được thiết kế để ủy quyền (proxy) và quản lý các yêu cầu dịch thuật. Nó đóng vai trò là cầu nối giữa các ứng dụng khách (client) và các nhà cung cấp dịch vụ dịch thuật khác nhau (như DeepL, Google Translate, v.v.), cung cấp các tính năng tập trung về xác thực, ghi log và quản lý thông tin xác thực (credentials).

## 🏗 Kiến trúc hệ thống

Dự án được cấu trúc theo dạng monorepo bao gồm máy chủ proxy backend và một frontend quản lý.

- **Backend (`/BE`)**: Một API Express.js xử lý các yêu cầu dịch thuật, xác thực API key và tương tác với Supabase để lưu trữ dữ liệu và ghi log.
- **Frontend (`/FE`)**: Một bảng điều khiển dựa trên React để quản lý người dùng, các dịch vụ dịch thuật và theo dõi log sử dụng.
- **Database**: Sử dụng **Supabase (PostgreSQL)**, quản lý hồ sơ người dùng, thông tin xác thực API và log chi tiết yêu cầu/phản hồi.

---

## 🛠 Công nghệ sử dụng

### Backend (Node.js)
- **Framework**: Express.js
- **Database Client**: @supabase/supabase-js
- **Security**: Helmet, CORS
- **Logging**: Morgan
- **Môi trường**: Dotenv

### Frontend (React)
- **Framework**: React 19 + Vite
- **Ngôn ngữ**: TypeScript
- **Styling**: Tailwind CSS

---

## 📂 Cấu trúc dự án

```text
quicktranseeproxy/
├── BE/                 # Backend Proxy Server
│   ├── config/         # Cấu hình Database và dịch vụ
│   ├── controllers/    # Bộ điều khiển xử lý yêu cầu
│   ├── middleware/     # Xác thực, Kiểm tra dữ liệu, Xử lý lỗi
│   ├── routes/         # Định nghĩa các tuyến đường API
│   ├── services/       # Logic nghiệp vụ chính (Gọi API dịch thuật)
│   └── utils/          # Các hàm tiện ích
├── FE/                 # Frontend Quản lý
│   └── src/            # Mã nguồn React
└── README.md           # Hướng dẫn này
```

---

## 🚀 Bắt đầu

### 1. Yêu cầu hệ thống
- Node.js (v18+)
- npm hoặc yarn
- Một dự án Supabase

### 2. Cài đặt Backend
1. Truy cập thư mục backend:
   ```bash
   cd BE
   ```
2. Cài đặt thư viện:
   ```bash
   npm install
   ```
3. Tạo file `.env` dựa trên yêu cầu:
   ```env
   PORT=3000
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_service_role_key
   CORS_ORIGIN=*
   ```
4. Chạy server:
   ```bash
   npm start
   ```

### 3. Cài đặt Frontend
1. Truy cập thư mục frontend:
   ```bash
   cd FE
   ```
2. Cài đặt thư viện:
   ```bash
   npm install
   ```
3. Chạy môi trường phát triển:
   ```bash
   npm run dev
   ```

---

## 🔐 Xác thực

API sử dụng cơ chế xác thực tùy chỉnh. Tất cả các yêu cầu đến các endpoint được bảo vệ (như `/v2/translate`) phải bao gồm header `Authorization`.

- **Header**: `Authorization: <YOUR_API_TOKEN>`
- **Xác thực**: Token được so khớp với `api_token_hash` trong bảng `users_profile`.
- **Trạng thái**: Người dùng phải có trạng thái là `'inuse'` để truy cập dịch vụ.

---

## 📊 Cấu trúc Cơ sở dữ liệu

Hệ thống dựa trên các bảng chính sau trong Supabase:

- `users_profile`: Lưu trữ thông tin người dùng và `api_token_hash`.
- `services`: Danh sách các nhà cung cấp dịch thuật (ví dụ: DeepL, Google).
- `service_credentials`: API key và cài đặt môi trường cho từng dịch vụ.
- `service_assignments`: Liên kết người dùng với các thông tin xác thực dịch vụ cụ thể.
- `user_logs`: Ghi lại mọi yêu cầu do người dùng thực hiện.
- `service_logs`: Log chi tiết về tương tác với các API dịch thuật bên ngoài.

---

## 🛣 API Endpoints

### Dịch thuật (v2)
- **Endpoint**: `POST /v2/translate`
- **Xác thực**: Bắt buộc
- **Body**:
  ```json
  {
    "text": "Hello world",
    "target_lang": "vi"
  }
  ```
- **Phản hồi thành công**:
  ```json
  {
    "text": "Xin chào thế giới"
  }
  ```

---

## 📝 Giấy phép
Dự án này được cấp phép theo giấy phép ISC.
