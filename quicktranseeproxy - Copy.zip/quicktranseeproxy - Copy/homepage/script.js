/* ============================================================
   QuickTransee Homepage – script.js
   ============================================================ */

// ---- Navbar scroll behaviour ----
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
}, { passive: true });

// ---- Hamburger menu ----
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('nav-links');
hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
});
// Close menu when a link is clicked
navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => navLinks.classList.remove('open'));
});

// ---- Tabs ----
const tabBtns = document.querySelectorAll('.tab-btn');
tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        tabBtns.forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        const content = document.getElementById('tab-content-' + tab);
        if (content) content.classList.add('active');
    });
});

// ---- Scroll Reveal (simple AOS-like) ----
const aosElements = document.querySelectorAll('[data-aos]');
const aosObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const delay = parseInt(entry.target.dataset.aosDelay || '0', 10);
            setTimeout(() => {
                entry.target.classList.add('aos-animate');
            }, delay);
            aosObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

aosElements.forEach(el => aosObserver.observe(el));

// ---- Language Toggle (EN / VI / JA) ----
const i18n = {
    en: {
        hero_badge: '🚀 Free & Open Source',
        hero_title: 'QuickTransee',
        hero_subtitle: 'Your ultimate <strong>cross-platform</strong> translation &amp; OCR tool.<br />Powered by AI. Works everywhere.',
        hero_download: 'Download Free',
        hero_guide: 'User Guide',
        stat_translation: 'Translation Engines',
        stat_platforms: 'Platforms',
        stat_license: 'Open Source',
        feat_badge: 'Features',
        feat_title: 'Everything you need,<br/>nothing you don\'t',
        feat_desc: 'Lightning-fast translation at your fingertips with a single hotkey — no browser, no hassle.',
        feat1_title: 'Selection Translate',
        feat1_desc: 'Select any text and press your hotkey — instant translation appears right where you need it.',
        feat2_title: 'Screenshot OCR',
        feat2_desc: 'Capture any area on screen and extract text instantly using system OCR or AI-powered recognition.',
        feat3_title: 'Clipboard Listening',
        feat3_desc: 'Enable clipboard mode to automatically translate any text you copy — perfect for power readers.',
        feat4_title: 'Text-to-Speech',
        feat4_desc: 'One-click audio playback of any translation result, powered by Lingva TTS engine.',
        feat5_title: 'Word Collection',
        feat5_desc: 'Save translations directly to Anki or Eudic with a single click to build your vocabulary effortlessly.',
        feat6_title: 'External API',
        feat6_desc: 'Integrate QuickTransee into your workflow via HTTP API on port 60828.',
        hiw_badge: 'How it works',
        hiw_title: 'Three ways to translate',
        hiw_desc: 'Choose the method that fits your workflow perfectly.',
        step1_title: 'Select & Translate',
        step1_desc: 'Highlight any text in any application, press your customized hotkey, and get the translation instantly.',
        step2_title: 'Type & Translate',
        step2_desc: 'Open the input window with a hotkey, type or paste your text, hit Enter — results appear side by side.',
        step3_title: 'Screenshot & OCR',
        step3_desc: 'Press shortcut, draw a selection around the text in any image or video, let OCR do the rest.',
        svc_badge: 'Supported Services',
        svc_title: 'Works with all your<br/>favourite engines',
        svc_desc: 'Run multiple engines side-by-side and pick the best result — no compromises.',
        tab_translation: 'Translation',
        tab_vocab: 'Vocabulary',
        platform_title: 'Works on your OS,<br/>any OS',
        win_desc: 'x64 · x86 · arm64',
        mac_desc: 'x64 · Apple Silicon',
        linux_desc: 'Debian · Arch · Wayland',
        platform_download: 'Download .exe',
        platform_download_mac: 'Download .dmg',
        platform_download_linux: 'Download .deb',
        cta_title: 'Start translating smarter today',
        cta_desc: 'Free forever. Open source. No account needed.',
        cta_download: 'Download Latest Release',
        cta_source: 'View Source on GitHub',
    },
    vi: {
        hero_badge: '🚀 Miễn phí & Mã nguồn mở',
        hero_title: 'QuickTransee',
        hero_subtitle: 'Phần mềm dịch thuật &amp; OCR <strong>đa nền tảng</strong> mạnh mẽ.<br />Được hỗ trợ bởi AI. Hoạt động trên mọi hệ điều hành.',
        hero_download: 'Tải xuống miễn phí',
        hero_guide: 'Hướng dẫn sử dụng',
        stat_translation: 'Công cụ dịch thuật',
        stat_platforms: 'Nền tảng',
        stat_license: 'Mã nguồn mở',
        feat_badge: 'Tính năng',
        feat_title: 'Mọi thứ bạn cần,<br/>không có gì thừa',
        feat_desc: 'Dịch thuật siêu nhanh chỉ với một phím tắt — không cần mở trình duyệt.',
        feat1_title: 'Dịch bằng Bôi đen',
        feat1_desc: 'Bôi đen bất kỳ văn bản nào và nhấn phím tắt — bản dịch hiển thị ngay tức thì.',
        feat2_title: 'OCR Ảnh màn hình',
        feat2_desc: 'Chụp bất kỳ vùng nào trên màn hình và nhận dạng văn bản tức thì bằng OCR.',
        feat3_title: 'Nghe Clipboard',
        feat3_desc: 'Bật chế độ clipboard để tự động dịch bất kỳ văn bản nào bạn sao chép.',
        feat4_title: 'Chuyển văn bản thành giọng nói',
        feat4_desc: 'Nghe kết quả dịch chỉ bằng một cú nhấp chuột qua engine Lingva TTS.',
        feat5_title: 'Sổ từ vựng',
        feat5_desc: 'Lưu bản dịch trực tiếp vào Anki hoặc Eudic chỉ với một cú nhấp chuột.',
        feat6_title: 'API Bên ngoài',
        feat6_desc: 'Tích hợp QuickTransee vào quy trình làm việc qua HTTP API trên cổng 60828.',
        hiw_badge: 'Cách sử dụng',
        hiw_title: 'Ba cách để dịch',
        hiw_desc: 'Chọn phương pháp phù hợp nhất với quy trình làm việc của bạn.',
        step1_title: 'Bôi đen & Dịch',
        step1_desc: 'Tô sáng bất kỳ văn bản nào trong ứng dụng, nhấn phím tắt, nhận bản dịch ngay lập tức.',
        step2_title: 'Nhập & Dịch',
        step2_desc: 'Mở cửa sổ nhập bằng phím tắt, nhập hoặc dán văn bản, nhấn Enter — kết quả hiển thị song song.',
        step3_title: 'Chụp màn hình & OCR',
        step3_desc: 'Nhấn phím tắt, vẽ vùng chọn quanh văn bản trong bất kỳ ảnh hoặc video nào, để OCR làm phần còn lại.',
        svc_badge: 'Dịch vụ hỗ trợ',
        svc_title: 'Tương thích với tất cả<br/>các engine yêu thích của bạn',
        svc_desc: 'Chạy nhiều engine song song và chọn kết quả tốt nhất — không có sự đánh đổi.',
        tab_translation: 'Dịch thuật',
        tab_vocab: 'Từ vựng',
        platform_title: 'Hoạt động trên hệ điều hành<br/>của bạn, mọi hệ điều hành',
        win_desc: 'x64 · x86 · arm64',
        mac_desc: 'x64 · Apple Silicon',
        linux_desc: 'Debian · Arch · Wayland',
        platform_download: 'Tải xuống .exe',
        platform_download_mac: 'Tải xuống .dmg',
        platform_download_linux: 'Tải xuống .deb',
        cta_title: 'Bắt đầu dịch thông minh hơn ngay hôm nay',
        cta_desc: 'Miễn phí mãi mãi. Mã nguồn mở. Không cần tài khoản.',
        cta_download: 'Tải xuống phiên bản mới nhất',
        cta_source: 'Xem mã nguồn trên GitHub',
    },
    ja: {
        hero_badge: '🚀 無料・オープンソース',
        hero_title: 'QuickTransee',
        hero_subtitle: '強力な<strong>クロスプラットフォーム</strong>翻訳・OCRツール。<br />AIを活用し、どこでも動作します。',
        hero_download: '無料ダウンロード',
        hero_guide: 'ユーザーガイド',
        stat_translation: '翻訳エンジン',
        stat_platforms: 'プラットフォーム',
        stat_license: 'オープンソース',
        feat_badge: '機能',
        feat_title: '必要なものすべて、<br/>余分なものはなし',
        feat_desc: 'ホットキー1つで超高速翻訳 — ブラウザ不要、手間なし。',
        feat1_title: '選択翻訳',
        feat1_desc: 'テキストを選択してホットキーを押すと — その場で即座に翻訳が表示されます。',
        feat2_title: 'スクリーンショット OCR',
        feat2_desc: '画面上の任意の範囲をキャプチャし、OCRでテキストを即座に抽出。',
        feat3_title: 'クリップボード監視',
        feat3_desc: 'クリップボードモードを有効にすると、コピーしたテキストが自動翻訳されます。',
        feat4_title: 'テキスト読み上げ',
        feat4_desc: 'Lingva TTSエンジンを使用して翻訳結果をワンクリックで再生。',
        feat5_title: '単語帳',
        feat5_desc: 'AnkiまたはEudicにワンクリックで翻訳を保存し、語彙を構築。',
        feat6_title: '外部API',
        feat6_desc: 'HTTPワーフ60828経由でQuickTranseeをワークフローに統合。',
        hiw_badge: '使い方',
        hiw_title: '3つの翻訳方法',
        hiw_desc: 'ワークフローに最適な方法を選択してください。',
        step1_title: '選択して翻訳',
        step1_desc: 'アプリでテキストを選択し、ホットキーを押すと即座に翻訳が表示されます。',
        step2_title: '入力して翻訳',
        step2_desc: 'ホットキーで入力ウィンドウを開き、テキストを入力してEnterを押すと翻訳が並べて表示されます。',
        step3_title: 'スクリーンショット & OCR',
        step3_desc: 'ショートカットを押し、画像や動画のテキスト周囲を選択すると、OCRが処理します。',
        svc_badge: '対応サービス',
        svc_title: 'お気に入りのエンジンすべてに<br/>対応',
        svc_desc: '複数エンジンを並列実行して最良の結果を選択 — 妥協なし。',
        tab_translation: '翻訳',
        tab_vocab: '単語帳',
        platform_title: 'あなたのOSで動作、<br/>すべてのOSで動作',
        win_desc: 'x64 · x86 · arm64',
        mac_desc: 'x64 · Apple Silicon',
        linux_desc: 'Debian · Arch · Wayland',
        platform_download: '.exe をダウンロード',
        platform_download_mac: '.dmg をダウンロード',
        platform_download_linux: '.deb をダウンロード',
        cta_title: '今日からスマートな翻訳を始めよう',
        cta_desc: '永遠に無料。オープンソース。アカウント不要。',
        cta_download: '最新リリースをダウンロード',
        cta_source: 'GitHubでソースを見る',
    }
};

const langs = ['en', 'vi', 'ja'];
const langLabels = { en: '🌐 EN', vi: '🌐 VI', ja: '🌐 JA' };
let currentLang = 'en';

const langToggle = document.getElementById('langToggle');
langToggle.addEventListener('click', () => {
    const idx = langs.indexOf(currentLang);
    currentLang = langs[(idx + 1) % langs.length];
    applyLang(currentLang);
    langToggle.textContent = langLabels[currentLang];
});

function applyLang(lang) {
    const dict = i18n[lang];
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (dict[key] !== undefined) {
            el.innerHTML = dict[key];
        }
    });
    document.documentElement.lang = lang;
}

// ---- Smooth active nav link highlighting ----
const sections = document.querySelectorAll('section[id]');
const navLinkEls = document.querySelectorAll('.nav-link');
const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            navLinkEls.forEach(link => {
                link.style.color = '';
                if (link.getAttribute('href') === '#' + entry.target.id) {
                    link.style.color = 'var(--text-primary)';
                }
            });
        }
    });
}, { threshold: 0.35 });
sections.forEach(s => sectionObserver.observe(s));
