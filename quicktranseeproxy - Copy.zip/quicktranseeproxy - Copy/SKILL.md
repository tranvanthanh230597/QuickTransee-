# QUICKTRANSEE_PROXY

This skill covers the maintenance, development, and configuration of the QuickTransee Proxy project, incorporating global best practices for Node.js, Express, and React.

## When to use

Use this skill when performing tasks related to:
- Configuring Supabase tables or records for the proxy.
- Developing or debugging Express.js routes and controllers in `BE`.
- Updating or building management features in the `FE` dashboard.
- Managing translation service credentials and assignments.

## Instructions

### 1. **System Architecture & Workflow**
- **Pattern**: Follow the `middleware -> controller -> service` architecture for all backend features.
- **Authentication**: Use the `auth` middleware for any endpoint requiring API key validation. The key is matched against `api_token_hash` in Supabase.
- **Logging**: Ensure all translation requests are logged in both `user_logs` (client-side info) and `service_logs` (provider-side info).

### 2. **Backend (Node.js/Express) Best Practices**
- **Error Handling**: Use the `AppError` utility class and centralized `errorHandler` middleware. Never expose stack traces in production.
- **Async Operations**: Use `async/await` for all asynchronous code. Wrap route handlers to catch promise rejections.
- **Security**: Implement security headers using `helmet` and enable `cors` with restricted origins where possible.
- **Validation**: Validate all incoming request bodies and query parameters before processing business logic.

### 3. **Frontend (React/Vite) Best Practices**
- **Performance**: 
    - Eliminate waterfalls by using `Promise.all()` for independent data fetches.
    - Avoid barrel imports to optimize bundle size and tree-shaking.
    - Memoize expensive components and functions using `React.memo` or `useMemo` where appropriate.
- **State Management**: Use React 19 standards. Prefer functional `setState` for stable callbacks.
- **Code Quality**: Use TypeScript for all new frontend code. Ensure props are typed and interfaces are defined for API responses.

### 4. **Database Operations (Supabase)**
- **Tooling**: Use the `supabase-mcp-server` for all production database interactions (DDL and DML).
- **Integrity**: When adding new services (e.g., DeepL), ensure matching entries are created in `services` and `service_credentials` tables.
- **Status Checks**: Always verify that a user's status is `'inuse'` before allowing access to proxy services.

### 5. **Design & UX Guidelines**
- **Aesthetics**: Follow the "Rich Aesthetics" principle. Use curated color palettes, modern typography, and subtle micro-animations.
- **UI Architecture**: Maintain a consistent layout with a solid header and a clear sidebar navigation as per the project's established design.
- **Accessibility**: Ensure all interactive elements have descriptive IDs and maintain a proper heading hierarchy for SEO and screen readers.
