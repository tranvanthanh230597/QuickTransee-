# QuickTranseeProxy 🚀

[English](./README.md) | [Tiếng Việt](./README_VN.md) | [日本語](./README_JP.md)


QuickTranseeProxy is a high-performance middleware server designed to proxy and manage translation requests. It acts as a bridge between client applications and various translation service providers (like DeepL, Google Translate, etc.), providing centralized authentication, logging, and credential management.

## 🏗 System Architecture

The project is structured as a monorepo containing both the backend proxy server and a management frontend.

- **Backend (`/BE`)**: An Express.js API that handles translation requests, validates API keys, and interacts with Supabase for data persistence and logging.
- **Frontend (`/FE`)**: A React-based dashboard for managing users, translation services, and monitoring usage logs.
- **Database**: Powered by **Supabase (PostgreSQL)**, managing user profiles, API credentials, and detailed request/response logs.

---

## 🛠 Tech Stack

### Backend (Node.js)
- **Framework**: Express.js
- **Database Client**: @supabase/supabase-js
- **Security**: Helmet, CORS
- **Logging**: Morgan
- **Environment**: Dotenv

### Frontend (React)
- **Framework**: React 19 + Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS (Planned/Standard)

---

## 📂 Project Structure

```text
quicktranseeproxy/
├── BE/                 # Backend Proxy Server
│   ├── config/         # Database and service configurations
│   ├── controllers/    # Request handlers (logic)
│   ├── middleware/     # Auth, Validation, Error Handling
│   ├── routes/         # API Route definitions
│   ├── services/       # Core business logic (Translation API calls)
│   └── utils/          # Utility functions
├── FE/                 # Management Frontend
│   └── src/            # React source files
└── README.md           # This guide
```

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js (v18+)
- npm or yarn
- A Supabase project

### 2. Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd BE
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file based on the environment requirements:
   ```env
   PORT=3000
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_service_role_key
   CORS_ORIGIN=*
   ```
4. Start the server:
   ```bash
   npm start
   ```

### 3. Frontend Setup
1. Navigate to the frontend directory:
   ```bash
   cd FE
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

---

## 🔐 Authentication

The API uses a custom authentication mechanism. All requests to protected endpoints (like `/v2/translate`) must include an `Authorization` header.

- **Header**: `Authorization: <YOUR_API_TOKEN>`
- **Validation**: The token is matched against the `api_token_hash` in the `users_profile` table.
- **Status Check**: The user must have a status of `'inuse'` to access the services.

---

## 📊 Database Schema

The system relies on the following key tables in Supabase:

- `users_profile`: Stores user information and their `api_token_hash`.
- `services`: Master list of translation providers (e.g., DeepL, Google).
- `service_credentials`: API keys and environment settings for each service.
- `service_assignments`: Links users to specific service credentials.
- `user_logs`: Logs every request made by users.
- `service_logs`: Detailed logs of interactions with external translation APIs.

---

## 🛣 API Endpoints

### Translate (v2)
- **Endpoint**: `POST /v2/translate`
- **Auth**: Required
- **Body**:
  ```json
  {
    "text": "Hello world",
    "target_lang": "vi"
  }
  ```
- **Success Response**:
  ```json
  {
    "text": "Xin chào thế giới"
  }
  ```

---

## 📝 License
This project is licensed under the ISC License.
