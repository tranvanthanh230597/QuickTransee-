# QuickTranseeProxy 🚀 (Japanese Version)

[English](./README.md) | [Tiếng Việt](./README_VN.md) | [日本語](./README_JP.md)


QuickTranseeProxy は、翻訳リクエストのプロキシおよび管理を行うために設計された高性能ミドルウェアサーバーです。クライアントアプリケーションと様々な翻訳サービスプロバイダー（DeepL、Google 翻訳など）の架け橋として機能し、認証、ログ記録、認証情報管理を一元化します。

## 🏗 システム構成

本プロジェクトは、バックエンドプロキシサーバーと管理用フロントエンドを含むモノレポ構成となっています。

- **バックエンド (`/BE`)**: 翻訳リクエストの処理、API キーの検証、データ永続化とログ記録のための Supabase との連携を行う Express.js API です。
- **フロントエンド (`/FE`)**: ユーザー管理、翻訳サービスの管理、利用ログの監視を行うための React ベースのダッシュボードです。
- **データベース**: **Supabase (PostgreSQL)** を採用し、ユーザープロファイル、API 認証情報、詳細なリクエスト/レスポンスログを管理します。

---

## 🛠 使用技術

### バックエンド (Node.js)
- **フレームワーク**: Express.js
- **データベースクライアント**: @supabase/supabase-js
- **セキュリティ**: Helmet, CORS
- **ログ記録**: Morgan
- **環境管理**: Dotenv

### フロントエンド (React)
- **フレームワーク**: React 19 + Vite
- **言語**: TypeScript
- **スタイリング**: Tailwind CSS

---

## 📂 プロジェクト構造

```text
quicktranseeproxy/
├── BE/                 # バックエンド・プロキシサーバー
│   ├── config/         # データベースおよびサービス設定
│   ├── controllers/    # リクエストハンドラ（ロジック）
│   ├── middleware/     # 認証、バリデーション、エラーハンドリング
│   ├── routes/         # API ルート定義
│   ├── services/       # コアビジネスロジック（翻訳 API 呼び出し）
│   └── utils/          # ユーティリティ関数
├── FE/                 # 管理フロントエンド
│   └── src/            # React ソースファイル
└── README.md           # 本ガイド
```

---

## 🚀 はじめに

### 1. 前提条件
- Node.js (v18以降)
- npm または yarn
- Supabase プロジェクト

### 2. バックエンドのセットアップ
1. バックエンドディレクトリに移動します：
   ```bash
   cd BE
   ```
2. 依存関係をインストールします：
   ```bash
   npm install
   ```
3. 環境要件に基づいて `.env` ファイルを作成します：
   ```env
   PORT=3000
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_service_role_key
   CORS_ORIGIN=*
   ```
4. サーバーを起動します：
   ```bash
   npm start
   ```

### 3. フロントエンドのセットアップ
1. フロントエンドディレクトリに移動します：
   ```bash
   cd FE
   ```
2. 依存関係をインストールします：
   ```bash
   npm install
   ```
3. 開発サーバーを起動します：
   ```bash
   npm run dev
   ```

---

## 🔐 認証

API はカスタム認証メカニズムを使用しています。保護されたエンドポイント（`/v2/translate` など）へのすべてのリクエストには、`Authorization` ヘッダーを含める必要があります。

- **ヘッダー**: `Authorization: <YOUR_API_TOKEN>`
- **検証**: トークンは `users_profile` テーブルの `api_token_hash` と照合されます。
- **ステータス確認**: サービスにアクセスするには、ユーザーのステータスが `'inuse'` である必要があります。

---

## 📊 データベーススキーマ

システムは Supabase 内の以下の主要なテーブルに依存しています：

- `users_profile`: ユーザー情報と `api_token_hash` を保存します。
- `services`: 翻訳プロバイダー（DeepL、Google など）のマスターリストです。
- `service_credentials`: 各サービスの API キーと環境設定です。
- `service_assignments`: ユーザーを特定のサービス認証情報に紐付けます。
- `user_logs`: ユーザーによるすべてのリクエストを記録します。
- `service_logs`: 外部翻訳 API とのやり取りの詳細なログです。

---

## 🛣 API エンドポイント

### 翻訳 (v2)
- **エンドポイント**: `POST /v2/translate`
- **認証**: 必須
- **ボディ**:
  ```json
  {
    "text": "Hello world",
    "target_lang": "ja"
  }
  ```
- **成功レスポンス**:
  ```json
  {
    "text": "こんにちは世界"
  }
  ```

---

## 📝 ライセンス
本プロジェクトは ISC ライセンスの下でライセンスされています。
