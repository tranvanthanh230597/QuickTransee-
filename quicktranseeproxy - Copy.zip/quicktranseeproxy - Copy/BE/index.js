// Load environment variables first
require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const { SYSTEM } = require('./constants/messages');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;

// --------------- Global Middleware ---------------

// Helmet – secure HTTP headers
app.use(helmet());

// CORS – allow frontend to call API
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Morgan – HTTP request logger
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Parse JSON & URL-encoded request bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --------------- Routes ---------------

// Root
app.get('/', (req, res) => {
  res.json({ message: SYSTEM.API_RUNNING });
});

// Health check
const supabase = require('./config/supabase');
app.get('/health', async (req, res) => {
  try {
    const { data, error } = await supabase.from('users_profile').select('id').limit(1);
    if (error) throw error;
    res.json({ status: SYSTEM.HEALTH_OK, supabase: SYSTEM.SUPABASE_CONNECTED });
  } catch (err) {
    res.status(500).json({ status: 'error', supabase: err.message });
  }
});

// API v2 – Translate
const translateRoutes = require('./routes/v2/translate.routes');
app.use('/v2/translate', translateRoutes);

// API v2 – Mail
const mailRoutes = require('./routes/v2/mail.routes');
app.use('/v2/mail', mailRoutes);

// --------------- Global Error Handler ---------------

app.use(errorHandler);

// --------------- Start Server ---------------

const start = async () => {
  try {
    await app.listen(PORT);
    console.log(SYSTEM.SERVER_START.replace('{{port}}', PORT));
    console.log(SYSTEM.ENVIRONMENT.replace('{{env}}', process.env.NODE_ENV || 'development'));
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
};

start();

