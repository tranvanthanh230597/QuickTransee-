/**
 * Centralized messages used across the application.
 */
module.exports = {
    ERRORS: {
        // Authentication & Authorization
        UNAUTHORIZED: 'Missing or invalid API key.',
        FORBIDDEN: 'Account is disabled or access denied.',
        AUTH_HEADER_MISSING: 'Missing Authorization header',
        AUTH_FAILED: 'Authentication failed',

        // Resource related
        NOT_FOUND: 'The requested resource was not found.',

        // Translation Service related
        DEEPL_QUOTA_EXCEEDED: 'The translation quota for the current DeepL account has been exceeded. Please try again later or provide a different API Key.',
        DEEPL_SERVICE_NOT_FOUND: 'The DeepL translation service is currently unavailable. Please try again later.',
        DEEPL_CREDENTIALS_NOT_FOUND: 'No valid DeepL credentials found. Please configure a valid API Key in the settings.',
        DEEPL_GENERAL_ERROR: 'An unknown error occurred with the DeepL service. Please try again.',
        DEEPL_KEY_FAILED: 'DeepL Key [{{index}}/{{total}}] failed (Status: {{status}}). Trying the next available key...',

        // GeminiPro Service related
        GEMINIPRO_QUOTA_EXCEEDED: 'The Gemini system is currently overloaded or the quota has been exceeded. Please wait a moment and try again.',
        GEMINIPRO_SERVICE_NOT_FOUND: 'The Gemini service is currently unavailable. Please check your configuration or try again later.',
        GEMINIPRO_CREDENTIALS_NOT_FOUND: 'No API Key found for Gemini. Please configure at least one valid API Key.',
        GEMINIPRO_GENERAL_ERROR: 'An issue occurred with the Gemini service. Please check your configuration or try again later.',
        GEMINIPRO_KEY_FAILED: 'Gemini Key [{{index}}/{{total}}] failed (Status: {{status}}). Switching to a backup key...',
        GEMINIPRO_STREAMING_FAILED: 'The streaming connection to the Gemini server was interrupted. Please try again.',

        // Request & General
        BAD_REQUEST: 'Invalid request parameters.',
        INVALID_PROVIDER_CONFIG: 'Invalid configuration: You sent a {{detected}} request to the {{provider}} endpoint. Please check your Request Path in the App settings.',
        TARGET_LANG_REQUIRED: '"target_lang" is required and must be a non-empty string',
        TEXT_REQUIRED: '"text" is required and must be a non-empty string or array of strings',
        PROVIDER_REQUIRED: 'Translation service provider is missing',
        SERVICE_NOT_FOUND: 'Service "{{service}}" not found',
        CREDENTIALS_NOT_FOUND: 'No active credentials for {{service}}',
        UNSUPPORTED_PROVIDER: "Translation provider '{{provider}}' is not supported yet",
        INTERNAL_SERVER_ERROR: 'Internal Server Error',
        CONTENT_TYPE_JSON: 'Content-Type must be application/json'
    },
    SYSTEM: {
        API_RUNNING: 'API is running 🚀',
        SERVER_START: 'Server is running on http://localhost:{{port}}',
        ENVIRONMENT: 'Environment: {{env}}',
        HEALTH_OK: 'ok',
        SUPABASE_CONNECTED: 'connected'
    },
    SERVICES: {
        DEEPL: 'DeepL',
        GEMINI_PRO: 'GeminiPro',
        OPENAI: 'OpenAI'
    }
};
