const AppError = require('../utils/AppError');
const { ERRORS, SERVICES } = require('../constants/messages');

/**
 * Validate translate request middleware.
 */
const validateTranslateRequest = (req, res, next) => {
    const { text, target_lang } = req.body;

    // --- Validate Content-Type ---
    if (!req.is('application/json')) {
        return next(new AppError(ERRORS.CONTENT_TYPE_JSON, 400));
    }

    // --- Validate Required Fields ---
    const errors = [];
    const providerName = req.params.provider || req.query.provider || req.body.provider || '';
    const baseProvider = providerName.split(':')[0].toLowerCase();

    // --- Format Signature / Source Module Detection ---
    let sourceModule = null;

    // 1. Detect if the request originated from the Gemini module in the App (sends ?key= or has contents/promptList)
    if (req.body.contents || req.body.promptList || req.query.key) {
        sourceModule = SERVICES.GEMINI_PRO;
    }
    // 2. Detect if the request originated from the DeepL module in the App (sends Authorization: DeepL-Auth-Key ...)
    else if (req.headers['authorization'] && req.headers['authorization'].toLowerCase().includes('deepl-auth-key')) {
        sourceModule = SERVICES.DEEPL;
    }

    // Attempt to map requested base provider to pretty name for display
    let targetProvider = baseProvider;
    if (baseProvider === 'deepl') targetProvider = SERVICES.DEEPL;
    else if (baseProvider === 'geminipro') targetProvider = SERVICES.GEMINI_PRO;
    else if (baseProvider === 'openai') targetProvider = SERVICES.OPENAI;

    // Detect mismatched configuration (User put a provider URL in a different provider's setting panel)
    if (sourceModule && baseProvider !== '' && sourceModule.toLowerCase() !== baseProvider) {
        const errorMsg = ERRORS.INVALID_PROVIDER_CONFIG
            .replace('{{detected}}', sourceModule)
            .replace('{{provider}}', targetProvider);
        return next(new AppError(errorMsg, 400));
    }

    // Skip universal text/target_lang validation if it's a valid direct Gemini module request
    // (Gemini module usually sends everything packed inside contents/promptList, no top-level text/target_lang required)
    if (sourceModule === SERVICES.GEMINI_PRO) {
        return next();
    }

    // Check for "text" - can be string (v1/simple) or array (v2/standard)
    const isTextValid = (typeof text === 'string' && text.trim().length > 0) ||
        (Array.isArray(text) && text.length > 0 && typeof text[0] === 'string' && text[0].trim().length > 0);

    if (!isTextValid) {
        errors.push(ERRORS.TEXT_REQUIRED);
    }

    if (!target_lang || typeof target_lang !== 'string' || target_lang.trim().length === 0) {
        errors.push(ERRORS.TARGET_LANG_REQUIRED);
    }

    if (errors.length > 0) {
        return next(new AppError(errors.join('; '), 400));
    }

    next();
};

module.exports = { validateTranslateRequest };
