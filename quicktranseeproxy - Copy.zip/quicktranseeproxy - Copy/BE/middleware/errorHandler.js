const { ERRORS } = require('../constants/messages');

const errorHandler = (err, req, res, next) => {
    const statusCode = err.statusCode || 500;

    // Use original error message if available, otherwise fallback to constants
    let message = err.message || ERRORS.INTERNAL_SERVER_ERROR;

    // Optional: Keep generic messages for security-sensitive codes like 401/403
    // but allow specific messages for 404 (like "Service not found")
    if (statusCode === 401 && !err.message) message = ERRORS.UNAUTHORIZED;
    else if (statusCode === 403 && !err.message) message = ERRORS.FORBIDDEN;
    else if (statusCode === 456) message = ERRORS.DEEPL_QUOTA_EXCEEDED;

    // Log error details for debugging
    console.error(`[ERROR] ${statusCode} - ${err.message || message}`);
    if (!err.isOperational) {
        console.error(err.stack);
    }

    // Format response to match DeepL's expected error format
    res.status(statusCode).json({
        message,
        error: {
            message
        }
    });
};

module.exports = errorHandler;
