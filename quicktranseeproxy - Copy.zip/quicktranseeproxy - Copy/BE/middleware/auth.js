const supabase = require('../config/supabase');
const AppError = require('../utils/AppError');
const { ERRORS } = require('../constants/messages');

/**
 * Authentication middleware.
 * Validates API key from Authorization header against Supabase users_profile table.
 */
const auth = async (req, res, next) => {
    try {
        // --- Step 1: Extract API key ---
        // Support both Header (standard) and Query Param (how some apps like QuickTransee send it)
        let apiKey = req.headers['authorization'] || req.query.key;

        if (!apiKey) {
            throw new AppError(ERRORS.AUTH_HEADER_MISSING, 401);
        }

        // Strip common prefixes if coming from header
        if (typeof apiKey === 'string') {
            apiKey = apiKey.replace(/^(DeepL-Auth-Key|Bearer)\s+/i, '').trim();
        }

        // --- Step 2: Query Supabase for matching token ---
        const { data: user, error } = await supabase
            .from('users_profile')
            .select('*')
            .eq('api_token_hash', apiKey)
            .single();

        if (error || !user) {
            throw new AppError(ERRORS.UNAUTHORIZED, 401);
        }

        // --- Step 3: Check user status ---
        if (user.status !== 'inuse') {
            throw new AppError(ERRORS.FORBIDDEN, 403);
        }

        // --- Step 4: Attach user to request ---
        req.user = user;

        next();
    } catch (err) {
        next(err instanceof AppError ? err : new AppError(ERRORS.AUTH_FAILED, 401));
    }
};

module.exports = auth;
