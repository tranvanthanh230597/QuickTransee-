/**
 * Custom application error class.
 * Extends native Error with HTTP status code and operational flag.
 * Operational errors are expected errors (e.g. validation, auth failures).
 */
class AppError extends Error {
    /**
     * @param {string} message - Error message
     * @param {number} statusCode - HTTP status code (default: 500)
     */
    constructor(message, statusCode = 500) {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = true;
        Error.captureStackTrace(this, this.constructor);
    }
}

module.exports = AppError;
