'use strict';

require('dotenv').config();
const { sendEmailFromTemplate } = require('./services/mail.service');

async function test() {
    console.log('--- Starting Mail Test ---');
    console.log('Sending to: thanhtv@aureole-it.vn');

    try {
        const result = await sendEmailFromTemplate({
            to: 'thanhtv@aureole-it.vn',
            subject: 'Your QuickTransee API Token',
            templateName: 'api-token-delivery.html',
            variables: {
                '{{USER_NAME}}': 'Thanh TV',
                '{{API_TOKEN}}': 'qt_57b1f8e2d4c3a9b0e1f7d2c3b4a5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2',
                '{{PROXY_ENDPOINT}}': 'http://localhost:3000/v2/translate',
                '{{PLAN_NAME}}': 'Test Plan',
                '{{QUOTA_LIMIT}}': 'Unlimited',
                '{{TOKEN_EXPIRY}}': 'Never',
                '{{DASHBOARD_URL}}': 'https://quicktransee.com/dashboard',
                '{{DOCS_URL}}': 'https://quicktransee.com/docs',
                '{{SUPPORT_URL}}': 'https://quicktransee.com/support',
                '{{YEAR}}': '2026'
            }
        });

        console.log('✅ Mail sent successfully!');
    } catch (err) {
        console.error('❌ Failed to send mail:');
        console.error(err);
    }
}

test();
