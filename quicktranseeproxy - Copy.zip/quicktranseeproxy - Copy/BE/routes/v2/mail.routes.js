'use strict';

const express = require('express');
const router = express.Router();

const auth = require('../../middleware/auth');
const AppError = require('../../utils/AppError');
const { sendEmail, sendEmailFromTemplate } = require('../../services/mail.service');

/**
 * POST /v2/mail/send
 * Send a raw HTML email.
 *
 * Body: { to: string | string[], subject: string, html: string }
 */
router.post('/send', auth, async (req, res, next) => {
    try {
        const { to, subject, html } = req.body;

        if (!to || !subject || !html) {
            throw new AppError('to, subject, and html are required', 400);
        }

        await sendEmail({ to, subject, html });
        res.json({ success: true, message: 'Email sent successfully' });
    } catch (err) {
        next(err);
    }
});

/**
 * POST /v2/mail/send-template
 * Send an email rendered from an EmailTemplate file.
 *
 * Body: {
 *   to: string | string[],
 *   subject: string,
 *   templateName: string,       // filename inside BE/EmailTemplates/
 *   variables?: Record<string, string>,
 *   fallbackHtml?: string
 * }
 */
router.post('/send-template', auth, async (req, res, next) => {
    try {
        const { to, subject, templateName, variables, fallbackHtml } = req.body;

        if (!to || !subject || !templateName) {
            throw new AppError('to, subject, and templateName are required', 400);
        }

        await sendEmailFromTemplate({ to, subject, templateName, variables, fallbackHtml });
        res.json({ success: true, message: 'Email sent successfully' });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
