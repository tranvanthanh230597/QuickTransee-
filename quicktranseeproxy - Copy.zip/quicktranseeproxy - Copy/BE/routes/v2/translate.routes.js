const express = require('express');
const router = express.Router();

const auth = require('../../middleware/auth');
const { validateTranslateRequest } = require('../../middleware/validate');
const { translateText } = require('../../controllers/translate.controller');

// API v2 – Translate
// Supports both:
// 1. POST /v2/translate (provider in body or query)
// 2. POST /v2/translate/:provider (provider in path)
router.post(['/', '/:provider'], auth, validateTranslateRequest, translateText);

module.exports = router;
