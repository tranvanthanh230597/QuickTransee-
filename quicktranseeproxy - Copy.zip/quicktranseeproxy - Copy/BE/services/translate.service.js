const AppError = require('../utils/AppError');
const deeplProvider = require('./providers/deepl.service');
const geminiProvider = require('./providers/geminipro.service');
const { ERRORS, SERVICES } = require('../constants/messages');

/**
 * Main Translation Service Dispatcher.
 */
const translate = async (req, res) => {
    const body = req.body || {};
    const user = req.user;

    // 1. Determine provider (Path > Body > Query)
    const rawProvider = req.params.provider || body.provider || req.query.provider;

    if (!rawProvider) {
        console.error('[DEBUG] Provider missing. Body:', JSON.stringify(body));
        throw new AppError(ERRORS.PROVIDER_REQUIRED, 400);
    }

    // Split provider and action (e.g., 'geminipro:streamGenerateContent' -> 'geminipro' and 'streamGenerateContent')
    const [provider, action] = rawProvider.split(':');

    switch (provider.toLowerCase()) {
        case 'deepl':
            return await deeplProvider.translate(body, user);

        case 'geminipro':
            return await geminiProvider.translate(body, user, action, res);

        default:
            let prettyProvider = provider;
            if (provider.toLowerCase() === 'deepl') prettyProvider = SERVICES.DEEPL;
            if (provider.toLowerCase() === 'geminipro') prettyProvider = SERVICES.GEMINI_PRO;
            if (provider.toLowerCase() === 'openai') prettyProvider = SERVICES.OPENAI;

            const errorMsg = ERRORS.UNSUPPORTED_PROVIDER.replace('{{provider}}', prettyProvider);
            throw new AppError(errorMsg, 400);
    }
};

module.exports = { translate };
