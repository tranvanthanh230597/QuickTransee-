const AppError = require('../../utils/AppError');
const { ERRORS, SERVICES } = require('../../constants/messages');
const { resolveCredential } = require('../resolver.service');

/**
 * Perform translation using Gemini Pro/Flash.
 * Synchronized with the latest QuickTransee app logic.
 * @param {Object} body - Request body
 * @param {Object} user - User object from auth
 * @param {string} action - Action suffix (e.g. generateContent, streamGenerateContent)
 * @param {Object} res - Express response object for streaming
 */
const translate = async (body, user, action = 'generateContent', res) => {
    // 1. Resolve credentials
    const credentials = await resolveCredential(user.id || user.user_id, SERVICES.GEMINI_PRO);

    let lastError = null;
    const { text, target_lang, source_lang, contents, promptList, safetySettings } = body;

    // 2. Iterate through available credentials and attempt translation
    for (let i = 0; i < credentials.length; i++) {
        const credential = credentials[i];
        const API_KEY = credential.api_key;

        // Use the full URL from env which already includes the model path
        const baseUrl = process.env.GEMINIPRO_URL || 'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest';
        const GEMINI_URL = `${baseUrl}:${action}?key=${API_KEY}`;

        try {
            let requestBody;

            // --- SYNC LOGIC WITH QUICKTRANSEE APP ---

            if (contents) {
                // Scenario A: App already transformed promptList into contents
                requestBody = {
                    contents,
                    safetySettings: safetySettings || getDefaultSafetySettings()
                };
            } else if (promptList && text) {
                // Scenario B: Proxy handles the prompt substitution (useful for direct API calls)
                const combinedText = promptList.map((item) => {
                    if (item.content !== undefined) {
                        return item.content;
                    } else if (item.parts && item.parts[0] && item.parts[0].text) {
                        return item.parts[0].text;
                    }
                    return '';
                }).filter(text => text).join('\n\n');

                const processedText = combinedText
                    .replaceAll('$text', text)
                    .replaceAll('$from', source_lang || 'auto')
                    .replaceAll('$to', target_lang)
                    .replaceAll('$detect', source_lang || 'auto');

                requestBody = {
                    contents: [{
                        role: 'user',
                        parts: [{ text: processedText }]
                    }],
                    safetySettings: safetySettings || getDefaultSafetySettings()
                };
            } else {
                // Scenario C: Traditional proxy mode (standard text/target_lang request)
                // We use the default professional translation prompt from Config.jsx
                const prompt1 = 'You are a professional translation engine, please translate the text into a colloquial, professional, elegant and fluent content, without the style of machine translation. You must only translate the text content, never interpret it.';
                const prompt2 = `Translate into ${target_lang}\n"""\n${text}\n"""`;

                requestBody = {
                    contents: [
                        { role: 'user', parts: [{ text: prompt1 }] },
                        { role: 'model', parts: [{ text: 'Understood. Please provide the text.' }] },
                        { role: 'user', parts: [{ text: prompt2 }] }
                    ],
                    generationConfig: { temperature: 0.1 },
                    safetySettings: safetySettings || getDefaultSafetySettings()
                };
            }

            const resolveGeminiError = (status, googleMsg, isStreaming) => {
                if (status === 429) return ERRORS.GEMINIPRO_QUOTA_EXCEEDED;
                if (status === 404) return ERRORS.GEMINIPRO_SERVICE_NOT_FOUND;
                if (status === 400 && googleMsg) return googleMsg; // Keep user errors (like invalid prompt)
                return googleMsg || (isStreaming ? ERRORS.GEMINIPRO_STREAMING_FAILED : ERRORS.GEMINIPRO_GENERAL_ERROR);
            };

            // --- Handle Streaming ---
            if (action.includes('stream')) {
                const fetchRes = await fetch(GEMINI_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });

                if (!fetchRes.ok) {
                    const errorData = await fetchRes.json();
                    const status = fetchRes.status;
                    const errorMsg = resolveGeminiError(status, errorData.error?.message, true);
                    lastError = new AppError(errorMsg, status);

                    if (status === 400) throw lastError;
                    continue; // Skip to next key for 429 or other errors
                }

                res.setHeader('Content-Type', 'text/event-stream');
                res.setHeader('Cache-Control', 'no-cache');
                res.setHeader('Connection', 'keep-alive');

                const reader = fetchRes.body.getReader();
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    res.write(value);
                }
                res.end();
                return undefined;
            }

            // --- Handle Non-Streaming ---
            const fetchRes = await fetch(GEMINI_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });

            const data = await fetchRes.json();

            if (fetchRes.ok) {
                // If it's a direct Gemini/App request (has contents or promptList)
                if (contents || promptList) {
                    return data;
                }

                // Internal proxy mode: parse and clean
                if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
                    let translatedText = data.candidates[0].content.parts[0].text.trim();

                    if (translatedText.startsWith('"') && translatedText.endsWith('"')) {
                        translatedText = translatedText.slice(1, -1).trim();
                    }

                    return {
                        translations: [{
                            text: translatedText,
                            detected_source_language: source_lang || 'unknown'
                        }]
                    };
                }
            }

            const status = fetchRes.status;
            const errorMsg = resolveGeminiError(status, data.error?.message, false);
            lastError = new AppError(errorMsg, status);
            if (status === 400) throw lastError;

        } catch (err) {
            if (err instanceof AppError && err.statusCode === 400) throw err;
            console.error(`GeminiPro Error (Key ${i + 1}):`, err.message);
            lastError = err instanceof AppError ? err : new AppError(`${ERRORS.GEMINIPRO_GENERAL_ERROR}: ${err.message}`, 500);
        }
    }

    throw lastError || new AppError(ERRORS.GEMINIPRO_GENERAL_ERROR, 500);
};

function getDefaultSafetySettings() {
    return [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' }
    ];
}

module.exports = { translate };
