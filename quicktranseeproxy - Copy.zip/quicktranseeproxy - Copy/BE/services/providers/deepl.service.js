const AppError = require('../../utils/AppError');
const { ERRORS, SERVICES } = require('../../constants/messages');
const { resolveCredential } = require('../resolver.service');

/**
 * Perform translation using DeepL.
 * @param {Object} body - Request body
 * @param {Object} user - User object from auth
 */
const translate = async (body, user) => {
    // 1. Resolve credentials (returns an array of one or more credentials)
    const credentials = await resolveCredential(user.id || user.user_id, SERVICES.DEEPL);

    let lastError = null;

    // 2. Iterate through available credentials and attempt translation
    for (let i = 0; i < credentials.length; i++) {
        const credential = credentials[i];
        const DEEPL_AUTH_KEY = credential.api_key;

        // Use the unified DeepL URL from env or default to free
        const DEEPL_URL = process.env.DEEPL_URL || 'https://api-free.deepl.com/v2/translate';

        try {
            const response = await fetch(DEEPL_URL, {
                method: 'POST',
                headers: {
                    'Authorization': `DeepL-Auth-Key ${DEEPL_AUTH_KEY}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(body)
            });

            const data = await response.json();

            if (response.ok) {
                return data; // Success! Return the translation data
            }

            // If not ok, capture the error and determine whether to retry
            const logMsg = ERRORS.DEEPL_KEY_FAILED
                .replace('{{index}}', i + 1)
                .replace('{{total}}', credentials.length)
                .replace('{{status}}', response.status);
            console.warn(logMsg);

            const errorMsg = (data.error && data.error.message) || data.message || `DeepL API error (${response.status})`;
            lastError = new AppError(errorMsg, response.status);

            // If it's a client error that retrying won't fix (like 400 Bad Request), throw immediately
            if (response.status === 400) {
                throw lastError;
            }

            // Otherwise, continue to the next key (for 401, 403, 429, 456, 5xx, etc.)
        } catch (err) {
            if (err instanceof AppError && err.statusCode === 400) throw err;

            console.error(ERRORS.DEEPL_KEY_FAILED.replace('{{index}}', i + 1).replace('{{total}}', credentials.length).replace('{{status}}', 'Catch'), err.message);
            lastError = err instanceof AppError ? err : new AppError(`${ERRORS.DEEPL_GENERAL_ERROR}: ${err.message}`, 500);

            // Continue loop to try next key
        }
    }

    // 3. If we've exhausted all keys and none worked, throw the last error encountered
    throw lastError || new AppError(ERRORS.DEEPL_GENERAL_ERROR, 500);
};

module.exports = { translate };
