const supabase = require('../config/supabase');
const AppError = require('../utils/AppError');
const { ERRORS } = require('../constants/messages');

/**
 * Service Resolver.
 * Responsible for finding the correct API key for a user and service.
 * 
 * Logic:
 * 1. Check if the user has a specific assignment for this service.
 * 2. If yes, use that specific credential.
 * 3. If no, fallback to any active credential for the service.
 */

/**
 * Resolves a credential for a given user and service name.
 * @param {string} userId - UUID of the user
 * @param {string} serviceName - Name of the service (e.g., 'DeepL')
 * @returns {Promise<Object>} The resolved credential object { api_key, ... }
 */
const resolveCredential = async (userId, serviceName) => {
    // 1. Find the service ID first
    const { data: service, error: sError } = await supabase
        .from('services')
        .select('service_id')
        .eq('name', serviceName)
        .single();

    if (sError || !service) {
        const msg = ERRORS.SERVICE_NOT_FOUND.replace('{{service}}', serviceName);
        throw new AppError(msg, 404);
    }

    const serviceId = service.service_id;

    // 2. Check for specific assignment
    const { data: assignment, error: aError } = await supabase
        .from('service_assignments')
        .select('credential_id')
        .eq('user_id', userId)
        .eq('service_id', serviceId)
        .maybeSingle();

    if (!aError && assignment && assignment.credential_id) {
        // Found a specific assignment, fetch that exact key
        const { data: credential, error: cError } = await supabase
            .from('service_credentials')
            .select('*')
            .eq('credential_id', assignment.credential_id)
            .eq('is_active', true)
            .single();

        if (!cError && credential) {
            return [credential]; // Return as array for consistency
        }
    }

    // 3. Fallback: Get ALL active credentials for this service
    const { data: credentials, error: fError } = await supabase
        .from('service_credentials')
        .select('*')
        .eq('service_id', serviceId)
        .eq('is_active', true)
        .order('created_at', { ascending: true });

    if (fError || !credentials || credentials.length === 0) {
        const errorKey = `${serviceName.toUpperCase()}_CREDENTIALS_NOT_FOUND`;
        const fallbackMsg = ERRORS.CREDENTIALS_NOT_FOUND.replace('{{service}}', serviceName);
        throw new AppError(ERRORS[errorKey] || fallbackMsg, 404);
    }

    return credentials;
};

module.exports = { resolveCredential };
