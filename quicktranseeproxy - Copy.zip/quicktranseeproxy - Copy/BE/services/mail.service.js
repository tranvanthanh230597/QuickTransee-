'use strict';

const nodemailer = require('nodemailer');
const fs = require('fs/promises');
const path = require('path');

// ---------------------------------------------------------------
// Helper: HTML-encode a string (mirrors C# WebUtility.HtmlEncode)
// ---------------------------------------------------------------
function htmlEncode(text) {
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// ---------------------------------------------------------------
// Helper: Replace {{key}} placeholders in a template string
// ---------------------------------------------------------------
function replaceTemplateVariables(template, variables = {}) {
    if (!template) throw new Error('Template cannot be null or empty');
    if (!variables || Object.keys(variables).length === 0) return template;

    let result = template;
    for (const [key, value] of Object.entries(variables)) {
        result = result.split(key).join(htmlEncode(value));
    }
    return result;
}

// ---------------------------------------------------------------
// Build a nodemailer transporter from environment variables
// ---------------------------------------------------------------
function createTransporter() {
    const host = process.env.SMTP_HOST;
    const port = parseInt(process.env.SMTP_PORT || '587', 10);
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;
    const secure = process.env.SMTP_SECURE === 'true'; // true = SSL (port 465)

    if (!host || !user || !pass) {
        throw new Error('SMTP configuration is incomplete. Check SMTP_HOST, SMTP_USER, SMTP_PASS in .env');
    }

    return nodemailer.createTransport({
        host,
        port,
        secure,
        auth: { user, pass },
        requireTLS: process.env.SMTP_REQUIRE_TLS === 'true',
        connectionTimeout: parseInt(process.env.SMTP_CONNECT_TIMEOUT_MS || '10000', 10),
        socketTimeout: parseInt(process.env.SMTP_SOCKET_TIMEOUT_MS || '10000', 10),
    });
}

// ---------------------------------------------------------------
// Public: send a plain HTML body
// ---------------------------------------------------------------
async function sendEmail({ to, subject, html }) {
    if (!to || !subject || !html) {
        throw new Error('to, subject, and html are required');
    }

    const toList = Array.isArray(to) ? to.join(',') : to;
    const from = `"${process.env.SMTP_FROM_NAME || 'App'}" <${process.env.SMTP_USER}>`;

    const transporter = createTransporter();
    await transporter.sendMail({ from, to: toList, subject, html });
}

// ---------------------------------------------------------------
// Public: resolve template file, substitute variables, then send
// ---------------------------------------------------------------
async function sendEmailFromTemplate({ to, subject, templateName, variables = {}, fallbackHtml = '' }) {
    const templateRoot = path.join(__dirname, '..', 'EmailTemplates');
    const safeName = path.basename(templateName);
    const templatePath = path.join(templateRoot, safeName);

    let html;
    try {
        const raw = await fs.readFile(templatePath, 'utf-8');
        html = replaceTemplateVariables(raw, variables);
    } catch (err) {
        if (err.code === 'ENOENT') {
            console.warn(`[MailService] Template "${safeName}" not found – using fallback`);
            html = fallbackHtml;
        } else {
            throw err;
        }
    }

    await sendEmail({ to, subject, html });
}

module.exports = { sendEmail, sendEmailFromTemplate, replaceTemplateVariables };
