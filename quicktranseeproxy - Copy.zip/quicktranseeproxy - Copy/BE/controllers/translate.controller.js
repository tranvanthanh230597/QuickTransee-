const translateService = require('../services/translate.service');

/**
 * Translate controller.
 * Handles HTTP request/response for the translate endpoint.
 * Delegates business logic to translateService.
 */

/**
 * POST /v2/translate
 * @param {import('express').Request} req - Express request (body: { text, target_lang })
 * @param {import('express').Response} res - Express response
 * @param {import('express').NextFunction} next - Next middleware
 */
const translateText = async (req, res, next) => {
    try {
        // The service function is expected to extract 'user' and other details from 'req' internally.
        const result = await translateService.translate(req, res);

        // If result is undefined, we assume the service has already handled the response (e.g. streaming)
        if (result !== undefined && !res.headersSent) {
            res.status(200).json(result);
        }
    } catch (err) {
        next(err);
    }
};

module.exports = { translateText };
